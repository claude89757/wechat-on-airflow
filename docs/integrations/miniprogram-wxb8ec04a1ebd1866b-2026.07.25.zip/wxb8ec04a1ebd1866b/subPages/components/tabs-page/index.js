Component({
  options: {
    multipleSlots: !0
  },
  properties: {
    tabs: {
      type: Array,
      value: []
    },
    tabWidth: {
      type: String,
      value: "auto"
    },
    tabPadding: {
      type: String,
      value: "40rpx"
    },
    stripWidth: {
      type: String,
      value: "60rpx"
    },
    borderBottom: {
      type: String,
      value: ""
    },
    multiplePage: {
      type: Boolean,
      value: !1
    },
    refresherEnabled: {
      type: Array,
      value: []
    },
    refresherTriggered: {
      type: Array,
      value: []
    },
    pageBackground: {
      type: String,
      value: "#F6F6F6"
    },
    tabsBackground: {
      type: String,
      value: "#FFFFFF"
    },
    showTabPanelBtn: {
      type: Boolean,
      value: !0
    },
    style: {
      type: String,
      value: "default"
    },
    setDefaultcurrentTab: {
      value: 0,
      type: Number
    }
  },
  observers: {
    "setDefaultcurrentTab, tabs": function(t, e) {
      e.length > 0 && this.initNodeInfo(t)
    }
  },
  data: {
    tabsScrollLeft: 0,
    tabsStripLeft: 0,
    tabsStripWidth: 0,
    tabWidthArray: [],
    currentTab: 0,
    tabOverflow: !1,
    tabPanelVisible: !1
  },
  methods: {
    initNodeInfo: function(t) {
      var e = this,
        a = wx.createSelectorQuery().in(this);
      a.select("#scroll").boundingClientRect(), a.selectAll(".tab").boundingClientRect(), a.selectAll(".tab-strip").boundingClientRect(), a.select("#panelBtn").boundingClientRect(), a.exec((function(n) {
        e.data.scrollNodeInfo = n[0], e.data.tabNodeInfo = n[1], e.data.tabStripNodeInfo = n[2];
        var r = 0,
          i = n[1].map((function(t) {
            return r += t.width, t.width + "px"
          })),
          o = e.data.showTabPanelBtn && r > n[0].width;
        e.setData({
          tabOverflow: o,
          tabWidthArray: i,
          currentTab: t
        }, (function() {
          o ? a.exec((function(t) {
            e.data.scrollNodeInfo = t[0], e.data.tabNodeInfo = t[1], e.data.tabStripNodeInfo = t[2], e.data.panelBtnNodeInfo = t[3], e.setActiveTab(e.data.currentTab)
          })) : e.setActiveTab(e.data.currentTab)
        }))
      }))
    },
    setActiveTab: function(t) {
      var e = this;
      this.data.scrollNodeInfo && this.data.tabNodeInfo[t] && this.data.tabStripNodeInfo[t] && this.setData({
        tabsScrollLeft: this.data.tabNodeInfo[t].left - this.data.scrollNodeInfo.width / 2 + this.data.tabNodeInfo[t].width / 2 - (this.data.panelBtnNodeInfo ? this.data.panelBtnNodeInfo.width / 2 : 0),
        tabsStripLeft: this.data.tabStripNodeInfo[t].left,
        tabsStripWidth: this.data.tabStripNodeInfo[t].width,
        currentTab: t,
        tabPanelVisible: !1
      }, (function() {
        e.triggerEvent("change", {
          tabIndex: t
        })
      }))
    },
    onPanelBtnTap: function() {
      this.setData({
        tabPanelVisible: !this.data.tabPanelVisible
      })
    },
    onTabTap: function(t) {
      var e = t.currentTarget.dataset.index;
      e != this.data.currentTab && this.setActiveTab(e)
    },
    onContentChange: function(t) {
      var e = t.detail,
        a = e.source,
        n = e.current;
      "touch" == a && this.setActiveTab(n)
    },
    onContentScrollLower: function(t) {
      var e = t.currentTarget.dataset.index;
      this.triggerEvent("scrolltolower", {
        tabIndex: e
      })
    },
    onContentRefresh: function(t) {
      var e = t.currentTarget.dataset.index;
      this.triggerEvent("refresherrefresh", {
        tabIndex: e
      })
    }
  }
});