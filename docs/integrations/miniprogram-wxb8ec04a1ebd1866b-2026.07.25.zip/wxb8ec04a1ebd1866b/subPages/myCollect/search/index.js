var t = require("../../../@babel/runtime/helpers/toConsumableArray"),
  e = require("../../../@babel/runtime/helpers/objectSpread2"),
  a = require("../../../modules/server/fetch.js"),
  i = getApp();
Page({
  mixins: [require("../../../modules/colorMixin")],
  searchParam: {
    size: 20,
    keyword: ""
  },
  pageIndex: 0,
  isAllLoaded: !1,
  data: {
    isLoaded: !1,
    inputValue: "",
    inputFocus: !1,
    productList: [],
    currencySymbol: i.getCurrencySymbol(),
    isShowRecord: !0
  },
  goDetail: function(t) {
    var e = t.currentTarget.dataset.id;
    e && wx.navigateTo({
      url: "/subPages/shopping/details/details?productid=" + e
    })
  },
  handleGetCategoryProductList: function() {
    var i = this,
      n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
    (0, a.fetch)({
      url: "wxapi/ProductCollect/LoadProduct",
      params: e({
        includeTag: !0,
        includeSale: 365,
        includeUnitName: !0,
        pageIdx: n
      }, this.searchParam)
    }).then((function(e) {
      if (e) {
        var a = i.clearProductData(e.data || []);
        console.log("products", a);
        var o = 0 == n ? [] : i.data.productList;
        o.push.apply(o, t(a)), i.isAllLoaded = a.length < i.searchParam.size, i.pageIndex = n, i.setData({
          productList: o,
          isLoaded: !0
        });
        var r = [{
            name: i.searchParam.keyword.trim()
          }].concat(t(i.data.historySearchList)),
          s = [];
        s = r.concat(), r.length > 6 && s.pop(), wx.setStorage({
          key: "HistorySearchList",
          data: s.filter((function(t, e, a) {
            return a.findIndex((function(e) {
              return e.name == t.name && t.name
            })) === e
          }))
        })
      } else {
        if ("请登录会员" == e.message) return void wx.navigateTo({
          url: "/accountSubpages/pages/account/login/login"
        });
        wx.showModal({
          title: "提示",
          content: e.message || "网络错误",
          showCancel: !1
        })
      }
    }))
  },
  clearProductData: function(t) {
    var e = this;
    return t.map((function(t) {
      "批发商贸" == i.globalData.industry && void 0 !== t.availableStock ? t.stock = t.availableStock : t.isEnableVirtualStock && (t.stock = t.virtualStock), e.setData({
        isHideUint: 1 == i.getGlobalByKey("_closeAllUnit")
      });
      var a = !1;
      t.productSeries && t.productSeries.length > 0 && (a = t.productSeriesMaxPrice > t.productSeriesMinPrice);
      var n = t.sellPrice.toString().split(".")[0],
        o = t.sellPrice.toString().split(".")[1] || "00",
        r = o.length > 1 ? o : o + "0",
        s = (r ? "." + r : "") + (a ? "起" : "") + (t.unitName && !0 !== e.data.isHideUint ? "/" + t.unitName : "");
      if (t.minQuantity || t.baseQuantity) {
        var c = t.minQuantity || 0,
          u = t.baseQuantity;
        if (c % u != 0 && u)
          if (c > u) {
            for (var l = u; l < c;) l += u;
            t.minSellQuantity = l
          } else t.minSellQuantity = u;
        else t.minSellQuantity = 0 !== c ? c : u
      }
      return {
        id: t.id,
        uid: t.uid,
        productName: t.name,
        stock: t.stock,
        productSaleNum: t.productSaleNum || 0,
        productTags: t.productTags,
        unitName: t.unitName && !0 !== e.data.isHideUint ? t.unitName : "",
        sellPrice: t.sellPrice,
        sellPriceInt: n,
        sellPriceFloat: s,
        productOriginalPrice: t.sellPrice2,
        isOutOfStock: t.isOutOfStock,
        isOffShelf: !!t.isOffShelf && t.isOffShelf,
        minSellQuantity: t.minSellQuantity || 0,
        imageName: t.defaultproductimage ? t.defaultproductimage.imagepath.replace("_200x200", "") : "",
        isSeries: !1,
        ignoreStock: t.ignoreStock,
        category: t.category.uid,
        attribute6: t.attribute6,
        baseQuantity: t.baseQuantity || 1
      }
    }))
  },
  onInputInput: function(t) {
    this.setData({
      inputValue: t.detail.value
    })
  },
  onClearBtnTap: function() {
    console.log("onClearBtnTap"), this.setData({
      inputValue: "",
      inputFocus: !0
    })
  },
  onInputFocus: function() {
    this.setData({
      inputFocus: !0
    })
  },
  confirmSearch: function() {
    console.log("confirmSearch"), this.searchParam.keyword = this.data.inputValue, this.setData({
      inputFocus: !1,
      isShowRecord: !1
    }), this.handleGetCategoryProductList()
  },
  onScrollToLower: function() {
    !this.isAllLoaded && this.handleGetCategoryProductList(this.pageIndex + 1)
  },
  delRecord: function() {
    var t = this;
    wx.showModal({
      title: "提示",
      content: "确定删除全部搜索历史?",
      complete: function(e) {
        e.cancel, e.confirm && (wx.removeStorage({
          key: "HistorySearchList"
        }), t.setData({
          historySearchList: []
        }))
      }
    })
  },
  onRecordTap: function(t) {
    var e = t.currentTarget.dataset.name;
    this.setData({
      inputValue: e
    })
  },
  onLoad: function() {
    this.setData({
      historySearchList: wx.getStorageSync("HistorySearchList") || []
    })
  },
  onReady: function() {},
  onShow: function() {},
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});