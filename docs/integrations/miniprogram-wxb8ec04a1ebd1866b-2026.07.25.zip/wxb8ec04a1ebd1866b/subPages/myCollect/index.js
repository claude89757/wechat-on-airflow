var t, e, a = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  i = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../@babel/runtime/helpers/objectSpread2"),
  o = require("../../@babel/runtime/helpers/defineProperty"),
  n = require("../../@babel/runtime/helpers/toConsumableArray"),
  c = require("../../modules/server/fetch.js"),
  s = getApp(),
  u = require("../../modules/services/cartService.js").initCartService(),
  l = null;
Page({
  mixins: [require("../../modules/colorMixin")],
  data: {
    currencySymbol: s.getCurrencySymbol(),
    tabList: [],
    tabPageRefresherEnabled: [],
    tabPageRefresherTriggered: [],
    pageDataList: [],
    buyCourseData: null,
    courseBuyPopupShow: !1,
    firstLoad: [],
    cartNumberObj: {},
    _allProductsObj: {},
    isNeadSyncCart: !0
  },
  onSliderShow: function() {
    this.setData({
      sliderShow: !0
    })
  },
  onSliderHide: function() {
    this.setData({
      sliderShow: !1
    })
  },
  onSearchAreaTap: function() {
    wx.navigateTo({
      url: "/trainingSubpages/pages/shopping/search/index"
    })
  },
  onTabsChange: function(t) {
    console.log("eeee", t);
    var e = t.detail.tabIndex;
    this.setData({
      tabIndex: e
    });
    var a = this.data.pageDataList[e],
      i = a.data;
    a.allLoaded || 0 != i.length || this.handleGetCategoryProductList(e)
  },
  onTabsPageScrollToLower: function(t) {
    var e = t.detail.tabIndex,
      a = this.data.pageDataList[e],
      i = a.pageIdx;
    a.allLoaded || this.handleGetCategoryProductList(e, i + 1)
  },
  onTabsPageRefresh: function(t) {
    var e = t.detail.tabIndex;
    this.handleGetCategoryProductList(e)
  },
  handleGetCategoryList: function() {
    var t = this;
    (0, c.fetch)({
      url: "wxapi/ProductCollect/LoadCategory",
      params: {},
      isShowMessage: !1
    }).then((function(e) {
      if (e) {
        console.log("eeresess", e);
        var a = [],
          i = [],
          r = [],
          o = [];
        e.result && e.forEach((function(t, e) {
          a.push(t.DisplayName), i.push(!0), r.push(!1), o.push({
            categorieIndex: e,
            categoryUid: t.CategoryUidTxt,
            data: [],
            allLoaded: !1
          })
        })), t.setData({
          tabList: ["全部商品"].concat(a),
          tabPageRefresherEnabled: i,
          tabPageRefresherTriggered: r,
          pageDataList: [{
            categorieIndex: -1,
            categoryUid: null,
            data: [],
            allLoaded: !1
          }].concat(o)
        })
      } else wx.showModal({
        title: "提示",
        content: e.message || "网络错误",
        showCancel: !1
      })
    })).catch((function(t) {
      console.log("errr", t), "请先登录会员" != t.message ? wx.showModal({
        title: "提示",
        content: t.message || "网络错误",
        showCancel: !1
      }) : wx.navigateTo({
        url: "/accountSubpages/pages/account/login/login"
      })
    }))
  },
  handleGetCategoryProductList: function(t) {
    var e = this,
      a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
      i = this.data.pageDataList[t].categoryUid,
      r = {};
    i && (r.categoryUid = i), (0, c.fetch)({
      url: "wxapi/ProductCollect/LoadProduct",
      params: {
        categoryUid: i,
        includeTag: !0,
        includeSale: 365,
        includeUnitName: !0,
        pageIdx: a,
        size: 20
      },
      isShowMessage: !1
    }).then((function(i) {
      if (i) {
        var r, c;
        console.log("reeee", i);
        var s = e.clearProductData(i.data || []),
          u = e.data.pageDataList[t] || {};
        0 == a && (u.data = []), (r = u.data).push.apply(r, n(s)), u.allLoaded = s.length < 20, u.pageIdx = a, e.setData((o(c = {}, "pageDataList[".concat(t, "]"), u), o(c, "tabPageRefresherTriggered[".concat(t, "]"), !1), o(c, "firstLoad[".concat(t, "]"), !1), c), (function() {}))
      } else {
        if ("请先登录会员" == i.message) return void wx.navigateTo({
          url: "/accountSubpages/pages/account/login/login"
        });
        wx.showModal({
          title: "提示",
          content: i.message || "网络错误",
          showCancel: !1
        })
      }
    })).catch((function(a) {
      var i;
      e.setData((o(i = {}, "tabPageRefresherTriggered[".concat(t, "]"), !1), o(i, "firstLoad[".concat(t, "]"), !1), i)), "请先登录会员" != a.message ? wx.showModal({
        title: "提示",
        content: a.message || "网络错误",
        showCancel: !1
      }) : wx.navigateTo({
        url: "/accountSubpages/pages/account/login/login"
      })
    }))
  },
  clearProductData: function(t) {
    var e = this;
    return t.map((function(t) {
      "批发商贸" == s.globalData.industry && void 0 !== t.availableStock ? t.stock = t.availableStock : t.isEnableVirtualStock && (t.stock = t.virtualStock), e.setData({
        isHideUint: 1 == s.getGlobalByKey("_closeAllUnit")
      });
      var a = !1;
      t.productSeries && t.productSeries.length > 0 && (a = t.productSeriesMaxPrice > t.productSeriesMinPrice);
      var i = t.sellPrice.toString().split(".")[0],
        r = t.sellPrice.toString().split(".")[1] || "00",
        o = r.length > 1 ? r : r + "0",
        n = (o ? "." + o : "") + (a ? "起" : "") + (t.unitName && !0 !== e.data.isHideUint ? "/" + t.unitName : "");
      if (t.minQuantity || t.baseQuantity) {
        var c = t.minQuantity || 0,
          u = t.baseQuantity;
        if (c % u != 0 && u)
          if (c > u) {
            for (var l = u; l < c;) l += u;
            t.minSellQuantity = l
          } else t.minSellQuantity = u;
        else t.minSellQuantity = 0 !== c ? c : u
      }
      return {
        id: t.id,
        uid: t.uid,
        productName: t.productDisplayName,
        stock: t.stock,
        productSaleNum: t.productSaleNum || 0,
        productTags: t.productTags && t.productTags.length > 0 ? t.productTags : [],
        unitName: t.unitName && !0 !== e.data.isHideUint ? t.unitName : "",
        sellPrice: t.sellPrice,
        sellPriceInt: i,
        sellPriceFloat: n,
        productOriginalPrice: t.sellPrice2,
        isOutOfStock: t.isOutOfStock,
        isOffShelf: !!t.isOffShelf && t.isOffShelf,
        minSellQuantity: t.minSellQuantity || 0,
        imageName: t.defaultproductimage ? t.defaultproductimage.imagepath.replace("_200x200", "") : "",
        isSeries: !1,
        ignoreStock: t.ignoreStock,
        category: t.category ? t.category.uid : "",
        attribute6: t.attribute6,
        baseQuantity: t.baseQuantity || 1
      }
    }))
  },
  syncCartByTimeout: function() {
    var t = this;
    l && clearTimeout(l), l = setTimeout((function() {
      wx.showLoading({
        mask: !0
      }), u.syncCart((function() {
        t.updateAllItems((function() {
          wx.hideLoading()
        }))
      }), !1, !0)
    }), 500)
  },
  addProduct: function(t) {
    var e = this,
      a = this.data,
      i = a.tabIndex;
    a.pageDataList[i].data.map((function(a) {
      a.id === t.currentTarget.dataset.productid && e.setData({
        _allProductsObj: a
      })
    }));
    var o = t.currentTarget.dataset.productid,
      n = this.data._allProductsObj,
      c = this.data.cartNumberObj,
      s = this.data.isNeadSyncCart,
      l = t.currentTarget.dataset.minsell || 0;
    if (console.log("cartNumberObjcartNumberObj", this.data.cartNumberObj), n.isOffShelf) wx.showModal({
      title: "商品已下架"
    });
    else if (n && !n.isOutOfStock) {
      var d = c[o];
      u.checkAttr(o).then((function(a) {
        if ("1" === a) s && wx.hideLoading(), e.tabToggle(n);
        else {
          var i = null;
          console.log("product", n);
          var g = {
            stock: n.stock,
            categoryUid: n.category.uid,
            ignoreStock: n.ignoreStock,
            uid: n.uid
          };
          if (l > 1 && !d ? i = u.addWithNum(o, l, n.name, n.sellPrice, [], !s, (function() {
              s && wx.hideLoading(), e.triggerEvent("operateCallback")
            }), n.attribute6 || "", r(r({}, g), {}, {
              rejectCb: function(t) {
                s && wx.hideLoading(), e.triggerEvent("operateCallback")
              }
            }), !1) : l > 1 && d && n.baseQuantity ? i = u.addWithNum(o, n.baseQuantity, n.name, n.sellPrice, [], !s, (function() {
              s && wx.hideLoading(), e.triggerEvent("operateCallback")
            }), n.attribute6 || "", r(r({}, g), {}, {
              rejectCb: function(t) {
                s && wx.hideLoading(), e.triggerEvent("operateCallback")
              }
            }), !1) : (console.log("product-3", n), i = u.add(o, n.name, n.sellPrice, [], !s, (function() {
              s && wx.hideLoading(), e.triggerEvent("operateCallback")
            }), n.attribute6 || "", r(r({}, g), {}, {
              rejectCb: function(t) {
                s && wx.hideLoading()
              }
            }), !1)), !i) return;
          d || (c[o] = d);
          var h = n.baseQuantity || 1;
          l > 1 && (0 == d || !d) && (h = l), c[o] || (c[o] = 0), c[o] += h, e.setData({
            cartNumberObj: c
          }), e.triggerEvent("addCartAnimation", t)
        }
      }))
    }
  },
  minusProduct: function(t) {
    var e = this,
      a = this.data,
      i = a.tabIndex;
    a.pageDataList[i].data.map((function(a) {
      a.id === t.currentTarget.dataset.productid && e.setData({
        _allProductsObj: a
      })
    }));
    var r = t.currentTarget.dataset.productid,
      o = this.data._allProductsObj,
      n = this.data.cartNumberObj,
      c = this.data.isNeadSyncCart,
      l = t.currentTarget.dataset.minsell || 0;
    o.isOffShelf ? wx.showModal({
      title: "商品已下架"
    }) : (c && wx.showLoading(), n[r] || (n[r] = 0), n[r] <= 0 || u.checkAttr(r).then((function(t) {
      if ("1" === t && 1 !== n[r]) console.log("open attr view", o), c && wx.hideLoading(), e.tabToggle(o, !0);
      else {
        l > 1 && n[r] == l ? u.minusWithNum(r, l, !c, (function() {
          c && wx.hideLoading(), e.triggerEvent("operateCallback")
        }), !1) : l > 1 && n[r] != l && o.baseQuantity ? u.minusWithNum(r, o.baseQuantity, !c, (function() {
          c && wx.hideLoading(), e.triggerEvent("operateCallback")
        }), !1) : u.minusWithNum(r, 1, !c, (function() {
          c && wx.hideLoading(), e.triggerEvent("operateCallback")
        }), !1);
        var a = o.baseQuantity || 1;
        l > 1 && n[r] == l && (a = l), n[r] = parseFloat(s.floadSub(n[r], a)), n[r] < 0 && (n[r] = 0), e.setData({
          cartNumberObj: n
        }, (function(t) {
          console.log("cartNumberObjcartNumberObj--", n), c && wx.hideLoading()
        }))
      }
    })))
  },
  updateProductNum: function(t) {
    var e = this,
      a = parseFloat(t.detail.value);
    (a < 0 || isNaN(a)) && (a = 1);
    var i = t.currentTarget.dataset.minsell || 0,
      r = this.data.cartNumberObj,
      o = this.data.isNeadSyncCart,
      n = t.currentTarget.dataset.productid,
      c = u.find(null, null, !1),
      s = Object.assign(this.data._allProductsObj[n], c.filter((function(t) {
        return t.ProductId == n
      }))[0]);
    if (a < i && 0 != a && (a = i), s.baseQuantity && a % s.baseQuantity != 0)
      for (; a % s.baseQuantity != 0;) a++;
    wx.showLoading();
    var l = u.findByIdx(s.CartIdx, !1);
    l && l.ProductNum != a ? u.update(l.ProductId, a, l.ProductName, l.SellPrice, !o, (function() {
      wx.hideLoading(), r[n] = a, e.setData({
        cartNumberObj: r
      }), e.triggerEvent("addCartAnimation", t)
    }), l.Specifications, l.CartItemAttributes, void 0, !1) : (wx.hideLoading(), r[n] = a, this.setData({
      cartNumberObj: r
    }))
  },
  cartEventHandler: function(t, e, a) {
    switch (console.log("***product_Shopping", t, e, a), e) {
      case "reload":
        this.updateAllItems()
    }
  },
  updateAllItems: function(t) {
    var e = this.data,
      a = e.pageDataList[e.tabIndex].data,
      i = u.find(null, null, !1),
      r = {},
      o = {},
      n = {};
    console.log("__  updateAllItems   ", i), i.forEach((function(t) {
      t.PackageSerial ? t.PackagePromotionGroupUid && (n[t.PackageSerial] || (n[t.PackageSerial] = 1, o["c" + t.PackagePromotionGroupUid] = (o["c" + t.PackagePromotionGroupUid] || 0) + t.PackageNum)) : r[t.ProductId] = (r[t.ProductId] || 0) + t.ProductNum
    })), console.log("products", a), a.forEach((function(t) {
      var e = 0;
      t.seriesNoSelfIds && t.seriesNoSelfIds.forEach((function(t) {
        r[t] && (e += r[t])
      })), console.log("p.pd", t.id), r[t.id] && (e += r[t.id]), t.cartNum = e, e > 0 && (o[t.id] = e), console.log("cartIdObj", r)
    })), console.log("cartNumberObj——————", o), this.setData({
      cartNumberObj: o
    }, (function() {
      "function" == typeof t && t()
    }))
  },
  goDetail: function(t) {
    var e = t.currentTarget.dataset,
      a = e.id;
    e.isoffshelf ? wx.showModal({
      title: "提示",
      content: "商品已下架",
      showCancel: !1
    }) : a && wx.navigateTo({
      url: "/subPages/shopping/details/details?productid=" + a
    })
  },
  goSearch: function() {
    wx.navigateTo({
      url: "/subPages/myCollect/search/index"
    })
  },
  slideButtonTap: function(t) {
    var e = this,
      a = this.data.tabIndex;
    console.log("daaaa", t);
    var i = t.detail.data.productUid;
    s.authRequest("wxapi/ProductCollect/CancelCollect", {
      productUid: i
    }, (function(t) {
      if (t.successed) e.handleGetCategoryProductList(a);
      else {
        if ("请先登录会员" == t.message) return void wx.navigateTo({
          url: "/accountSubpages/pages/account/login/login"
        });
        wx.showModal({
          title: "提示",
          content: t.message || "网络错误",
          showCancel: !1
        })
      }
    }))
  },
  onLoad: (e = i(a().mark((function t(e) {
    return a().wrap((function(t) {
      for (;;) switch (t.prev = t.next) {
        case 0:
          this.handleGetCategoryList();
        case 1:
        case "end":
          return t.stop()
      }
    }), t, this)
  }))), function(t) {
    return e.apply(this, arguments)
  }),
  onReady: function() {},
  onShow: (t = i(a().mark((function t() {
    return a().wrap((function(t) {
      for (;;) switch (t.prev = t.next) {
        case 0:
        case "end":
          return t.stop()
      }
    }), t)
  }))), function() {
    return t.apply(this, arguments)
  }),
  onHide: function() {},
  onUnload: function() {},
  onPullDownRefresh: function() {},
  onReachBottom: function() {},
  onShareAppMessage: function() {}
});