Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.secondCountdown = void 0;
var e, t, o, n = require("../@babel/runtime/helpers/toConsumableArray"),
  r = (e = 1e3, t = new Set, o = !1, {
    add: function(r) {
      t.add(r),
        function r() {
          o || (o = !0, setTimeout((function() {
            n(t).forEach((function(e) {
              try {
                e()
              } catch (o) {
                t.delete(e)
              }
            })), o = !1, t.size > 0 && r()
          }), e))
        }()
    },
    delete: function(e) {
      t.delete(e)
    }
  });
exports.secondCountdown = r;