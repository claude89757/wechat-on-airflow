Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.selectComponentAsync = function(r, a) {
  var u = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
    i = u.maxAttempts,
    s = void 0 === i ? 50 : i,
    l = u.interval,
    d = void 0 === l ? 100 : l,
    f = u.timeout,
    m = void 0 === f ? 5e3 : f;
  c();
  var g = t(),
    _ = n(),
    p = "".concat(g, "_").concat(_);
  if (e[p] && e[p][a]) {
    var v = e[p][a];
    if (o(r, a, v)) return Promise.resolve(v.component);
    delete e[p][a], 0 === Object.keys(e[p] || {}).length && delete e[p]
  }
  return new Promise((function(o, c) {
    var u = 0,
      i = Date.now(),
      l = null,
      f = !1,
      v = function() {
        null !== l && (clearTimeout(l), l = null)
      };
    ! function h() {
      if (!f) {
        if (u++, Date.now() - i > m) return v(), f = !0, e[p] && (delete e[p][a], 0 === Object.keys(e[p]).length && delete e[p]), void c(new Error("selectComponentAsync timeout: ".concat(a, " not found within ").concat(m, "ms")));
        var C = t(),
          y = n();
        "".concat(C, "_").concat(y);
        if (C !== g || y !== _) return v(), f = !0, e[p] && (delete e[p][a], 0 === Object.keys(e[p]).length && delete e[p]), void c(new Error("selectComponentAsync cancelled: page route or instance changed"));
        try {
          var P = r.selectComponent(a);
          if (P) return v(), f = !0, e[p] || (e[p] = {}), e[p][a] = {
            component: P,
            pageInstanceId: _
          }, void o(P)
        } catch (e) {
          console.warn("selectComponentAsync error on attempt ".concat(u, ":"), e)
        }
        if (u >= s) return v(), f = !0, e[p] && (delete e[p][a], 0 === Object.keys(e[p]).length && delete e[p]), void c(new Error("selectComponentAsync failed: ".concat(a, " not found after ").concat(u, " attempts")));
        f || (l = setTimeout(h, d))
      }
    }()
  }))
}, exports.tableServicesRequire = function() {
  return new Promise((function(e, t) {
    require("../subPages/scanCodeOrder/common/tableServices.js", (function(t) {
      e(t)
    }), (function(e) {
      var t = e.mod,
        n = e.errMsg;
      console.log("__queue__ err path: ".concat(t, ", ").concat(n))
    }))
  }))
};
var e = {};

function t() {
  var e = getCurrentPages();
  return 0 === e.length ? "" : e[e.length - 1].route || ""
}

function n() {
  var e = getCurrentPages();
  if (0 === e.length) return "";
  var t = e[e.length - 1];
  return t && "function" == typeof t.getPageId ? t.getPageId() : (t.__componentCacheId__ || (t.__componentCacheId__ = "page_".concat(Date.now(), "_").concat(Math.random().toString(36).substr(2, 9))), t.__componentCacheId__)
}

function o(e, t, n) {
  if (!n || !n.component) return !1;
  try {
    var o = e.selectComponent(t);
    return !!o && o === n.component
  } catch (e) {
    return !1
  }
}

function c() {
  var t = getCurrentPages(),
    n = new Set;
  t.forEach((function(e, t) {
    var o = e.route || "",
      c = "";
    e && "function" == typeof e.getPageId ? c = e.getPageId() : e.__componentCacheId__ && (c = e.__componentCacheId__), o && c && n.add("".concat(o, "_").concat(c))
  })), Object.keys(e).forEach((function(t) {
    n.has(t) || delete e[t]
  }))
}