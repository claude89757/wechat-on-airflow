var e = require("../@babel/runtime/helpers/objectSpread2"),
  o = require("../modules/store/store-Info"),
  t = o.isWholesaleIndustry,
  n = (o.storeInfoStore, o.isWxChannelsInByStore),
  i = o.isTabletopEntertainmentIndustry,
  r = o.isEquestrianIndustry,
  a = o.isYipeiIndustry;
var s = {};
module.exports = {
  replacePhone: function(e, o) {
    for (var t = [], n = 0; n < e.length; n++) {
      if (o) {
        var i = e[n].phone;
        e[n].phone = i.replace(i.substring(3, 7), "****")
      }
      t[n] = e[n].name + " " + e[n].phone + "\n" + e[n].province + e[n].city + e[n].addr
    }
    return t
  },
  goToAccount: function(e, o) {
    var t = o || "/accountSubpages/pages/account/account/account";
    wx.switchTab({
      url: t,
      fail: function() {
        wx.redirectTo({
          url: t
        })
      }
    }), "Garment" == e || "Tea" == e ? wx.switchTab({
      url: t,
      fail: function() {
        wx.reLaunch({
          url: t
        })
      }
    }) : wx.redirectTo({
      url: t,
      fail: function() {
        wx.reLaunch({
          url: t
        })
      }
    })
  },
  goToOrder: function(e) {
    ! function(e) {
      console.log(e), e && (e.switch ? e.path && wx.switchTab({
        url: e.path
      }) : e.path && wx.navigateTo({
        url: e.path
      }))
    }({
      Garment: {
        switch: !1,
        path: "/subPages/shopping/placeorder/payment"
      },
      Tea: {
        switch: !1,
        path: "/subPages/shopping/placeorder/payment"
      },
      DisplayOrder: {
        switch: !1,
        path: "/subPages/shopping/placeorder/payment"
      },
      FastOrder: {
        switch: !1,
        path: "/subPages/shopping/placeorder/payment"
      },
      Components: {
        switch: !1,
        path: "/subPages/shopping/placeorder/payment"
      },
      Aesthetic: {
        switch: !1,
        path: "/subPages/shopping/placeorder/payment"
      },
      Customize: {
        switch: !1,
        path: "/subPages/shopping/placeorder/payment"
      }
    } [e])
  },
  getObjParams: function(e) {
    return "[object Object]" != Object.prototype.toString.call(e) ? "" : Object.keys(e).map((function(o) {
      return "".concat(o, "=").concat(e[o])
    })).join("&")
  },
  getActiveGiftShowList: function e(o, t, n) {
    for (var i = n ? t[n] : t.CustomerGiftItems, r = 0; r < i.length; r++) {
      var a = i[r],
        s = a.quantity > 1 ? " x " + a.quantity : "";
      switch (a.giftType) {
        case 0:
          o.push("·余额 " + a.quantity + "元");
          break;
        case 1:
          o.push("·积分 " + a.quantity + "分");
          break;
        case 2:
        case 8:
        case 3:
          a.giftInfo && o.push("·" + a.giftInfo.name + s);
          break;
        case 4:
        case 7:
          a.giftInfo && o.push("·" + a.giftInfo.description + s);
          break;
        case 5:
          a.giftInfo && e(o, a.giftInfo, "GiftPackageItems")
      }
    }
    return o
  },
  couponTypeToUrl: function(e, o) {
    console.log("场地优惠券coupon", e);
    var t = "";
    if (!1 === e.promotionRule.forEShop) wx.removeStorageSync("CouponCardDetails"), t = "/accountSubpages/pages/account/couponPromotionCardDetails/couponPromotionCardDetails?uid=" + (e.uidTxt || e.uid);
    else {
      if ([21, 22, 25, 26, 27, 31, 33].indexOf(e.couponType) >= 0) return "/subPages/customize/category?couponGoods=1&ruleUid=".concat(e.promotionRule.txtUid, "&ruleType=").concat(e.promotionRule.type);
      var n = [];
      if (e.promotionCashback && e.promotionCashback.productSelectionRule) {
        if ("venuetimecard" == e.promotionCashback.productSelectionRule.originIncludeType) return "/mpxPackages/sport/pages/venue-time-card-list";
        if ("productTag" == e.promotionCashback.productSelectionRule.originIncludeType) return "/subPages/shopping/shopping/fast";
        n = e.promotionCashback.productSelectionRule.ruleItems.filter((function(e) {
          return 1 == e.includeType
        }))
      } else if (e.promotionproductdiscount && e.promotionproductdiscount.productSelectionRule) {
        if ("productTag" == e.promotionproductdiscount.productSelectionRule.originIncludeType) return "/subPages/shopping/shopping/fast";
        n = e.promotionproductdiscount.productSelectionRule.ruleItems.filter((function(e) {
          return 1 == e.includeType
        }))
      }
      var i = n[0];
      if (i) "category" == i.entityType ? t = "/subPages/shopping/shopping/fast?categoryUid=" + i.entityKeyStr : "product" == i.entityType ? n.length > 1 ? (wx.setStorageSync("couponGoodsUids", n.map((function(e) {
        return {
          uid: e.entityKeyStr
        }
      }))), t = "/subPages/customize/category?couponGoods=1") : t = i.productId && 1 == i.includeType ? a() ? "/trainingSubpages/pages/shopping/details/index?id=" + i.productId : "/subPages/shopping/details/details?productid=" + i.productId : "/subPages/shopping/shopping/fast" : t = "/subPages/shopping/shopping/fast";
      else if ("促销活动优惠券" === e.couponTypeName && e.promotionRule) switch (e.promotionRule.type) {
        case "PromotionCombo":
          t = "/subPages/shopping/combo/combo?productid=c".concat(e.promotioncombogroupTxtId);
          break;
        default:
          t = "/subPages/shopping/shopping/fast"
      } else t = -1 != [32].indexOf(e.couponType) ? "/mpxPackages/sport/pages/venue-booking" : "/subPages/shopping/shopping/fast"
    }
    return t
  },
  checkUseNewOrderStyle: function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
      o = !1,
      t = ["零售行业", "服装鞋帽", "母婴行业", "宠物行业", "烘焙行业", "美业休闲", "生鲜称重", "餐饮行业", "文旅景区", "茶饮行业"];
    return t.indexOf(e) >= 0 && (o = !0), o
  },
  checkLoginByOnShow: function(e) {
    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
      t = arguments.length > 2 ? arguments[2] : void 0,
      n = getApp();
    n.getLoginInfo((function(n) {
      if (n.isLogin) e && e(n);
      else {
        if (t) return void wx.navigateTo({
          url: "/accountSubpages/pages/account/login/login" + o
        });
        wx.showModal({
          title: "提示",
          content: "请先登录",
          showCancel: !0,
          success: function(e) {
            if (e.confirm) wx.navigateTo({
              url: "/accountSubpages/pages/account/login/login" + o
            });
            else {
              var t = getCurrentPages();
              t[t.length - 2] ? wx.navigateBack() : wx.redirectTo({
                url: "/pages/index/index"
              })
            }
          }
        })
      }
    }))
  },
  getCouponTypeInfo: function() {
    var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      t = o.couponTypeName,
      n = {},
      i = ["第二件打折券", "多品特价券", "搭赠券"];
    return !t || i.indexOf(t) >= 0 ? {
      showTypeInfo: !1
    } : (t.indexOf("抵现券") >= 0 ? (n.showSymbol = !0, o.promotionCashback ? (n.titTxt = o.promotionCashback.backAmount, n.titTxtisNum = !0, n.descTxt = o.promotionCashback.requireAmount ? "满".concat(o.promotionCashback.requireAmount, "可用") : null) : n.titTxt = "抵现券") : t.indexOf("打折券") >= 0 ? (n.showDiscount = !0, o.promotionproductdiscount ? (n.titTxt = o.promotionproductdiscount.discount / 10, n.titTxtisNum = !0) : n.titTxt = "打折券") : t.indexOf("提货券") >= 0 ? (n.titTxt = "赠品券", n.descTxt = o.promotionRule && o.promotionRule.maxDiscountableQuantity ? "提货数量".concat(o.promotionRule.maxDiscountableQuantity) : null) : t.indexOf("运费券") >= 0 ? (n.titTxt = "免运费", n.descTxt = o.freeShipping && o.freeShipping.requireAmount ? "满".concat(o.freeShipping.requireAmount, "可用") : null) : t.indexOf("促销活动") >= 0 && (n.titTxt = "促销券", n.descTxt = "活动指定用券"), e(e({}, n), {}, {
      showTypeInfo: !0
    }))
  },
  backLivePage: function() {
    var e = getApp();
    (e.globalData.fromLive || e.globalData.fromReplay) && (e.globalData.fromLive = !1, e.globalData.fromReplay = !1)
  },
  isWholesaleIndustry: t,
  isTabletopEntertainmentIndustry: i,
  isEquestrianIndustry: r,
  isYipeiIndustry: a,
  isWxChannelsIn: n,
  checkPathIn: function(e) {
    var o = e.path,
      t = (e.openType, e.query),
      n = (e.scene, []);
    for (var i in t) n.push(i + "=" + t[i]);
    var r = "/pages/nonactivated/nonactivated?nofindPage=1&path=".concat(encodeURIComponent(o + "?" + n.join("&")));
    return [{
      whiteFirstName: "pages/shopping",
      beforName: "/subPages/shopping/",
      whitelist: ["shopping/fast", "combo/combo", "shoppingcart/shoppingcart", "placeorder/payment", "selfSelectedStores/selfSelectedStores", "details/details", "orderhistory/orderhistory", "orderhistory/order", "orderhistory/orderByDate", "orderhistory/supplier/orderhistory", "orderhistory/supplier/order", "orderhistory/supplier/orderByDate", "orderhistory/supplier/orderConfirm", "share/share", "customerService/customerService", "receipt/receipt", "orderServiceDetails/orderServiceDetails", "commentList/index", "uploadID/uploadID", "crossBorderShoppingTerms/index", "courseDetail/index", "comment-show/details/index", "comment-show/list/index"]
    }].forEach((function(e) {
      if (0 == o.indexOf(e.whiteFirstName)) {
        var t = e.whitelist.find((function(e) {
          return o.indexOf(e) >= 0
        }));
        t && (r = e.beforName + t + "?" + n.join("&"))
      }
    })), r
  },
  checkBeforeAddOrder: function() {
    return new Promise((function(e, o) {
      n() && wx.checkBeforeAddOrder ? wx.checkBeforeAddOrder({
        success: function(o) {
          console.log("checkBeforeAddOrder success", o), e(o.data)
        },
        fail: function(o) {
          console.log("checkBeforeAddOrder fail", o), e({})
        }
      }) : e({})
    }))
  },
  queryStringFormat: function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
      o = {};
    return e.split("&").forEach((function(e) {
      var t = e.split("=");
      o[t[0]] = t[1]
    })), o
  },
  autoChargeGetRule: function(o, t) {
    var n = function(e) {
        var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return Number(e.toFixed(o))
      },
      i = o.filter((function(e) {
        return Number((t * (e.RequireAmountRate / 100)).toFixed(0)) >= e.ChargeAmount
      })).map((function(o) {
        var i, r = o.RequireAmountRate,
          a = o.GiftAmountRate,
          s = void 0 === a ? 0 : a,
          c = o.GiftPointRate,
          u = void 0 === c ? 0 : c,
          p = u > 0 ? n(t * (u / 100), 2) : 0,
          l = s > 0 ? n(t * (s / 100), 2) : 0;
        return null !== (i = o.GiftItems) && void 0 !== i && i.length && o.GiftItems.forEach((function(e) {
          0 == e.GiftType && (e.GiftAmount = l), 2 == e.GiftType && (e.GiftPoint = p)
        })), e(e({}, o), {}, {
          GiftAmount: l,
          GiftPoint: p,
          ChargeAmount: n(t * (r / 100)),
          GiftType: u > 0 ? 2 : 0
        })
      }));
    return i.sort((function(e, o) {
      return Math.abs(e.ChargeAmount - t) - Math.abs(o.ChargeAmount - t)
    })), i
  },
  openAgreementPreview: function(e) {
    function o(e) {
      wx.openDocument({
        filePath: e,
        success: function(e) {
          console.log("打开文档成功")
        },
        fail: function(e) {
          console.log("协议打开失败了", e)
        }
      })
    }
    e && (s[e] ? o(s[e]) : wx.downloadFile({
      url: e,
      success: function(t) {
        var n = t.tempFilePath;
        s[e] = n, o(s[e])
      },
      fail: function(e) {
        console.log("文件下载失败", e)
      }
    }))
  },
  groupBy: function(e, o) {
    if (!Array.isArray(e)) throw new TypeError("第一个参数必须是数组");
    if ("function" != typeof o) throw new TypeError("第二个参数必须是函数");
    return e.reduce((function(e, t, n) {
      var i = o(t, n);
      return e[i] || (e[i] = []), e[i].push(t), e
    }), {})
  },
  businessCouponCallBack: function(e) {
    if (1038 === e.scene) {
      var o = e.referrerInfo,
        t = o.appId,
        n = o.extraData;
      if ("wxe2f280194b94c0aa" === t || "wx3e9c2672ad37eb4b" === t) {
        console.log("appId: ", t);
        var i = n.action,
          r = n.productPath,
          a = n.source;
        console.log("用户动作: ", i), console.log("商品 path: ", r), console.log("来源：", a), "receiveProductCouponComponent" === a && r && wx.navigateTo({
          url: r,
          fail: function(e) {
            console.log("navigateTo fail: ", e), wx.reLaunch({
              url: r
            })
          }
        })
      }
    }
  }
};