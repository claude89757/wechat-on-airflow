Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.checkNumberInput = exports.antiCheckNumberInput = void 0;
var e = function(e, t) {
    return t ? Number.parseFloat(e) : Number.parseInt(e)
  },
  t = function(e, t, r) {
    return !Number.isNaN(e) && e >= t && e <= r
  };
exports.checkNumberInput = function(r, n) {
  var u = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
    o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : Number.MAX_VALUE,
    i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
    c = e(r, i);
  t(c, u, o) && n(c)
};
exports.antiCheckNumberInput = function(r, n, u) {
  var o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
    i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : Number.MAX_VALUE,
    c = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
    p = e(r, c);
  t(p, o, i) || u(n)
};