var n = {},
  e = function(e) {
    if (!e) return !1;
    if (!e.tg) return console.error("事件监听未设置目标对象   属性key=tg"), !1;
    if (e.name && n[e.name]) n[e.name] = n[e.name].filter((function(n) {
      return n[0] != e.tg
    }));
    else
      for (var r in n) n[r] = n[r].filter((function(n) {
        return n[0] != e.tg
      }))
  },
  r = function(n) {
    if (n.onUnload) {
      var r = n.onUnload;
      n.onUnload = function(n) {
        r.call(this, n), e({
          tg: this
        })
      }
    } else n.onUnload = function() {
      e({
        tg: this
      })
    }
  };
exports.$on = function(e) {
  if (!e) return !1;
  if (!e.name) return console.error("事件监听未设置名称 属性key=name"), !1;
  if (!e.success) return console.error("事件监听未设置回调函数 属性key=success"), !1;
  if (!e.tg) return console.error("事件监听未设置目标对象   属性key=tg"), !1;
  n[e.name] ? n[e.name].push([e.tg, e.success]) : n[e.name] = [
    [e.tg, e.success]
  ];
  r(e.tg)
}, exports.$emit = function(e) {
  if (!e) return !1;
  if (!e.name) return console.error("事件发送未设置名称 属性key=name"), !1;
  n[e.name] && n[e.name].forEach((function(n) {
    n[1].call(n[0], e.data)
  }))
}, exports.$remove = e;