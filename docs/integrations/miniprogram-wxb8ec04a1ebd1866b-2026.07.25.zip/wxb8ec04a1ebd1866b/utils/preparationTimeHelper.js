Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.formatPreparationTagByMinTime = m, exports.formatPreparationTagText = u, exports.getDayModeReservationOffset = o, exports.getPreparationBusinessTimesFromStoreInfo = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  return {
    storeBusinessTimes: T(e.storeBusinessTimes, e.StoreBusinessTimes),
    bizTimes: T(e.bizTimes, e.BizTimes)
  }
}, exports.getPreparationModeIndex = p, exports.getPreparationTagDisplayText = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = e.preparationTime,
    t = void 0 === i ? 0 : i,
    n = e.preparationTimeUnit,
    a = void 0 === n ? 0 : n,
    s = e.typeSelectedIndex,
    u = void 0 === s ? 0 : s,
    d = e.shippingRule,
    l = void 0 === d ? {} : d,
    p = e.storeBusinessTimes,
    v = void 0 === p ? [] : p,
    T = e.bizTimes,
    c = void 0 === T ? [] : T,
    g = e.nowTime,
    f = void 0 === g ? new Date : g,
    b = Number(t || 0);
  if (b <= 0) return "";
  var h = Number(0 === u ? l.earliestReservationDay || 0 : l.selfTakeEarliestReservationDay || 0),
    R = new Date(f);
  if (1 === Number(a || 0)) {
    var A = o({
        preparationTime: b,
        preparationTimeUnit: a,
        earliestReservationDay: h
      }),
      I = r.default.addDays(R, A),
      z = y({
        date: I,
        shippingRule: l,
        storeBusinessTimes: v,
        bizTimes: c,
        typeSelectedIndex: u
      });
    if (!z.length) return "";
    var M = D(I, z);
    return m({
      minAppointmentTime: M,
      preparationTimeUnit: a,
      typeSelectedIndex: u,
      nowTime: R
    })
  }
  var N = new Date(R);
  if (h > 0) {
    var w = r.default.addDays(R, h),
      k = y({
        date: w,
        shippingRule: l,
        storeBusinessTimes: v,
        bizTimes: c,
        typeSelectedIndex: u
      });
    N = D(w, k)
  }
  var U = null,
    P = y({
      date: R,
      shippingRule: l,
      storeBusinessTimes: v,
      bizTimes: c,
      typeSelectedIndex: u
    }),
    O = S(R, P),
    q = r.default.addMinutes(R, b),
    H = 1 === Number(u) && 1 === Number(l.selfTakeAvailableTimeMode || 0) && Array.isArray(l.selfTakeAvailableTimes) && l.selfTakeAvailableTimes.length > 0;
  if (1 === Number(u) && h <= 0 && !H && O && R <= O && q > O) {
    var E = x({
      date: R,
      shippingRule: l,
      storeBusinessTimes: v,
      bizTimes: c,
      typeSelectedIndex: u
    });
    if (E) {
      var F = y({
          date: E,
          shippingRule: l,
          storeBusinessTimes: v,
          bizTimes: c,
          typeSelectedIndex: u
        }),
        _ = S(E, F),
        j = r.default.addMinutes(E, b);
      U = _ && j <= _ ? j : B({
        startTime: N,
        minutes: b,
        shippingRule: l,
        storeBusinessTimes: v,
        bizTimes: c,
        typeSelectedIndex: u
      })
    }
  } else U = B({
    startTime: N,
    minutes: b,
    shippingRule: l,
    storeBusinessTimes: v,
    bizTimes: c,
    typeSelectedIndex: u
  });
  return m({
    minAppointmentTime: U,
    preparationTimeUnit: a,
    typeSelectedIndex: u,
    nowTime: R
  })
}, exports.getProductPreparationTag = function() {
  var e, i, t, n, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    a = r.item,
    o = void 0 === a ? {} : a,
    s = r.shippingRule,
    d = void 0 === s ? {} : s,
    l = r.modeValue,
    m = void 0 === l ? "" : l;
  if (!v(d, m)) return "";
  var T = p(m);
  if (2 === T) return "";
  var c = Number(null !== (e = null !== (i = o.preparationTime) && void 0 !== i ? i : o.PreparationTime) && void 0 !== e ? e : 0),
    g = Number(null !== (t = null !== (n = o.preparationTimeUnit) && void 0 !== n ? n : o.PreparationTimeUnit) && void 0 !== t ? t : 0);
  if (c <= 0) return "";
  var f = Number(0 === T ? d.earliestReservationDay || 0 : d.selfTakeEarliestReservationDay || 0);
  return u({
    preparationTime: c,
    preparationTimeUnit: g,
    earliestReservationDay: f,
    typeSelectedIndex: T
  })
}, exports.normalizePreparationTime = a, exports.shouldUseProductPreparationTime = v;
var e, i = require("../@babel/runtime/helpers/createForOfIteratorHelper"),
  t = require("../@babel/runtime/helpers/toConsumableArray"),
  n = require("../@babel/runtime/helpers/slicedToArray"),
  r = (e = require("./utilDate.js")) && e.__esModule ? e : {
    default: e
  };

function a() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = e.preparationTime,
    t = void 0 === i ? 0 : i,
    n = e.preparationTimeUnit,
    r = void 0 === n ? 0 : n,
    a = Number(t || 0),
    o = 1 === Number(r || 0) ? 1 : 0;
  return {
    amount: a,
    unit: o,
    isByDay: 1 === o,
    isByMinute: 1 !== o
  }
}

function o() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = e.preparationTime,
    t = void 0 === i ? 0 : i,
    n = e.preparationTimeUnit,
    r = void 0 === n ? 0 : n,
    o = e.earliestReservationDay,
    s = void 0 === o ? 0 : o,
    u = a({
      preparationTime: t,
      preparationTimeUnit: r
    }),
    d = u.amount,
    l = u.isByDay,
    m = Number(s || 0);
  return l ? Math.max(d, m) : m
}

function s() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
    i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
    t = Number(e || 0),
    n = Math.floor(t / 60),
    r = t % 60;
  return n > 0 && r > 0 ? "".concat(n, "小时").concat(r, "分钟后").concat(i) : n > 0 ? "".concat(n, "小时后").concat(i) : "".concat(r, "分钟后").concat(i)
}

function u() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = e.preparationTime,
    t = void 0 === i ? 0 : i,
    n = e.preparationTimeUnit,
    r = void 0 === n ? 0 : n,
    u = e.earliestReservationDay,
    d = void 0 === u ? 0 : u,
    l = e.typeSelectedIndex,
    m = void 0 === l ? 0 : l,
    p = a({
      preparationTime: t,
      preparationTimeUnit: r
    }),
    v = p.amount,
    T = p.isByDay;
  if (v <= 0) return "";
  var c = 0 === Number(m) ? "配送" : "自提";
  if (T) {
    var g = o({
      preparationTime: v,
      preparationTimeUnit: r,
      earliestReservationDay: d
    });
    return "最快".concat(g, "天").concat(c)
  }
  return s(v, c)
}

function d() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
  return 0 === Number(e) ? "配送" : "自提"
}

function l() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date,
    i = new Date(e);
  i.setHours(0, 0, 0, 0);
  var t = i.getDay(),
    n = 0 === t ? 6 : t - 1;
  return i.setDate(i.getDate() - n), i
}

function m() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = e.minAppointmentTime,
    t = e.preparationTimeUnit,
    n = void 0 === t ? 0 : t,
    r = e.typeSelectedIndex,
    a = void 0 === r ? 0 : r,
    o = e.nowTime,
    s = void 0 === o ? new Date : o;
  if (!i) return "";
  var u = new Date(i),
    m = new Date(s),
    p = d(a),
    v = Number(n || 0);
  if (1 !== v) {
    var T = "".concat(String(u.getHours()).padStart(2, "0"), ":").concat(String(u.getMinutes()).padStart(2, "0"));
    return "最快".concat(T).concat(p)
  }
  var c = new Date(m);
  c.setHours(0, 0, 0, 0);
  var g = new Date(u);
  g.setHours(0, 0, 0, 0);
  var f = Math.round((g - c) / 864e5);
  if (1 === f) return "明天可".concat(p);
  if (2 === f) return "后天可".concat(p);
  var b = l(c),
    y = new Date(b);
  if (y.setDate(y.getDate() + 6), g >= b && g <= y) {
    var h = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
    return "".concat(h[g.getDay()], "可").concat(p)
  }
  return c.getFullYear() === g.getFullYear() && c.getMonth() === g.getMonth() ? "".concat(g.getDate(), "号可").concat(p) : "".concat(g.getMonth() + 1, "月").concat(g.getDate(), "号可").concat(p)
}

function p() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
    i = {
      package: 0,
      "RegularOrder|package": 0,
      takeout: 1,
      pickedUpInStores: 1,
      queue: 1,
      localOrder: 2
    };
  return "number" == typeof i[e] ? i[e] : 0
}

function v() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
    t = p(i);
  return 0 === t ? 2 !== Number(e.preparationTimeMode || 0) : 1 === t && 2 !== Number(e.selfTakePreparationTimeMode || 0)
}

function T(e, i) {
  return Array.isArray(e) && e.length > 0 ? e : Array.isArray(i) && i.length > 0 ? i : Array.isArray(e) ? e : []
}

function c() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
  return e.map((function(e) {
    var i = String(e || "").split("|"),
      t = n(i, 2);
    return {
      begin: t[0],
      end: t[1]
    }
  })).filter((function(e) {
    return e.begin && e.end
  }))
}

function g() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new Date;
  return e.filter((function(e) {
    return void 0 === e.dayOfWeek || Number(e.dayOfWeek) === i.getDay()
  })).map((function(e) {
    return {
      begin: e.beginTime || e.begin,
      end: e.endTime || e.end
    }
  })).filter((function(e) {
    return e.begin && e.end
  }))
}

function f() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = e.date,
    t = e.storeBusinessTimes,
    n = void 0 === t ? [] : t,
    r = e.bizTimes,
    a = void 0 === r ? [] : r;
  return Array.isArray(n) && n.length > 0 ? g(n, i) : Array.isArray(a) && a.length > 0 ? a.map((function(e) {
    return {
      begin: e.begin,
      end: e.end
    }
  })) : [{
    begin: "00:00:00",
    end: "23:59:59"
  }]
}

function b() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
    t = [];
  return e.forEach((function(e) {
    i.forEach((function(i) {
      var n = String(e.begin) > String(i.begin) ? e.begin : i.begin,
        r = String(e.end) < String(i.end) ? e.end : i.end;
      String(n) < String(r) && t.push({
        begin: n,
        end: r
      })
    }))
  })), h(t)
}

function y() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    i = e.date,
    t = e.shippingRule,
    n = void 0 === t ? {} : t,
    r = e.storeBusinessTimes,
    a = void 0 === r ? [] : r,
    o = e.bizTimes,
    s = void 0 === o ? [] : o,
    u = e.typeSelectedIndex,
    d = void 0 === u ? 0 : u,
    l = f({
      date: i,
      storeBusinessTimes: a,
      bizTimes: s
    });
  if (1 === d && 1 === Number(n.selfTakeAvailableTimeMode || 0) && Array.isArray(n.selfTakeAvailableTimes) && n.selfTakeAvailableTimes.length > 0) {
    var m = c(n.selfTakeAvailableTimes),
      p = b(m, l);
    return p
  }
  return l
}

function h() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
  return t(e).sort((function(e, i) {
    return String(e.begin).localeCompare(String(i.begin))
  }))
}

function D(e) {
  var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
    t = h(i);
  return t.length ? r.default.setTimeDate(e, t[0].begin) : new Date(e)
}

function S(e) {
  var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
    t = h(i);
  return t.length ? t.reduce((function(i, t) {
    var n = r.default.setTimeDate(e, t.begin),
      a = r.default.setTimeDate(e, t.end);
    return n > a && (a = r.default.addDays(a, 1)), !i || a > i ? a : i
  }), null) : null
}

function x() {
  for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = e.date, t = e.shippingRule, n = void 0 === t ? {} : t, a = e.storeBusinessTimes, o = void 0 === a ? [] : a, s = e.bizTimes, u = void 0 === s ? [] : s, d = e.typeSelectedIndex, l = void 0 === d ? 0 : d, m = r.default.addDays(i, 1), p = 0; p < 14;) {
    var v = y({
      date: m,
      shippingRule: n,
      storeBusinessTimes: o,
      bizTimes: u,
      typeSelectedIndex: l
    });
    if (v.length > 0) return D(m, v);
    m = r.default.addDays(m, 1), p += 1
  }
  return null
}

function B() {
  for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.startTime, n = e.minutes, a = void 0 === n ? 0 : n, o = e.shippingRule, s = void 0 === o ? {} : o, u = e.storeBusinessTimes, d = void 0 === u ? [] : u, l = e.bizTimes, m = void 0 === l ? [] : l, p = e.typeSelectedIndex, v = void 0 === p ? 0 : p, T = new Date(t), c = Number(a || 0), g = 0; g < 60;) {
    var f, b = h(y({
        date: T,
        shippingRule: s,
        storeBusinessTimes: d,
        bizTimes: m,
        typeSelectedIndex: v
      })),
      D = i(b);
    try {
      for (D.s(); !(f = D.n()).done;) {
        var S = f.value,
          B = r.default.setTimeDate(T, S.begin),
          R = r.default.setTimeDate(T, S.end);
        if (B > R && (B = r.default.setTimeDate(T, "00:00:00")), T < B && (T = B), T >= B && T <= R) {
          var A = Math.floor((R - T) / 6e4);
          if (c <= A) return r.default.addMinutes(T, c);
          c -= A;
          var I = x({
            date: T,
            shippingRule: s,
            storeBusinessTimes: d,
            bizTimes: m,
            typeSelectedIndex: v
          });
          if (!I) return null;
          T = I;
          break
        }
      }
    } catch (e) {
      D.e(e)
    } finally {
      D.f()
    }
    var z = b.some((function(e) {
      var i = r.default.setTimeDate(T, e.begin),
        t = r.default.setTimeDate(T, e.end);
      return T >= i && T <= t
    }));
    if (!z) {
      var M = x({
        date: T,
        shippingRule: s,
        storeBusinessTimes: d,
        bizTimes: m,
        typeSelectedIndex: v
      });
      if (!M) return null;
      T = M
    }
    g += 1
  }
  return T
}