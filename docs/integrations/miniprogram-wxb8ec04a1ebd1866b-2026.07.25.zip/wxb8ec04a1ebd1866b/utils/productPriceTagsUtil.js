Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.awaitCatch = void 0, exports.buildPromotionGiftCartItems = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    r = e.product,
    t = e.quantity,
    o = void 0 === t ? 1 : t,
    i = e.rule,
    n = e.giftProducts,
    a = void 0 === n ? [] : n,
    c = e.shopItemAttrs,
    s = void 0 === c ? [] : c,
    l = e.giftAttrsMap,
    d = void 0 === l ? {} : l,
    f = (+new Date).toString(),
    g = function(e) {
      var r, t, o, i;
      return {
        ProductId: e.id || e.ProductId,
        ProductName: e.name || e.ProductName || e.productDisplayName,
        SellPrice: e.sellPrice || e.SellPrice || 0,
        ProductSellPrice: e.productOriginalPrice || e.ProductSellPrice || e.sellPrice || e.SellPrice || 0,
        ProductUid: U(e),
        categoryUid: (null === (r = e.category) || void 0 === r ? void 0 : r.uid) || e.categoryUid || "",
        Stock: e.stock || e.Stock || 0,
        IgnoreStock: e.ignoreStock || e.IgnoreStock || !1,
        CartItemAttributes: e.shopItemAttrs || e.CartItemAttributes || [],
        Specifications: e.attribute6 || e.Specifications || "",
        ImageName: (null === (t = e.defaultproductimage) || void 0 === t ? void 0 : t.imagepath) || e.imagepath || e.productImage || e.ImageName || "",
        imagepath: e.imagepath || (null === (o = e.defaultproductimage) || void 0 === o ? void 0 : o.imagepath) || "",
        productImage: e.productImage || e.imagepath || (null === (i = e.defaultproductimage) || void 0 === i ? void 0 : i.imagepath) || ""
      }
    },
    h = u(u({}, g(r)), {}, {
      ProductNum: o,
      CartItemAttributes: s || []
    });
  i && (h.GiftPromotionUid = i.ruleUid, h.IsGiftPromotionRequire = !0, h.GiftPromotionBatchUid = f);
  var m = [h];
  return i ? (a.forEach((function(e) {
    var r = U(e);
    m.push(u(u({}, g(e)), {}, {
      ProductNum: e.giftNum || e.ProductNum || 1,
      CartItemAttributes: d[r] || e.shopItemAttrs || [],
      GiftPromotionUid: i.ruleUid,
      IsGiftPromotionGift: !0,
      GiftPromotionBatchUid: f
    }))
  })), m) : m
}, exports.checkProductByModeCantPay = exports.checkHideProductByMode = void 0, exports.checkProductHasGift = function(e) {
  var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
  if (D()) return null;
  var t = null,
    o = y[e],
    i = [];
  r.forEach((function(e) {
    y[e] && i.push.apply(i, n(y[e]))
  })), i && i.length > 0 ? t = i : o && o[0] && o[0].isGiftSelf && (t = o);
  return t
}, exports.checkShoppingCartHasGfitPromes = function(e) {
  if (D()) return {
    promotionGiftTotal: 0,
    giftProducts: []
  };
  var r = [],
    t = [],
    o = {},
    i = [];
  e.forEach((function(e) {
    return !e.excluded && i.unshift(e)
  })), e.filter((function(e) {
    return !e.excluded && e.IsGiftPromotionGift && e.GiftPromotionBatchUid
  })).forEach((function(e) {
    !t.some((function(r) {
      return r.cartId == e.CartItemId
    })) && t.push({
      uid: e.ProductUid,
      cartId: e.CartItemId,
      giftNum: Number(e.ProductNum || 0),
      name: e.ProductName,
      sellPrice: Number(e.SellPrice || 0)
    })
  }));
  var n = function(e, o) {
    r.push(e);
    var n = {};
    e.gifts.forEach((function(e) {
      var r = 0;
      i.filter((function(r) {
        return r.ProductUid == e.ProductUidTxt
      })).forEach((function(i) {
        e.Count - r > 0 && !n["".concat(o, "_").concat(i.CartItemId)] && (!t.some((function(e) {
          return e.cartId == i.CartItemId
        })) && t.push({
          uid: e.ProductUidTxt,
          cartId: i.CartItemId,
          giftNum: Math.min(e.Count - r, i.ProductNum),
          name: i.ProductName,
          sellPrice: i.SellPrice
        }), n["".concat(o, "_").concat(i.CartItemId)] = !0, r += i.ProductNum)
      }))
    }))
  };
  e.filter((function(e) {
    return !e.isPackageSerial || !0 === e.excluded
  })).forEach((function(e) {
    var r = y[e.ProductUid] || [];
    e.GiftPromotionUid && (r = r.filter((function(r) {
      return r.ruleUid == e.GiftPromotionUid
    }))), r.forEach((function(r) {
      var t = "".concat(r.ruleUid, "_").concat(r.ruleBusUid, "_").concat(e.CartItemId);
      r && e.ProductTotalNum >= r.num && !o[t] && (o[t] = !0, r.isGiftSelf ? e.ProductTotalNum >= r.num + r.gifts.reduce((function(e, r) {
        return e + r.Count
      }), 0) && n(r, t) : n(r, t))
    }))
  }));
  var u = 0;
  t.length > 0 && (u = t.reduce((function(e, r) {
    return e + r.sellPrice * r.giftNum
  }), u));
  var a = {};
  return t.forEach((function(e) {
    a[e.cartId] = {
      giftNum: e.giftNum,
      name: e.name
    }
  })), {
    promotionGiftTotal: u,
    giftProducts: t,
    giftsMap: a
  }
}, exports.clearPrivilegePriceCache = void 0, exports.detailsSaleStockControl = function() {
  var e = f.storeInfoStore.get("rawData"),
    r = e.IsShowSaleAmount,
    t = e.IsShowStock,
    o = e.Industry,
    i = d.preferenceSettingStore.get("rawData"),
    n = i._hideDetailViewSale,
    u = i._hideDetailViewStock;
  return {
    isShowSaleAmount: !0 === r || 0 == n,
    showStock: (!0 === t || 0 == u) && "服装鞋帽" !== o
  }
}, exports.discountPriceTags = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    r = arguments.length > 1 ? arguments[1] : void 0,
    t = null,
    o = d.preferenceSettingStore.get("rawData"),
    i = null,
    n = r.sellPrice;
  if (r && r.productSeries) {
    var u = void 0 !== r.nextCategorySellPrice ? r.nextCategorySellPrice : r.sellPrice,
      a = -1;
    r.productSeries.forEach((function(e, r) {
      u > e.nextCategorySellPrice && (u = e.nextCategorySellPrice, a = r)
    })), a > -1 && r.sellPrice > u && (e = r.productSeries[a].discounts || [], r.nextCategorySellPrice = r.productSeries[a].nextCategorySellPrice, n = r.productSeries[a].sellPrice)
  }
  if (e && e.length > 0) {
    if (e.some((function(e) {
        return [1, 2, 3, 4, 5, 6].includes(e.discType)
      }))) {
      t = e.some((function(e) {
        return [3, 4].includes(e.discType)
      })) ? f.storeInfoStore.get("rawData").IsCustomerBalanceConsume ? "会员储值价" : "会员价" : "促销价", e.some((function(e) {
        return e.forCustomer && e.discType < 3
      })) && g.userInfoStore.get("isLogin") && "会员储值价" != t && (t = "会员促销价");
      var c = e.find((function(e) {
        return !!e.paymethods
      }));
      if (c && c.paymethods) {
        var s = c.paymethods.split(","),
          l = s.every((function(e) {
            return ["2", "7", "19", "48"].indexOf(e) >= 0
          })) && s.some((function(e) {
            return ["2", "7"].indexOf(e) >= 0
          }));
        l && (t = "储值促销价")
      }
    }
    var m = e.find((function(e) {
        return [7, 8].includes(e.discType)
      })),
      p = {};
    if (m) {
      r.nextCategorySellPrice ? p.price = (0, h.formatFloat)(r.nextCategorySellPrice) : 7 == m.discType ? p.price = (0, h.formatFloat)(r.productOriginalPrice * (m.discValue / 100)) : p.price = (0, h.formatFloat)(m.discValue);
      var S = C();
      p.nextUid = v(S), p.nextName = !0 === r.notShortenName ? v(S, 1) : P(v(S, 1)), n > p.price && (i = p)
    }
    e.some((function(e) {
      return "PromotionWeworkFriendDiscount" == e.promotionType
    })) && (t = "好友价");
    var x = o._customizeTag || {},
      y = {
        _showDepositPromotionPrice: "储值促销价",
        _showMemberPromotionPrice: "会员促销价",
        _showPromotionPrice: "促销价",
        _showMemberDepositPrice: "会员储值价",
        _showMemberPrice: "会员价",
        _showPrivilegeCardPrice: "权益卡专享价"
      },
      I = Object.keys(y).find((function(e) {
        return y[e] === t
      })),
      b = I ? x[I] : void 0,
      w = t ? x[t] : "";
    t && I && "0" === b && (t = ""), t && x && "0" !== b && w && (t = w), 1 == o._hideCustomTag && (t = "")
  }
  r && r.productOriginalPrice <= r.sellPrice && (t = null);
  return {
    priceTagsTxt: t,
    nextCustomerTag: i
  }
}, exports.getPrivilegePriceByProUid = exports.getDisplayPrivilegeName = exports.getCustomPrivilegeCardUid = exports.getCustomPrivilegeCardId = void 0, exports.getPromotionGiftProductUids = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    r = {};
  return e.forEach((function(e) {
    (e.gifts || e.giftItems || []).forEach((function(e) {
      var t = String(e.ProductUidTxt || "");
      t && (r[t] = !0)
    }))
  })), Object.keys(r)
}, exports.getPromotionGiftRulesByProduct = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  if (D()) return [];
  var r = [U(e)];
  Array.isArray(e.productSeries) && e.productSeries.forEach((function(e) {
    var t = U(e);
    t && r.push(t)
  }));
  e.pUids && String(e.pUids).split("|").forEach((function(e) {
    return e && r.push(e)
  }));
  var t = [],
    o = {};
  return r.filter(Boolean).forEach((function(e) {
    (y[String(e)] || []).forEach((function(e) {
      var r = "".concat(e.ruleUid, "_").concat(e.ruleBusUid, "_").concat(e.buyProductUid);
      o[r] || (o[r] = !0, t.push(e))
    }))
  })), t
}, exports.getPromotionGiftRulesByProductUid = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
    t = String(r || "");
  return t ? e.filter((function(e) {
    return String(e.buyProductUid || "") == t
  })) : []
}, exports.getRecommendDiscountAllData = function() {
  var e = d.preferenceSettingStore.get("rawData"),
    r = null;
  2 == e._showRecommendDiscount && e._recommendDiscount ? r = e._recommendDiscount : 1 == e._showRecommendDiscount && m && (r = m);
  var t = {};
  for (var o in r) {
    var i = r[o],
      n = i.substring(0, i.search("-"));
    t[n] = n
  }
  0 == Object.keys(t).length && (t = null);
  return t
}, exports.getRecommendDiscountParams = C, exports.hasPrivilegePriceShow = exports.hasPrivilegeCardInSelf = exports.getShopActiveModeNum = void 0, exports.loadCustomerAutoUpgradeRules = function() {
  1 == d.preferenceSettingStore.get("rawData")._showRecommendDiscount && (0, s.fetch)({
    url: "wxapi/CustomerCategory/LoadAutoUpgradeRules",
    params: {},
    isShowLoading: !1,
    isShowMessage: !1
  }).then((function(e) {
    if (e && e.rules && 0 != e.rules.length) {
      var r = e.rules.filter((function(e) {
        return e.value
      }));
      r.sort((function(e, r) {
        return e.value - r.value
      })), m = {}, r.forEach((function(e, t) {
        var o = r[t + 1];
        0 == t && (m[-1] = e.categoryUidTxt + "-" + e.categoryName), o && (m[e.categoryUidTxt] = o.categoryUidTxt + "-" + o.categoryName)
      }))
    }
  }));
  (0, s.fetch)({
    url: "wxapi/store/LoadDefaultCustomerCategory",
    params: {},
    isShowLoading: !1,
    isShowMessage: !1
  }).then((function(e) {
    e && e.category && (p = e.category, d.preferenceSettingStore.get("rawData")._unLoginDefaultCategoryName && (p.name = d.preferenceSettingStore.get("rawData")._unLoginDefaultCategoryName))
  }))
}, exports.loadPrivilegePriceByProUids = void 0, exports.loadPromotionGiftInfo = function() {
  if (D()) return Promise.resolve(y);
  var e = (0, l.getStoreId)();
  if (I == e && Object.keys(y).length > 0) return Promise.resolve(y);
  if (I == e && b) return b;
  return I = e, b = (0, c.LoadPromotions)({
    promotionTypes: ["PromotionGift"],
    ignoreCustomer: !0,
    pageSize: 50,
    pageIndex: 0
  }).then((function(e) {
    var r = Array.isArray(e.rules) ? e.rules : [];
    return function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
      Object.keys(y).forEach((function(e) {
        return delete y[e]
      })), e.filter((function(e) {
        var r;
        return 0 == e.GiftType && 1 == (null === (r = e.BuyProductUidCountPairs) || void 0 === r ? void 0 : r.length) && 1 == e.ForEShop && !0 !== e.NeedCoupon && !0 !== e.HasCouponInfo
      })).forEach((function(e) {
        e.BuyProductUidCountPairs.forEach((function(r) {
          var t = String(w(r));
          if (t) {
            var o = N(e, r);
            y[t] ? y[t].push(o) : y[t] = [o]
          }
        }))
      }))
    }(r), console.log("搭赠 促销规则。", r, y), b = null, y
  })).catch((function(e) {
    return b = null, console.log("搭赠促销规则加载失败", e), y
  }))
}, exports.matchPromotionGiftRules = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
    t = Number(r) || 1;
  return e.map((function(e) {
    var r = Number(e.num || e.buyCount || 0);
    if (r <= 0) return null;
    var o = Math.floor(t / r);
    if (t % r != 0 && t / r <= 1) return null;
    if (o <= 0) return null;
    var i = Number(e.limitTimes || 0),
      n = i > 0 ? Math.min(o, i) : o;
    return u(u({}, e), {}, {
      multiple: n,
      giftItems: (e.gifts || e.giftItems || []).map((function(e) {
        return u(u({}, e), {}, {
          Count: Number(e.Count || 0) * n
        })
      }))
    })
  })).filter(Boolean)
}, exports.showNextCustomerPriceTags = function() {
  return 0 != d.preferenceSettingStore.get("rawData")._showRecommendDiscount
}, exports.showProductShopModeTips = void 0;
var e = require("../@babel/runtime/helpers/regeneratorRuntime"),
  r = require("../@babel/runtime/helpers/slicedToArray"),
  t = require("../@babel/runtime/helpers/asyncToGenerator"),
  o = require("../@babel/runtime/helpers/classCallCheck"),
  i = require("../@babel/runtime/helpers/createClass"),
  n = require("../@babel/runtime/helpers/toConsumableArray"),
  u = require("../@babel/runtime/helpers/objectSpread2");
require("../@babel/runtime/helpers/Arrayincludes");
var a = require("../@babel/runtime/helpers/typeof"),
  c = require("../modules/server/api"),
  s = require("../modules/server/fetch"),
  l = require("../modules/store/app"),
  d = require("../modules/store/preference-setting"),
  f = require("../modules/store/store-Info"),
  g = require("../modules/store/user-info"),
  h = require("./utilMoney"),
  m = null,
  p = null,
  v = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
      r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
    return [e.substring(0, e.search("-")), e.substring(e.search("-") + 1)][r]
  },
  P = function() {
    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = 0, t = e.length, o = -1, i = 3, n = 0; n < t; n++) 8 == (r += (o = e.charCodeAt(n)) >= 0 && o <= 128 ? 1 : 2) && (i = n);
    return r > 8 && (e = e.substring(0, i) + "…"), e
  };

function C(e) {
  var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "nextCustomerCategoryUid",
    t = d.preferenceSettingStore.get("rawData"),
    o = "";
  if (0 != t._showRecommendDiscount) {
    var i = t._recommendDiscount;
    if (1 == t._showRecommendDiscount && (i = m), !i) return "";
    var n = i[-1] || i[Object.keys(i)[0]];
    if (g.userInfoStore.get("isLogin")) {
      var u = g.userInfoStore.get("rawData").categoryUidTxt;
      n = 0 == u ? i[-1] : i[g.userInfoStore.get("rawData").categoryUidTxt] || i[-1]
    } else p && (n = p.txtUid + "-" + (p.name || "无"));
    o = n, "object" == a(e) && (e[r] = v(n))
  }
  return o
}
exports.showProductShopModeTips = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    r = {
      1: "堂食",
      2: "配送",
      3: "自取",
      4: "扫码点单"
    },
    t = [];
  if (0 == e.length || S()) return null;
  for (var o in r) e.includes(Number(o)) || t.push(r[o]);
  return 0 == t.length ? null : 1 == t.length ? "仅" + t[0] : "支持" + t.join("、")
};
var S = function() {
  var e = f.storeInfoStore.get("rawData").IsHideProductByMode,
    r = d.preferenceSettingStore.get("ignoreProductModeHide");
  return !!e && !(1 == r && !(0, f.isTableMode)())
};
exports.checkHideProductByMode = S;
var x = function() {
  var e = (0, l.getStoreMode)(),
    r = {
      "RegularOrder|package": 2,
      "AddressQRCode|queue": 1,
      "RegularOrder|takeout": 3
    } [e + "|" + (0, l.getStoreModeValue)()];
  return !r && ["AddressQRCode", "SelfOrderingPlus"].includes(e) && (r = 4), [1, 2, 3, 4].includes(r) || console.log("获取店铺模式值 错了。"), r
};
exports.getShopActiveModeNum = x;
exports.checkProductByModeCantPay = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
  if (0 == e.length || S()) return !1;
  var r = x(),
    t = e.includes(r);
  return console.log("checkProductByModeCantPay", r, e), t && wx.showModal({
    title: "提示",
    content: "该商品暂不支持当前店铺模式下购买。",
    showCancel: !1
  }), t
};
var y = {},
  I = "",
  b = null;

function w() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  return e.ProductUidTxt || ""
}

function U() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  return e.uid || ""
}

function T() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  return e.PromotionRuleUidTxt || ""
}

function k() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  return Number(e.LimitTimes || 0)
}

function N() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
    t = (e.ProductUidCountPairs || e.gifts || []).map((function(e) {
      return u(u({}, e), {}, {
        ProductUidTxt: String(w(e)),
        Count: Number(e.Count || e.count || 0)
      })
    })).filter((function(e) {
      return e.ProductUidTxt && e.Count > 0
    })),
    o = Number(r.Count || r.count || 0),
    i = t.reduce((function(e, r) {
      return e + r.Count
    }), 0);
  return u(u({}, e), {}, {
    ruleUid: String(T(e)),
    ruleBusUid: String(e.PromotionBusUidTxt || e.PromotionBusUid || ""),
    ruleName: e.PromotionName || "",
    num: o,
    buyCount: o,
    buyProductUid: String(w(r)),
    gifts: t,
    giftItems: t,
    giftCount: i,
    limitTimes: k(e),
    giftType: e.GiftType,
    isGiftSelf: t.every((function(e) {
      return e.ProductUidTxt == w(r)
    })),
    showStr: "购买".concat(o, "件可享受搭赠"),
    showStr2: "买".concat(o, "送").concat(i).concat(k(e) > 0 ? " 限" + k(e) + "次" : "")
  })
}

function D() {
  return 1 == d.preferenceSettingStore.get("rawData")._hidePromotionGiftInfoShow
}
var _ = function(e) {
  return e().then((function(e) {
    return [null, e]
  })).catch((function(e) {
    return [e, null]
  }))
};
exports.awaitCatch = _;
var M = new(function() {
    function e(r) {
      o(this, e), this.cache = (null == r ? void 0 : r.cache) || new Map
    }
    return i(e, [{
      key: "setCache",
      value: function(e, r) {
        this.cache.has((0, l.getStoreId)()) || this.cache.set((0, l.getStoreId)(), new Map), this.cache.get((0, l.getStoreId)()).set(e, r)
      }
    }, {
      key: "removeCache",
      value: function(e) {
        this.cache.has((0, l.getStoreId)()) && this.cache.get((0, l.getStoreId)()).delete(e)
      }
    }, {
      key: "hasCache",
      value: function(e) {
        return this.cache.has((0, l.getStoreId)()) && this.cache.get((0, l.getStoreId)()).has(e)
      }
    }, {
      key: "getCache",
      value: function(e) {
        if (this.cache.has((0, l.getStoreId)())) return this.cache.get((0, l.getStoreId)()).get(e)
      }
    }, {
      key: "clearCache",
      value: function() {
        this.cache.get((0, l.getStoreId)()).clear()
      }
    }, {
      key: "clearCacheAll",
      value: function() {
        this.cache.clear()
      }
    }, {
      key: "getUidsWihtoutCache",
      value: function() {
        var e = this,
          r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return r.filter((function(r) {
          return !e.hasCache(r)
        }))
      }
    }]), e
  }())(new Map),
  G = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      r = e.discountResults || [];
    return r.some((function(e) {
      return e && (e.ruleUid || e.ruleUidTxt)
    }))
  },
  A = function() {
    var e = d.preferenceSettingStore.get("rawData")._customizeTag || {};
    return {
      name: e["权益卡专享价"] || "权益卡专享价",
      uid: e._privilegeCardUid
    }
  };
exports.getDisplayPrivilegeName = A;
var B = function() {
  var o = t(e().mark((function t() {
    var o, i, n, u, a, c, l, f, g;
    return e().wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          if (o = d.preferenceSettingStore.get("rawData"), i = o._customizeTag, i && "0" !== i._showPrivilegeCardPrice && i._privilegeCardUid) {
            e.next = 5;
            break
          }
          return e.abrupt("return", Promise.resolve(!1));
        case 5:
          if (n = "privilegePriceShow", !M.hasCache(n)) {
            e.next = 8;
            break
          }
          return e.abrupt("return", Promise.resolve(M.getCache(n)));
        case 8:
          return e.next = 10, _((function() {
            return (0, s.fetch)({
              url: "wxapi/OrderPrivilegeCard/LoadRules",
              params: {}
            })
          }));
        case 10:
          return u = e.sent, a = r(u, 2), c = a[0], l = a[1], f = void 0 === l ? [] : l, c && M.setCache(n, !1), g = f.find((function(e) {
            return e.uid == i._privilegeCardUid
          })), M.setCache(n, !!g), g && (i._privilegeCardId = g.id), e.abrupt("return", Promise.resolve(M.getCache(n)));
        case 20:
        case "end":
          return e.stop()
      }
    }), t)
  })));
  return function() {
    return o.apply(this, arguments)
  }
}();
exports.hasPrivilegePriceShow = B;
var E = function() {
  var o = t(e().mark((function t() {
    var o, i, n, u, a, c, l, d, f, h, m;
    return e().wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          if (i = g.userInfoStore.get("isLogin"), n = A(), u = n.uid, i) {
            e.next = 3;
            break
          }
          return e.abrupt("return", Promise.resolve(!1));
        case 3:
          if (a = "CustomerPrivilegeHasCard", !M.hasCache(a)) {
            e.next = 6;
            break
          }
          return e.abrupt("return", Promise.resolve(M.getCache(a)));
        case 6:
          return e.next = 8, _((function() {
            return (0, s.fetch)({
              url: "wxapi/CustomerPrivilegeCard/LoadCustomerPrivilegeCards",
              params: {
                queryTypes: [2, 3],
                refresh: !0
              }
            })
          }));
        case 8:
          return c = e.sent, l = r(c, 2), d = l[0], f = l[1], d && M.setCache(a, !1), h = null === (o = f.customerPrivilegeCards) || void 0 === o ? void 0 : o.filter((function(e) {
            return e.cardRuleUidTxt == u
          })), M.setCache("CustomerPrivilegeCards", h.map((function(e) {
            return e.uid
          }))), m = h.length > 0, M.setCache(a, m), e.abrupt("return", Promise.resolve(M.getCache(a)));
        case 18:
        case "end":
          return e.stop()
      }
    }), t)
  })));
  return function() {
    return o.apply(this, arguments)
  }
}();
exports.hasPrivilegeCardInSelf = E;
var R = function() {
  var o = t(e().mark((function t(o) {
    var i, n, u, a, c, l, f, g;
    return e().wrap((function(e) {
      for (;;) switch (e.prev = e.next) {
        case 0:
          if (i = d.preferenceSettingStore.get("rawData"), n = i._customizeTag, 0 != o.length) {
            e.next = 4;
            break
          }
          return e.abrupt("return", Promise.resolve(!1));
        case 4:
          if (n && "0" !== n._showPrivilegeCardPrice && n._privilegeCardUid) {
            e.next = 6;
            break
          }
          return e.abrupt("return", Promise.resolve(!1));
        case 6:
          if (0 != (u = M.getUidsWihtoutCache(o)).length) {
            e.next = 9;
            break
          }
          return e.abrupt("return", Promise.resolve(!0));
        case 9:
          return e.next = 11, E();
        case 11:
          return a = e.sent, e.next = 14, _((function() {
            return (0, s.fetch)({
              url: "wxapi/product/GetProductExtentInfo",
              params: {
                productUids: u,
                filterNoMatch: !0,
                isCurrentTimeValid: a,
                incPirce: !0,
                pricePromotionType: ["PrivilegeCardDiscount"],
                privilegecardUid: n._privilegeCardUid
              },
              isShowMessage: !1,
              checkSuccessField: !1
            })
          }));
        case 14:
          if (c = e.sent, l = r(c, 2), f = l[0], g = l[1], !f) {
            e.next = 20;
            break
          }
          return e.abrupt("return", Promise.resolve(!1));
        case 20:
          return u.forEach((function(e) {
            return M.setCache(e, null)
          })), (g.prices || []).forEach((function(e) {
            M.setCache(e.uid, G(e) ? e.sellPrice : null)
          })), e.abrupt("return", Promise.resolve(!0));
        case 24:
        case "end":
          return e.stop()
      }
    }), t)
  })));
  return function(e) {
    return o.apply(this, arguments)
  }
}();
exports.loadPrivilegePriceByProUids = R;
exports.getPrivilegePriceByProUid = function(e, r) {
  var t = M.hasCache(e) ? M.getCache(e) : null;
  return t && r > t ? t : null
};
exports.getCustomPrivilegeCardUid = function() {
  return M.getCache("CustomerPrivilegeCards")
};
exports.getCustomPrivilegeCardId = function() {
  var e, r;
  return null === (e = d.preferenceSettingStore.get("rawData")) || void 0 === e || null === (r = e._customizeTag) || void 0 === r ? void 0 : r._privilegeCardId
};
exports.clearPrivilegePriceCache = function(e) {
  B().then((function(r) {
    if (r) {
      var t = A().uid;
      e === t && M.clearCache()
    }
  }))
};