Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var t = require("../@babel/runtime/helpers/classCallCheck"),
  e = require("../@babel/runtime/helpers/createClass"),
  i = function() {
    function i(e, s) {
      t(this, i), this._sortInit(e), this.reset(s)
    }
    return e(i, [{
      key: "_sortInit",
      value: function(t) {
        var e = {};
        t.forEach((function(t, i) {
          e[t] = i
        })), this.popSortMap = e
      }
    }, {
      key: "_sort",
      value: function() {
        this.popList = this.popList.sort((function(t, e) {
          return t.idx - e.idx
        }))
      }
    }, {
      key: "_start",
      value: function() {
        this._sort(), this.next()
      }
    }, {
      key: "reset",
      value: function(t) {
        this.popList = [], this.runing = !1, this.currentItem = {}, this.popKeys = [], this.interfaces = t.reduce((function(t, e) {
          return t[e] = !1, t
        }), {})
      }
    }, {
      key: "load",
      value: function(t) {
        var e = this;
        0 !== Object.keys(this.interfaces).length && (delete this.interfaces[t], 0 === Object.keys(this.interfaces).length && setTimeout((function() {
          console.log("开始展示弹窗"), e._start(), e.runing = !0
        }), 0))
      }
    }, {
      key: "push",
      value: function(t, e) {
        var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 100,
          s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 100,
          n = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
        try {
          this.runing || this.popKeys.some((function(e) {
            return e === t
          })) ? this.runing && this.popKeys.some((function(e) {
            return e === t
          })) && n && (console.log("重复插入".concat(t, ", 直接执行")), e()) : (this.popList.push({
            key: t,
            callback: e,
            idx: this.popSortMap[t],
            startDelay: i,
            endDelay: s
          }), this.popKeys.push(t))
        } catch (t) {
          console.log(t)
        }
      }
    }, {
      key: "next",
      value: function(t) {
        var e = this;
        if (t === this.currentItem.key) {
          var i = this.popList.shift();
          if (i) {
            var s = this.currentItem.endDelay || 0 + i.startDelay;
            setTimeout((function() {
              i.callback(), e.currentItem = i
            }), s)
          }
        }
      }
    }]), i
  }();
exports.default = i;