Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.urlQueryToParams = exports.urlParamsToQuery = void 0;
exports.urlQueryToParams = function(r) {
  r = r.substring(r.indexOf("?") + 1);
  var e = {};
  return r.split("&").forEach((function(r) {
    if ("" !== r) {
      var t = r.indexOf("="); - 1 === t && (t = r.length), e[r.substring(0, t)] = r.substring(t + 1)
    }
  })), e
};
exports.urlParamsToQuery = function(r) {
  return Object.keys(r).map((function(e) {
    return "".concat(e, "=").concat(r[e])
  })).join("&")
};