Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.createLogger = void 0;
var e = function(e, r) {
  console.error(e, r)
};
exports.createLogger = function() {
  var r = wx.getRealtimeLogManager ? wx.getRealtimeLogManager() : null;
  if (r && r.addFilterMsg) {
    for (var t = arguments.length, o = new Array(t), a = 0; a < t; a++) o[a] = arguments[a];
    return o.forEach((function(e) {
      r.addFilterMsg(e)
    })), r
  }
  return {
    error: e
  }
};