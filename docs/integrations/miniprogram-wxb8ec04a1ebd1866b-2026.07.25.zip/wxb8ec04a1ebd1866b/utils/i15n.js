Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.createI15n = void 0;
var e = require("../@babel/runtime/helpers/objectSpread2");
exports.createI15n = function(r, t) {
  return {
    getMessage: function(n, a, i) {
      var s = e({}, r),
        o = n + (a ? "-" + a : "");
      if (o)
        for (var c in Object.keys(t).map((function(e) {
            0 === o.indexOf(e) && Object.assign(s, t[e])
          })), s) {
          var u = s[c];
          i[u] && (s[c] = i[u])
        }
      return s
    }
  }
};