var r = ["〇", "一", "二", "三", "四", "五", "六", "七", "八", "九"],
  e = ["", "万", "亿", "万亿", "亿亿"],
  o = ["", "十", "百", "千"];

function t(e) {
  for (var t = "", n = "", u = 0, a = !0; e > 0;) {
    0;
    var f = e % 10;
    0 === f ? a || (a = !0, n = r[f] + n) : (a = !1, "一" == (t = r[f]) && "十" == o[u] && (t = ""), n = (t += o[u]) + n), u++, e = Math.floor(e / 10)
  }
  return n
}
module.exports = {
  num2Chinese: function(o) {
    var n = 0,
      u = "",
      a = "",
      f = !1;
    if (0 === o) return r[0];
    for (; o > 0;) {
      var i = o % 1e4;
      f && (a = r[0] + a), u = t(i), a = (u += 0 !== i ? e[n] : e[0]) + a, f = i < 1e3 && i > 0, o = Math.floor(o / 1e4), n++
    }
    return a
  }
};