module.exports = {
  parseTableNameCode: function(e) {
    for (var a = null == e ? "" : String(e), r = 0; r < 2 && a.indexOf("%") >= 0; r++) try {
      a = decodeURIComponent(a)
    } catch (e) {
      break
    }
    var t = a.indexOf(".");
    return -1 === t ? {
      restaurantAreaName: "",
      restaurantTableName: a
    } : {
      restaurantAreaName: a.slice(0, t),
      restaurantTableName: a.slice(t + 1)
    }
  },
  getTableCodeCheckErrorMessage: function(e) {
    if (!e) return "";
    if ("string" == typeof e) return e;
    var a = e.message || e.Message || e.data && (e.data.message || e.data.Message);
    return "string" == typeof a ? a : ""
  }
};