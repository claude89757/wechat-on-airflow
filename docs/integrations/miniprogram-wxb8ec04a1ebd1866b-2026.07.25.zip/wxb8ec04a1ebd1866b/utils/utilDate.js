function e(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "-",
    n = e.getFullYear(),
    r = e.getMonth() + 1,
    o = e.getDate();
  return [n, r, o].map(a).join(t)
}

function t(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "00:00:00",
    n = e.getFullYear(),
    r = e.getMonth() + 1,
    o = e.getDate();
  return new Date([n, r, o].map(a).join("/") + " " + t)
}

function n(e) {
  return [e.getHours(), e.getMinutes(), e.getSeconds()].map(a).join(":")
}

function r(e) {
  return [e.getHours(), e.getMinutes()].map(a).join(":")
}

function a(e) {
  return (e = e.toString())[1] ? e : "0" + e
}

function o(e, t) {
  var n = new Date(e);
  return n.setTime(n.getTime() + 60 * t * 1e3), n
}

function u(e) {
  return new Date(e.replace(/\.|-/gm, "/"))
}
var i = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"],
  g = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
module.exports = {
  parse: function(e) {
    var t = new Date(e.replace(/-/gm, "/"));
    return t.getFullYear() ? t : t = new Date(e.replace(/-/gm, "/"))
  },
  parse2: u,
  formatDate: e,
  setTimeDate: t,
  formatMonthDate: function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [".", ""],
      n = e.getMonth() + 1,
      r = e.getDate();
    return n + t[0] + r + t[1]
  },
  formatTime: n,
  formatTimeHHMM: r,
  formatDateTime: function(t) {
    return e(t) + " " + n(t)
  },
  formatNumber: a,
  addYears: function(e, t) {
    var n = new Date(e);
    return n.setYear(n.getFullYear() + t), n
  },
  addMonths: function(e, t) {
    var n = new Date(e);
    return n.setMonth(n.getMonth() + t), n
  },
  addDays: function(e, t) {
    var n = new Date(e);
    return n.setDate(n.getDate() + t), n
  },
  addHours: function(e, t) {
    var n = new Date(e);
    return n.setTime(n.getTime() + 60 * t * 60 * 1e3), n
  },
  reduceHours: function(e, t) {
    var n = new Date(e);
    return n.setTime(n.getTime() - 60 * t * 60 * 1e3), n
  },
  addMinutes: o,
  reduceYears: function(e, t) {
    var n = new Date(e);
    return n.setYear(n.getFullYear() - t), n
  },
  beginOfDate: function(e) {
    var t = new Date(e);
    return t.setMinutes(0), t.setHours(0), t
  },
  hourRange: function(e, t, n) {
    for (var a = [], u = 0, i = e; i <= t && (a.push(r(i)), !(++u > 100)); i = o(i));
    return a
  },
  timeRanges: function(e, t, n) {
    for (var a = [], u = 0, i = e; i < t && (a.push([r(i), r(o(i, n))].join("-")), !(++u > 100)); i = o(i, n));
    return a
  },
  makeTimeIntervals: function(e, t, n) {
    for (var r = e.split(":"), a = t.split(":"), o = n.split(":"), u = 60 * r[0] + 1 * r[1], i = 60 * a[0] + 1 * a[1], g = 60 * o[0] + 1 * o[1], s = [], l = [], c = u; c <= i; c += g) {
      var D = Math.floor(c / 60) + "",
        f = c % 60 + "";
      f = f.length < 2 ? "0" + f : f, D = D.length < 2 ? "0" + D : D, s.push(D + ":" + f)
    }
    var h = s[s.length - 1].split(":");
    60 * h[0] + 1 * h[1] != i && s.push(t.split(":")[0] + ":" + t.split(":")[1]);
    for (var m = 0; m < s.length - 1; m++) l.push(s[m] + " - " + s[m + 1]);
    return l
  },
  getWeekeTxt: function(e) {
    var t = e ? new Date(e) : new Date;
    return "日一二三四五六".charAt(t.getDay())
  },
  couponTimeFormat: function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
      t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "start",
      n = e,
      r = e.split(" ");
    return r[1] && ("start" == t && "00:00:00" == r[1] || "end" == t && "23:59:59" == r[1]) ? r[0] : n
  },
  dateFormat: function(e, t) {
    var n = {
      "M+": e.getMonth() + 1,
      "d+": e.getDate(),
      "h+": e.getHours(),
      "m+": e.getMinutes(),
      "s+": e.getSeconds(),
      "q+": Math.floor((e.getMonth() + 3) / 3),
      S: e.getMilliseconds()
    };
    for (var r in /(y+)/.test(t) && (t = t.replace(RegExp.$1, (e.getFullYear() + "").substr(4 - RegExp.$1.length))), n) new RegExp("(" + r + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? n[r] : ("00" + n[r]).substr(("" + n[r]).length)));
    return t
  },
  formatDateHHMM: function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ["-", " "],
      n = e.getFullYear(),
      r = e.getMonth() + 1,
      o = e.getDate(),
      u = e.getHours(),
      i = e.getMinutes();
    return [n, r, o].map(a).join(t[0]) + t[1] + [u, i].map(a).join(":")
  },
  getRangeWeek: function() {
    var e = new Date,
      t = e.getFullYear(),
      n = e.getMonth() + 1,
      r = e.getDate(),
      a = {};
    if (a.now = t + "-" + n + "-" + r, r - 7 <= 0) {
      var o = new Date(t, parseInt(n) - 1, 0).getDate();
      console.log("lastMonthDay", o, n, r), a.last = n - 1 <= 0 ? t - 1 + "-12-" + (31 - (7 - r)) : t + "-" + (n - 1) + "-" + (o - (7 - r))
    } else a.last = t + "-" + n + "-" + (r - 7);
    return console.log("getRangeMonth:", a), a
  },
  getRangeMonth: function() {
    var e = new Date,
      t = e.getFullYear(),
      n = e.getMonth() + 1,
      r = e.getDate(),
      a = {};
    a.now = t + "-" + n + "-" + r;
    var o = new Date(t, n, 0).getDate();
    if (n - 1 <= 0) a.last = t - 1 + "-12-" + r;
    else {
      var u = new Date(t, parseInt(n) - 1, 0).getDate();
      a.last = u < r ? r < o ? t + "-" + (n - 1) + "-" + (u - (o - r)) : t + "-" + (n - 1) + "-" + u : t + "-" + (n - 1) + "-" + r
    }
    return console.log("getRangeMonth:", a), a
  },
  getRange6Month: function() {
    var e = new Date,
      t = e.getFullYear(),
      n = e.getMonth() + 1,
      r = e.getDate(),
      a = {};
    return a.now = t + "-" + n + "-" + r, e.setMonth(e.getMonth() - 6), e.setDate(e.getDate() + 2), a.last = e.toLocaleDateString(), console.log("getRange6Month:", a), a
  },
  inThisWeek: function(e) {
    var t = new Date,
      n = t.getDay(),
      r = new Date(t.getTime() + 24 * (7 - (n || 7)) * 60 * 60 * 1e3);
    r.setHours(23, 59, 59, 999);
    var a = new Date(t.getTime() - 24 * ((n || 7) - 1) * 60 * 60 * 1e3);
    return a.setHours(0, 0, 0, 0), e.getTime() <= r.getTime() && e.getTime() >= a.getTime()
  },
  getDuration: function(e, t) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : ["milliseconds", "hours", "minutes"],
      r = "string" == typeof e ? new Date(e) : e,
      a = "string" == typeof t ? new Date(t) : t,
      o = a - r;
    return n.reduce((function(e, t) {
      var n = {
        milliseconds: 1,
        hours: 36e5,
        minutes: 6e4
      } [t] || 0;
      return n && (e[t] = Math.floor(o / n)), e
    }), {})
  },
  getDaysBetweenDates: function(e, t) {
    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
      r = e instanceof Date ? e : new Date(e),
      a = t instanceof Date ? t : new Date(t);
    r.setHours(0, 0, 0, 0), a.setHours(0, 0, 0, 0);
    var o = a.getTime() - r.getTime(),
      u = o / 864e5;
    return n ? Math.abs(u) : u
  },
  getFiexdTimeLast: function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
      n = new Date;
    if (e && e.length > 0) {
      e.sort((function(e, t) {
        return e.split("|")[1].substring(0, 2) - t.split("|")[1].substring(0, 2)
      }));
      var r = t(n, e[e.length - 1].split("|")[1]);
      return n < r
    }
    return !0
  },
  formatWeek: function(e, t) {
    switch (t) {
      case 1:
        return g[e.getDay()];
      default:
        return i[e.getDay()]
    }
  },
  calculateDaysSince: function(e) {
    var t = u(e),
      n = (new Date).getTime() - t.getTime();
    return Math.floor(n / 864e5)
  }
};