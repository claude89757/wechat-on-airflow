Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.getWebpImage = exports.getSmallImage = exports.getOriginImage = exports.getMiddleImage = exports.getHttpsImage = exports.getDomainImage = exports.getCustomImage = exports.getBigImage = exports.checkProImageIsDefault = void 0;
var e = require("../modules/store/preference-setting");
exports.getSmallImage = function(e) {
  return e && e.replace(/.(?=[^.]*$)/, "_200x200.")
};
exports.getBigImage = function(e) {
  return e && e.replace(/.(?=[^.]*$)/, "_640x640.")
};
var t = function(e) {
  return e && e.replace(/_(?:200x200|640x640).(?=[^.]*$)/, ".")
};
exports.getOriginImage = t;
exports.getHttpsImage = function(e) {
  return e && (0 === e.indexOf("https://") ? e : 0 === e.indexOf("//") ? "https:".concat(e) : "https://".concat(e))
};
exports.getDomainImage = function(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "img",
    r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "pospal.cn";
  return e && "https://".concat(t, ".").concat(r, "/").concat(e)
};
exports.getMiddleImage = function(e) {
  return e && e.replace(/_(?:200x200).(?=[^.]*$)/, "_640x640.")
};
exports.getCustomImage = function(e) {
  var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 750,
    o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 750;
  return e && t(e) + "!/fxfn2/".concat(r, "x").concat(o)
};
exports.checkProImageIsDefault = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
  return e.indexOf("productImages/0/default") > 0
};
exports.getWebpImage = function() {
  var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
    o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 750,
    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 80,
    g = 1 == e.preferenceSettingStore.get("useHomeImageWebp") ? "/format/webp" : "";
  return t(r) + "!/fw/".concat(o, "/quality/").concat(n).concat(g)
};