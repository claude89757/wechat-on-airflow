Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.otherUntil = exports.CutDownTimer = void 0;
var t = function(t) {
  this.defaultSettings = {
    ms: !0,
    withDay: !0,
    eleId: "",
    timer: null,
    startTime: "",
    endTime: "",
    endCallBack: function() {},
    callback: function() {}
  }, this.config = Object.assign(this.defaultSettings, t), this.config.time_distance = e.getTimeDistance(this.config.startTime, this.config.endTime)
};
exports.CutDownTimer = t, t.prototype = {
  run: function() {
    var t, r, i, n, a, c = this;
    t = e.getTimeDistance(this.config.startTime, this.config.endTime), this.config.time_distance = t - 1e3, this.config.isBeforeStart = e.checkTimeStart(this.config.startTime), t > 0 ? (t -= 864e5 * (r = Math.floor(t / 864e5)), t -= 36e5 * (i = Math.floor(t / 36e5)), t -= 6e4 * (n = Math.floor(t / 6e4)), r < 10 && (r = "0" + r), i < 10 && (i = "0" + i), n < 10 && (n = "0" + n), (a = Math.floor(t / 1e3)) < 10 && (a = "0" + a), c.config.callback({
      isBeforeStart: this.config.isBeforeStart,
      timeOver: !1,
      d: r,
      h: i,
      m: n,
      s: a
    }), c.config.timer = setTimeout((function() {
      c.run()
    }), 1e3)) : c.config.endCallBack({
      isBeforeStart: this.config.isBeforeStart,
      timeOver: !0,
      d: "00",
      h: "00",
      m: "00",
      s: "00"
    })
  },
  clear: function() {
    clearTimeout(this.config.timer)
  }
};
var e = {
  checkTimeStart: function(t) {
    var e = t.replace("-", "/").replace("-", "/");
    return new Date(e) - new Date >= 0
  },
  checkTimeOver: function(t) {
    var e = t.replace("-", "/").replace("-", "/");
    return !(new Date(e) - new Date >= 0)
  },
  getTimeDistance: function(t, e, r) {
    var i = /-/g,
      n = new Date(t.replace(i, "/")).getTime(),
      a = new Date(e.replace(i, "/")).getTime(),
      c = null;
    return n > (c = r ? new Date(r.replace(i, "/")).getTime() : (new Date).getTime()) ? n - c : n < c && c < a ? a - c : c > a ? 0 : void 0
  },
  accSub: function(t, e) {
    var r, i, n;
    try {
      r = t.toString().split(".")[1].length
    } catch (t) {
      r = 0
    }
    try {
      i = e.toString().split(".")[1].length
    } catch (t) {
      i = 0
    }
    return ((t * (n = Math.pow(10, Math.max(r, i))) - e * n) / n).toFixed(r >= i ? r : i)
  },
  accAdd: function(t, e) {
    var r, i, n, a;
    try {
      r = t.toString().split(".")[1].length
    } catch (t) {
      r = 0
    }
    try {
      i = e.toString().split(".")[1].length
    } catch (t) {
      i = 0
    }
    if (a = Math.abs(r - i), n = Math.pow(10, Math.max(r, i)), a > 0) {
      var c = Math.pow(10, a);
      r > i ? (t = Number(t.toString().replace(".", "")), e = Number(e.toString().replace(".", "")) * c) : (t = Number(t.toString().replace(".", "")) * c, e = Number(e.toString().replace(".", "")))
    } else t = Number(t.toString().replace(".", "")), e = Number(e.toString().replace(".", ""));
    return (t + e) / n
  },
  accDiv: function(t, e) {
    var r = 0,
      i = 0;
    try {
      r = t.toString().split(".")[1].length
    } catch (t) {}
    try {
      i = e.toString().split(".")[1].length
    } catch (t) {}
    return Number(t.toString().replace(".", "")) / Number(e.toString().replace(".", "")) * pow(10, i - r)
  },
  GetQueryString: function(t) {
    var e = new RegExp("(^|&)" + t + "=([^&]*)(&|$)"),
      r = window.location.search.substr(1).match(e);
    return null != r ? unescape(r[2]) : null
  },
  formateUserName: function(t) {
    var e = "",
      r = t.length;
    if (r < 3 && r > 0) e = t[0] + "*";
    else {
      var i = Math.ceil(r / 3),
        n = Math.floor(r / 3),
        a = r - n - i,
        c = "*".repeat(i);
      e = t.substr(0, n) + c + t.substr(r - a)
    }
    return e
  },
  ft_c: function(t) {
    return "number" != typeof t && (t = parseFloat(t)), NaN === t ? "" : t.toFixed(2)
  }
};
exports.otherUntil = e;