Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var e, t = require("../@babel/runtime/helpers/typeof"),
  r = (e = require("./debounce.js")) && e.__esModule ? e : {
    default: e
  };
var i = function(e, i, n) {
  var a, u, l = !0,
    o = !0;
  if ("function" != typeof e) throw new TypeError("Expected a function");
  return u = t(a = n), null == a || "object" != u && "function" != u || (l = "leading" in n ? !!n.leading : l, o = "trailing" in n ? !!n.trailing : o), (0, r.default)(e, i, {
    leading: l,
    trailing: o,
    maxWait: i
  })
};
exports.default = i;