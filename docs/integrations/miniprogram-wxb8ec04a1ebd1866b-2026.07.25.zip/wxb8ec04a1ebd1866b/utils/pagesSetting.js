Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.getTabBarTpl = exports.getCurrentPageOpenCustomBar = void 0;
var n = require("../@babel/runtime/helpers/typeof"),
  i = require("../@babel/runtime/helpers/objectSpread2"),
  o = require("../@babel/runtime/helpers/slicedToArray"),
  e = require("../modules/cache/pages-structure"),
  t = require("../modules/store/app"),
  a = ["subPages/customize/customize", "subPages/customize/definePage", "accountSubpages/pages/account/account/account", "subPages/scanCodeOrder/shopping/fast", "subPages/shopping/details/details", "marketingSubpages/pages/group/details/details", "marketingSubpages/pages/bargain/details/details", "marketingSubpages/pages/seckill/details/details", "marketingSubpages/pages/presell/details/details", "subPages/shopping/shopping/fast", "marketingSubpages/pages/inviteShopping/index"];
exports.getCurrentPageOpenCustomBar = function() {
  var n = getCurrentPages();
  return -1 != a.indexOf(n[n.length - 1].route)
};
var c = new Map;
exports.getTabBarTpl = function() {
  return new Promise((function(a, s) {
    if (c.has((0, t.getStoreId)())) return a(c.get((0, t.getStoreId)()));
    e.pagesStructureCache.get(["footer"], !0).then((function(e) {
      var s = o(e, 1)[0].find((function(n) {
        return "底部标签栏" == n.name
      }));
      if (!s) return a(null);
      var u = JSON.parse(JSON.stringify(s.template));
      if (u.startIdx >= 0 && u.list[u.startIdx] && (u.list[u.startIdx]._startItem = !0), 1 == u.layoutType || 6 == u.layoutType) {
        u.list[0].isMiddle = !0;
        var f = u.list.splice(0, 1),
          r = u.list.length;
        u.list.splice(r / 2, 0, f[0])
      } else if (3 == u.layoutType) {
        var g = null;
        if (u.list.forEach((function(n, i) {
            "购物车" == n.name && (g = i, n.isMiddle = !0)
          })), null != g && "购物车" == u.list[g].name) {
          var d = u.list.splice(g, 1);
          u.cartItem = d[0]
        }
      } else 5 == u.layoutType && (u.cartItem = i({}, u.list[0]), u.couponItem = i({}, u.list[1]), u.list.splice(0, 2));
      u.layoutType > 0 ? u.list.forEach((function(i) {
        ("livelivelive" == i.link.data || i.link.data && "livelivelive" == i.link.data.href) && (i.link.live = "livelivelive"), i.link && "href" == i.link.type && (i.link.type = "pages"), i.link && "pages" == i.link.type && ("object" != n(i.link.data) || i.link.data.name ? "string" == typeof i.link.data && (i.link.data = {
          name: i.name
        }) : i.link.data.name = i.name, "自定义" == i.name && (i.link.data.title = i.title), i.link.data && i.link.data.name || (i.link.data = {
          name: i.name
        })), !i.link || "categories" != i.link.type && "pages" != i.link.type && "tags" != i.link.type || "自定义" == i.name && (i.link.data.title = i.title), i.beforeTitle = i.title || "", !i.title && i.link && (i.link.displayName ? i.title = i.link.displayName : i.link.data && i.link.data.displayName && (i.title = i.link.data.displayName)), "自定义-全部分类" == i.name && (i.link.data.name = "全部分类", i.link.data.href = "category", i.link.data.nType = "redirectTo"), i.iconNames = l(i), 1 == u.layoutType && i.isMiddle && ("购物车" == i.name && (i.iconNames = ["iconfont icon-gouwuche", "iconfont icon-gouwuche"]), "会员码" == i.name && (i.iconNames = ["iconfont icon-erweima", "iconfont icon-erweima"]))
      })) : u.list.forEach((function(n) {
        !n.link || "categories" != n.link.type && "pages" != n.link.type && "tags" != n.link.type || ("自定义" == n.name && (n.link.data.title = n.title), n.link.data && "livelivelive" == n.link.data.href && (n.link.live = "livelivelive")), n.sub && n.sub.forEach((function(n) {
          !n.link || "categories" != n.link.type && "pages" != n.link.type && "tags" != n.link.type || ("livelivelive" == n.link.data.href && (n.link.live = "livelivelive"), "自定义" == n.name && (n.link.data.title = n.title))
        }))
      })), u.startIdx = u.list.findIndex((function(n) {
        return Boolean(n._startItem)
      })), c.set((0, t.getStoreId)(), u), a(u)
    })).catch(s)
  }))
};
var l = function(n) {
  var i = n.name;
  if ("livelivelive" == n.link.live) return ["iconfont icon-zhibo", "iconfont icon-zhibo"];
  return {
    "首页": ["iconfont icon-shouye", "iconfont icon-shouye"],
    "全部分类": ["iconfont icon-shangpin", "iconfont icon-shangpin"],
    "自定义-全部分类": ["iconfont icon-shangpin", "iconfont icon-shangpin"],
    "扫码点单": ["iconfont icon-saoma", "iconfont icon-saoma"],
    "预订餐": ["iconfont icon-dingcan", "iconfont icon-dingcan"],
    "报餐": ["iconfont icon-dingcan", "iconfont icon-dingcan"],
    "个人中心": ["iconfont icon-wode", "iconfont icon-wode"],
    "会员中心": ["iconfont icon-wode", "iconfont icon-wode"],
    "会员码": ["iconfont icon-erweima", "iconfont icon-erweima"],
    "我的": ["iconfont icon-wode", "iconfont icon-wode"],
    "购物车": ["iconfont icon-gouwuche", "iconfont icon-gouwuche"],
    "地图": ["iconfont icon-ditu", "iconfont icon-ditu"],
    "联系我们": ["iconfont icon-dianhua", "iconfont icon-dianhua"],
    "优惠券": ["iconfont icon-kaquan", "iconfont icon-kaquan"],
    "我的卡券": ["iconfont icon-kaquan", "iconfont icon-kaquan"],
    "卡券中心": ["iconfont icon-kaquan", "iconfont icon-kaquan"],
    "客服": ["iconfont icon-kefu", "iconfont icon-kefu"],
    "签到有礼": ["iconfont icon-qiandao", "iconfont icon-qiandao"],
    "历史订单": ["iconfont icon-dingdan", "iconfont icon-dingdan"],
    "我的订单": ["iconfont icon-dingdanjindu", "iconfont icon-dingdanjindu"],
    "搜索": ["iconfont icon-sousuo", "iconfont icon-sousuo"],
    "自定义": ["iconfont icon-zidingyi", "iconfont icon-zidingyi"],
    "排队": ["iconfont icon-paidui", "iconfont icon-paidui"],
    "预约": ["iconfont icon-yuyue", "iconfont icon-yuyue"],
    "停车缴费": ["iconfont icon-tingchejiaofei", "iconfont icon-tingchejiaofei"],
    "所有商户": ["iconfont icon-home_icon_All-merchants_normal", "iconfont icon-home_icon_All-merchants_selected"],
    "知识店铺": ["iconfont icon-zhishiketang", "iconfont icon-zhishiketang"],
    "全部课程": ["iconfont icon-quanbukecheng", "iconfont icon-quanbukecheng"],
    "课程预约": ["iconfont icon-yuyue", "iconfont icon-yuyue"],
    "场地预约": ["iconfont icon-changdiyuyue", "iconfont icon-changdiyuyue"],
    "积分商城": ["iconfont icon-jifenshangcheng", "iconfont icon-jifenshangcheng"],
    "我的收藏": ["iconfont icon-icon_shoucang_gerenzhongxin", "iconfont icon-icon_shoucang_gerenzhongxin_mian"],
    "全部演出": ["iconfont icon-yanchu", "iconfont icon-yanchu"],
    "全部门票": ["iconfont icon-shangpin", "iconfont icon-shangpin"],
    "景区购物车": ["iconfont icon-gouwuche", "iconfont icon-gouwuche"],
    "报名活动": ["iconfont icon-baominghuodong-tab", "iconfont icon-baominghuodong-tab"],
    "店铺列表": ["iconfont icon-xuanzemendian-xuanzhong", "iconfont icon-xuanzemendian-xuanzhong"]
  } [i] || []
};