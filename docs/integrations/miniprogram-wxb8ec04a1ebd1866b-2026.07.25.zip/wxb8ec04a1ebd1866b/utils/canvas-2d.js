Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.measureWrapText = exports.fillText = exports.drawRoundRect = exports.drawCoverImage = exports.drawContainImage = void 0;
var e = require("../@babel/runtime/helpers/toConsumableArray");
exports.fillText = function(o, a, n, r) {
  var i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : -1,
    l = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : {},
    s = l.fontSize,
    h = void 0 === s ? 16 : s,
    v = l.lineHeight,
    f = void 0 === v ? 16 : v,
    d = l.fontStyle,
    c = void 0 === d ? "normal" : d,
    g = l.fontVariant,
    u = void 0 === g ? "normal" : g,
    p = l.fontWeight,
    x = void 0 === p ? "normal" : p,
    m = l.fontFamily,
    w = void 0 === m ? "sans-serif" : m,
    y = l.textAlign,
    I = void 0 === y ? null : y,
    T = l.textColor,
    P = void 0 === T ? null : T,
    b = l.textWrap,
    M = void 0 === b || b;
  o.save(), o.font = "".concat(c, " ").concat(u, " ").concat(x, " ").concat(h, "px/1  ").concat(w), o.textBaseline = "top", P && (o.fillStyle = P), I && (o.textAlign = I);
  var S = [];
  if (i >= 0)
    if (M) S.push.apply(S, e(t(o, a, i, {
      fontSize: h,
      lineHeight: f,
      fontStyle: c,
      fontVariant: u,
      fontWeight: x,
      fontFamily: w
    }).lines));
    else {
      for (var C = "", W = !1, A = 0; A < a.length; A++)
        if (C += a[A], o.measureText(C).width > i) {
          W = !0;
          break
        } if (W) {
        do {
          C = C.substring(0, C.length - 1)
        } while (o.measureText("".concat(C, "...")).width > i && C.length > 0);
        S.push("".concat(C, "..."))
      } else S.push(C)
    }
  else S.push(a);
  r += (f - h) / 2;
  for (var R = 0; R < S.length; R++, r += f) o.fillText(S[R], n, r);
  return o.restore(), f * S.length
};
var t = function(e, t) {
  var o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
    a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
    n = a.fontSize,
    r = void 0 === n ? 16 : n,
    i = a.lineHeight,
    l = void 0 === i ? 16 : i,
    s = a.fontStyle,
    h = void 0 === s ? "normal" : s,
    v = a.fontVariant,
    f = void 0 === v ? "normal" : v,
    d = a.fontWeight,
    c = void 0 === d ? "normal" : d,
    g = a.fontFamily,
    u = void 0 === g ? "sans-serif" : g;
  e.save(), e.font = "".concat(h, " ").concat(f, " ").concat(c, " ").concat(r, "px/1  ").concat(u);
  var p = [];
  if (o >= 0) {
    for (var x = "", m = 0; m < t.length; m++) {
      var w = x + t[m];
      e.measureText(w).width > o ? w.length > 1 ? (p.push(x), x = t[m]) : (p.push(w), x = "") : x = w
    }
    x.length > 0 && p.push(x)
  } else p.push(t);
  return e.restore(), {
    lines: p,
    height: p.length * l
  }
};
exports.measureWrapText = t;
exports.drawRoundRect = function(e, t, o, a, n) {
  var r, i, l, s, h = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
  "number" == typeof h ? r = i = l = s = h : Array.isArray(h) ? 1 === h.length ? r = i = l = s = h[0] : 2 === h.length ? (r = l = h[0], i = s = h[1]) : 4 === h.length ? (r = h[0], i = h[1], l = h[2], s = h[3]) : r = i = l = s = 0 : r = i = l = s = 0, e.save(), e.translate(t, o), e.beginPath(), e.arc(r, r, r, Math.PI, 3 * Math.PI / 2), e.lineTo(a - i, 0), e.arc(a - i, i, i, 3 * Math.PI / 2, 2 * Math.PI), e.lineTo(a, n - l), e.arc(a - l, n - l, l, 0, Math.PI / 2), e.lineTo(s, n), e.arc(s, n - s, s, Math.PI / 2, Math.PI), e.lineTo(0, r), e.closePath(), e.restore()
};
exports.drawCoverImage = function(e, t, o, a, n, r) {
  var i = 0,
    l = 0,
    s = t.width,
    h = t.height,
    v = n / r,
    f = s / h;
  if (v < f) {
    var d = h * v;
    i = (s - d) / 2, s = d
  } else if (v > f) {
    var c = s / v;
    l = (h - c) / 2, h = c
  }
  e.drawImage(t, i, l, s, h, o, a, n, r)
};
exports.drawContainImage = function(e, t, o, a, n, r) {
  var i = n / r,
    l = t.width / t.height,
    s = n,
    h = r;
  i < l ? h = n / l : i > l && (s = r * l);
  var v = o + (n - s) / 2,
    f = a + (r - h) / 2;
  e.drawImage(t, v, f, s, h)
};