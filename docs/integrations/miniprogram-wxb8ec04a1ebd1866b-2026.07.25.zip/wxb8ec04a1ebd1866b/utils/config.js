Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.createConfig = void 0;
var e = require("../@babel/runtime/helpers/objectSpread2");
exports.createConfig = function(r) {
  return {
    get: function(e) {
      return r[e]
    },
    getAll: function() {
      return e({}, r)
    },
    init: function(e) {
      for (var t in e) r.hasOwnProperty(t) && void 0 !== e[t] && (r[t] = e[t])
    }
  }
};