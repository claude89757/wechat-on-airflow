Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.wxp = void 0;
var e = function(e) {
    return function(t) {
      return new Promise((function(a, r) {
        var o = {
          success: a,
          fail: r
        };
        t = t || {};
        var s = Object.assign({}, t, o);
        e(s)
      }))
    }
  },
  t = {
    showModal: e(wx.showModal),
    getExtConfig: e(wx.getExtConfig),
    login: e(wx.login),
    switchTab: e(wx.switchTab),
    redirectTo: e(wx.redirectTo),
    reLaunch: e(wx.reLaunch),
    navigateTo: e(wx.navigateTo),
    navigateBack: e(wx.navigateBack),
    getStorage: e(wx.getStorage),
    setStorage: e(wx.setStorage),
    requestSubscribeMessage: e(wx.requestSubscribeMessage)
  };
exports.wxp = t;