Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.createStore = void 0;
var e = require("../@babel/runtime/helpers/toConsumableArray"),
  r = require("./listener"),
  t = function(e) {
    return JSON.parse(JSON.stringify(e))
  };
exports.createStore = function(n) {
  var i = 0,
    o = t(n),
    u = !1,
    a = [],
    s = (0, r.createListener)(),
    c = function() {
      var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
      u ? a.push.apply(a, e(r)) : (i++, s.trigger((function(e) {
        var t = e.cb,
          n = e.keys;
        if (0 !== r.length && 0 !== n.length) {
          for (var i = 0; i < n.length; i++)
            if (r.indexOf(n[i]) >= 0) return void t()
        } else t()
      })))
    };
  return {
    get: function(e) {
      return o[e]
    },
    getAll: function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
        r = {};
      for (var t in o) - 1 === e.indexOf(t) && (r[t] = o[t]);
      return r
    },
    set: function(e, r) {
      return !(!o.hasOwnProperty(e) || void 0 === r || o[e] === r) && (o[e] = r, c([e]), r)
    },
    setAll: function(e) {
      var r = [];
      for (var t in e) o.hasOwnProperty(t) && void 0 !== e[t] && o[t] !== e[t] && (o[t] = e[t], r.push(t));
      return r.length > 0 && (c(r), e)
    },
    groupSet: function(e) {
      try {
        u = !0, e(), u = !1, a.length > 0 && (c(a), a.length = 0)
      } catch (e) {
        throw u = !1, a.length = 0, e
      }
    },
    restore: function() {
      return !u && (Object.assign(o, t(n)), c(), !0)
    },
    getState: function() {
      return i
    },
    addChangeListener: function(e) {
      var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
        t = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      return t && e(), s.add({
        cb: e,
        keys: r
      })
    },
    removeChangeListener: function(e) {
      return s.remove(e)
    }
  }
};