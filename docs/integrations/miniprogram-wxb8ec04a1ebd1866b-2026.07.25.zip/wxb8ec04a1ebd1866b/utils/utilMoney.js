function t(t) {
  var n = String(t),
    e = n.lastIndexOf(".");
  if (-1 === e) return {
    moneyInt: t,
    multiple: 1
  };
  var r = n.substr(e + 1).length,
    l = Math.pow(10, r);
  return {
    moneyInt: parseInt(t * l + .5, 10),
    multiple: l
  }
}
module.exports = {
  add: function(n, e) {
    var r = t(n),
      l = r.moneyInt,
      u = r.multiple,
      i = t(e),
      o = i.moneyInt,
      a = i.multiple;
    return (u === a ? l + o : u > a ? l + o * (u / a) : o + l * (a / u)) / (u > a ? u : a)
  },
  sub: function(n, e) {
    var r = t(n),
      l = r.moneyInt,
      u = r.multiple,
      i = t(e),
      o = i.moneyInt,
      a = i.multiple;
    return (u === a ? l - o : u > a ? l - o * (u / a) : l * (a / u) - o) / (u > a ? u : a)
  },
  multiply: function(n, e) {
    var r = t(n),
      l = r.moneyInt,
      u = r.multiple,
      i = t(e);
    return l * i.moneyInt / (u * i.multiple)
  },
  division10: function(t) {
    var n = (t += "").indexOf(".");
    if (-1 == n) t = t.slice(0, t.length - 1) + "." + t.slice(-1);
    else {
      var e = t[n - 1];
      t = t.replace(e + ".", "." + e)
    }
    return parseFloat(t)
  },
  separateFloat: function(t) {
    var n = (t + "").split(".");
    return [parseInt(n[0]) || 0, parseInt(n[1]) || 0]
  },
  formatFloat: function(t) {
    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2,
      e = Math.pow(10, n);
    return Math.round(t * e, 10) / e
  }
};