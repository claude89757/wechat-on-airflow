Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.createSingleCache = exports.createMultipleCache = void 0;
var e = require("./listener");
exports.createSingleCache = function(e, n) {
  var r = {};
  return {
    get: function(t) {
      var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "main";
      return void 0 === r[i] && (r[i] = new Promise((function(r, i) {
        n(t).then((function(n) {
          var t = {};
          for (var i in e) t[i] = void 0 === n[i] ? e[i] : n[i];
          r(t)
        })).catch((function(e) {
          i(e)
        }))
      }))), r[i]
    },
    remove: function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "main";
      r[e] = void 0
    },
    removeAll: function() {
      for (var e in r) r[e] = void 0
    }
  }
};
exports.createMultipleCache = function(n, r) {
  var t = {},
    i = (0, e.createListener)(),
    o = function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
      i.trigger((function(n) {
        var r = n.cb,
          t = n.keys;
        if (0 !== e.length) {
          for (var i = 0; i < t.length; i++)
            if (e.indexOf(t[i]) >= 0) return void r()
        } else r()
      }))
    },
    c = (0, e.createListener)(),
    v = function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
      c.trigger((function(n) {
        var r = n.cb,
          t = n.keys;
        if (0 !== e.length) {
          for (var i = 0; i < t.length; i++)
            if (e.indexOf(t[i]) >= 0) return void r()
        } else r()
      }))
    };
  return {
    get: function(e) {
      var i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        c = e.filter((function(e) {
          return n.hasOwnProperty(e) && void 0 === t[e]
        }));
      if (c.length > 0) {
        for (var v = r(c), u = {}, a = function(e) {
            var r = c[e];
            t[r] = u[r] = new Promise((function(t, i) {
              v[e].then((function(e) {
                t(void 0 === e ? "function" == typeof n[r] ? n[r]() : n[r] : e)
              })).catch((function(e) {
                i(e)
              }))
            }))
          }, f = 0; f < c.length; f++) a(f);
        o(c)
      }
      var d = e.map((function(e) {
        return void 0 === t[e] ? Promise.reject(new Error("key未设置")) : t[e]
      }));
      return i ? Promise.all(d) : d
    },
    remove: function(e) {
      var n = [];
      return e.forEach((function(e) {
        t.hasOwnProperty(e) && void 0 !== t[e] && (t[e] = void 0, n.push(e))
      })), n.length > 0 && (v(n), !0)
    },
    removeAll: function() {
      for (var e in t) t[e] = void 0;
      return v(), !0
    },
    addChangeListener: function(e, n) {
      return i.add({
        cb: e,
        keys: n
      })
    },
    removeChangeListener: function(e) {
      return i.remove(e)
    },
    addRemoveListener: function(e, n) {
      return c.add({
        cb: e,
        keys: n
      })
    },
    removeRemoveListener: function(e) {
      return c.remove(e)
    }
  }
};