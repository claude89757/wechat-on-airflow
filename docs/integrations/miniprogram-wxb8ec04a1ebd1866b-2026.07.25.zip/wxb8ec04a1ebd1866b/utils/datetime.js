Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.setOrderTimesFormBeijingTime = exports.parseDate = exports.isShopBeijingUtc = exports.isNeedTransferTime = exports.getShopDiffTime = exports.getServicesTimeFromLocal = exports.getLocalTimeFromServicesTime = exports.getDayDiffAtNow = exports.getDayDiff = exports.formatDate = void 0;
var e = require("../@babel/runtime/helpers/construct"),
  t = require("../@babel/runtime/helpers/toConsumableArray"),
  r = require("../modules/store/store-Info"),
  n = function(e) {
    return [+e.substring(0, 4), +e.substring(5, 7) - 1, +e.substring(8, 10)]
  },
  i = function(e) {
    return [+e.substring(0, 4), +e.substring(5, 7) - 1, +e.substring(8, 10), +e.substring(11, 13), +e.substring(14, 16), +e.substring(17, 19)]
  },
  s = {
    "yyyy-MM-dd": n,
    "yyyy/MM/dd": n,
    "yyyy-MM-dd HH:mm:ss": i,
    "yyyy/MM/dd HH:mm:ss": i
  };
exports.parseDate = function(r) {
  var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "yyyy-MM-dd HH:mm:ss",
    i = s[n];
  return i ? e(Date, t(i(r))) : new Date
};
var o = ["日", "一", "二", "三", "四", "五", "六"],
  a = {
    "y+": function(e, t) {
      return (e.getFullYear() + "").padStart(t.length, "0")
    },
    "M+": function(e, t) {
      return (e.getMonth() + 1 + "").padStart(t.length, "0")
    },
    "d+": function(e, t) {
      return (e.getDate() + "").padStart(t.length, "0")
    },
    "H+": function(e, t) {
      return (e.getHours() + "").padStart(t.length, "0")
    },
    "m+": function(e, t) {
      return (e.getMinutes() + "").padStart(t.length, "0")
    },
    "s+": function(e, t) {
      return (e.getSeconds() + "").padStart(t.length, "0")
    },
    "E+": function(e, t) {
      var r = o[e.getDay()];
      switch (t.length) {
        case 1:
          return r;
        case 2:
        case 3:
          return "周" + r;
        default:
          return "星期" + r
      }
    }
  },
  u = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "yyyy-MM-dd HH:mm:ss",
      r = t,
      n = function(t) {
        var n = r.match(new RegExp(t, "g"));
        n && n.forEach((function(n) {
          r = r.replace(n, a[t](e, n))
        }))
      };
    for (var i in a) n(i);
    return r
  };
exports.formatDate = u;
var f = function(e, t) {
  var r = t.getTime() - e.getTime();
  return r <= 0 ? {
    time: r,
    days: "00",
    hours: "00",
    minutes: "00",
    seconds: "00"
  } : {
    time: r,
    days: Math.floor(r / 864e5) + "",
    hours: (Math.floor(r % 864e5 / 36e5) + "").padStart(2, "0"),
    minutes: (Math.floor(r % 36e5 / 6e4) + "").padStart(2, "0"),
    seconds: (Math.floor(r % 6e4 / 1e3) + "").padStart(2, "0")
  }
};
exports.getDayDiff = f;
var m = function(e) {
    return new Date(e.replace(/\.|-/gm, "/"))
  },
  g = function() {
    return r.storeInfoStore.get("utcOffsetMinus") || 480
  },
  c = function() {
    return g() !== -(new Date).getTimezoneOffset()
  };
exports.isNeedTransferTime = c;
var d = function() {
  return 480 === g()
};
exports.isShopBeijingUtc = d;
exports.getShopDiffTime = function() {
  var e = new Date,
    t = -e.getTimezoneOffset(),
    r = g(),
    n = t < 0 ? Math.abs(t) + r : r - t;
  return new Date(e.getTime() + 6e4 * n)
};
exports.getLocalTimeFromServicesTime = function(e) {
  if (!c()) return e;
  var t = u(m(e)),
    r = -(new Date).getTimezoneOffset(),
    n = g(),
    i = r < 0 ? Math.abs(r) + n : n - r,
    s = new Date(m(t).getTime() + 6e4 * i);
  return u(s)
};
exports.getDayDiffAtNow = function(e) {
  return f(new Date, e)
};
var p = function(e) {
  if (!c()) return e;
  var t = u(m(e), "yyyy/MM/dd HH:mm:ss"),
    r = new Date(t),
    n = -r.getTimezoneOffset(),
    i = g(),
    s = n < 0 ? Math.abs(n) + i : i - n,
    o = new Date(r.getTime() - 6e4 * s);
  return u(o)
};
exports.getServicesTimeFromLocal = p;
exports.setOrderTimesFormBeijingTime = function() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    t = ["reservationTime", "ticketCreateDateTime", "deliveryTime", "reservationOrDeliveryTimeEnd", "orderTime"];
  return d() && c() ? (e.isShowBeijingTime = !0, e) : (t.forEach((function(t) {
    e[t] && (e[t] = p(e[t]))
  })), e)
};