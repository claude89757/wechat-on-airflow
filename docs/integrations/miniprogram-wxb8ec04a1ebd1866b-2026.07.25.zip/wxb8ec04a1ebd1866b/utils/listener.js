Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.createListener = void 0;
exports.createListener = function() {
  var e = [];
  return {
    add: function(r) {
      return e.push(r), e.length - 1
    },
    remove: function(r) {
      return !(!e.hasOwnProperty(r) || void 0 === e.hasOwnProperty(r)) && (e[r] = void 0, !0)
    },
    trigger: function(r) {
      return "function" == typeof r && (e.forEach((function(e) {
        void 0 !== e && r(e)
      })), !0)
    }
  }
};