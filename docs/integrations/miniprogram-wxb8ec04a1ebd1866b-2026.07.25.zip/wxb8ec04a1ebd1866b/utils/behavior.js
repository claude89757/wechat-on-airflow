Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.pageBehaviorMixinMapper = exports.createStoreBehavior = exports.createConfigBehavior = void 0;
var e = require("../@babel/runtime/helpers/defineProperty"),
  t = {};
exports.pageBehaviorMixinMapper = t;
exports.createStoreBehavior = function(a, r) {
  var i = "_".concat(r, "State"),
    o = function() {
      var t = e({}, r, a.getAll(["rawData"]));
      return t[i] = a.getState(), t
    },
    n = new Set;
  a.addChangeListener((function() {
    var e = getCurrentPages(),
      t = e[e.length - 1];
    if (t && t.getPageId) {
      var a = t.getPageId();
      n.forEach((function(e) {
        e.getPageId() === a && e.setData(o())
      }))
    }
  }));
  var s = Behavior({
    lifetimes: {
      attached: function() {
        n.add(this), this.setData(o())
      },
      detached: function() {
        n.delete(this)
      }
    },
    pageLifetimes: {
      show: function() {
        this.data[i] !== a.getState() && this.setData(o())
      }
    }
  });
  return t[s] = {
    data: o(),
    onLoad: function() {
      n.add(this), this.data[i] !== a.getState() && this.setData(o())
    },
    onShow: function() {
      this.data[i] !== a.getState() && this.setData(o())
    },
    onUnload: function() {
      n.delete(this)
    }
  }, s
};
exports.createConfigBehavior = function(a, r) {
  var i = {
      data: e({}, r, a.getAll())
    },
    o = Behavior(i);
  return t[o] = i, o
};