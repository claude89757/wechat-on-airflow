Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.default = void 0;
var n = require("../@babel/runtime/helpers/typeof"),
  t = window;
var e = function(e, r, i) {
  var o, u, a, f, c, v, d, l, m = 0,
    p = !1,
    s = !1,
    w = !0,
    h = !r && 0 !== r && "function" == typeof t.requestAnimationFrame;
  if ("function" != typeof e) throw new TypeError("Expected a function");

  function x(n) {
    var t = o,
      r = u;
    return o = u = void 0, m = n, f = e.apply(r, t)
  }

  function y(n, e) {
    return h ? t.requestAnimationFrame(n) : setTimeout(n, e)
  }

  function g(n) {
    return m = n, c = y(A, r), p ? x(n) : f
  }

  function b(n) {
    var t = n - v;
    return void 0 === v || t >= r || t < 0 || s && n - m >= a
  }

  function A() {
    var n = Date.now();
    if (b(n)) return q(n);
    c = y(A, function(n) {
      var t = n - m,
        e = r - (n - v);
      return s ? Math.min(e, a - t) : e
    }(n))
  }

  function q(n) {
    return c = void 0, w && o ? x(n) : (o = u = void 0, f)
  }

  function D() {
    for (var n = Date.now(), t = b(n), e = arguments.length, i = new Array(e), a = 0; a < e; a++) i[a] = arguments[a];
    if (o = i, u = this, v = n, t) {
      if (void 0 === c) return g(v);
      if (s) return c = y(A, r), x(v)
    }
    return void 0 === c && (c = y(A, r)), f
  }
  return r = +r || 0, l = n(d = i), null == d || "object" != l && "function" != l || (p = !!i.leading, a = (s = "maxWait" in i) ? Math.max(+i.maxWait || 0, r) : a, w = "trailing" in i ? !!i.trailing : w), D.cancel = function() {
    void 0 !== c && function(n) {
      if (h) return t.cancelAnimationFrame(n);
      clearTimeout(n)
    }(c), m = 0, o = v = u = c = void 0
  }, D.flush = function() {
    return void 0 === c ? f : q(Date.now())
  }, D.pending = function() {
    return void 0 !== c
  }, D
};
exports.default = e;