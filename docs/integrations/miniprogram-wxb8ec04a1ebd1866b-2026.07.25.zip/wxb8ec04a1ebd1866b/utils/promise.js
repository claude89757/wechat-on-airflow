Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.createPromiseController = void 0;
exports.createPromiseController = function(e) {
  var t = "padding",
    n = null,
    r = null,
    u = new Promise((function(e, t) {
      n = e, r = t
    }));
  return {
    getName: function() {
      return e
    },
    getState: function() {
      return t
    },
    isPadding: function() {
      return "padding" === t
    },
    isFulfilled: function() {
      return "fulfilled" === t
    },
    isRejected: function() {
      return "rejected" === t
    },
    getPromise: function() {
      return u
    },
    then: function() {
      return u.then.apply(u, arguments)
    },
    catch: function() {
      return u.catch.apply(u, arguments)
    },
    finally: function() {
      return u.finally.apply(u, arguments)
    },
    setFulfilled: function(e) {
      return t = "fulfilled", n(e)
    },
    setRejected: function(e) {
      return t = "rejected", r(e)
    },
    run: function(e) {
      return e(this.setFulfilled, this.setRejected), u
    }
  }
};