Object.defineProperty(exports, "__esModule", {
  value: !0
}), exports.toHexColor = exports.rgbArray2Hex = exports.mixColor = exports.colorToGrey = exports.colorToDepth = exports.color2Rgba = exports.color2RgbArray = void 0;
var r = require("../@babel/runtime/helpers/slicedToArray"),
  t = function(r) {
    if (0 === (r = r.replace(/\s/g, "")).indexOf("#") && 7 === r.length) return [parseInt(r.slice(1, 3), 16), parseInt(r.slice(3, 5), 16), parseInt(r.slice(5, 7), 16)];
    if (0 === r.indexOf("rgb")) {
      var t = r.match(/rgb\((\d+),(\d+),(\d+)\)/);
      if (4 === t.length) return [parseInt(t[1]), parseInt(t[2]), parseInt(t[3])]
    }
    return [0, 0, 0]
  };
exports.color2RgbArray = t;
var e = function(t) {
  var e = r(t, 3),
    o = e[0],
    n = e[1],
    a = e[2],
    c = Math.round(o).toString(16),
    s = Math.round(n).toString(16),
    i = Math.round(a).toString(16);
  return 1 === c.length && (c = "0" + c), 1 === s.length && (s = "0" + s), 1 === i.length && (i = "0" + i), "#".concat(c).concat(s).concat(i)
};
exports.rgbArray2Hex = e;
exports.mixColor = function(o, n) {
  var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
    c = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
    s = t(o),
    i = r(s, 3),
    u = i[0],
    l = i[1],
    p = i[2],
    g = t(n),
    h = r(g, 3),
    x = h[0],
    f = h[1],
    d = h[2],
    v = 1 - (1 - a) * (1 - c),
    b = (u * a + x * c * (1 - a)) / v,
    M = (l * a + f * c * (1 - a)) / v,
    y = (p * a + d * c * (1 - a)) / v;
  return e([b, M, y])
};
exports.color2Rgba = function(e, o) {
  var n = t(e),
    a = r(n, 3),
    c = a[0],
    s = a[1],
    i = a[2];
  return "rgba(".concat(c, ",").concat(s, ",").concat(i, ",").concat(o, ")")
};
exports.colorToGrey = function(a) {
  var c = t(a),
    s = r(c, 3),
    i = o(s[0], s[1], s[2]),
    u = r(i, 3),
    l = u[0],
    p = (u[1], u[2]);
  return e(n(l, 0, p))
};

function o(r, t, e) {
  r /= 255, t /= 255, e /= 255;
  var o, n, a = Math.max(r, t, e),
    c = Math.min(r, t, e),
    s = (a + c) / 2;
  if (a == c) o = n = 0;
  else {
    var i = a - c;
    switch (n = s > .5 ? i / (2 - a - c) : i / (a + c), a) {
      case r:
        o = (t - e) / i + (t < e ? 6 : 0);
        break;
      case t:
        o = (e - r) / i + 2;
        break;
      case e:
        o = (r - t) / i + 4
    }
    o /= 6
  }
  return [o, n, s]
}

function n(r, t, e) {
  var o, n, a;
  if (0 == t) o = n = a = e;
  else {
    var c = function(r, t, e) {
        return e < 0 && (e += 1), e > 1 && (e -= 1), e < 1 / 6 ? r + 6 * (t - r) * e : e < .5 ? t : e < 2 / 3 ? r + (t - r) * (2 / 3 - e) * 6 : r
      },
      s = e < .5 ? e * (1 + t) : e + t - e * t,
      i = 2 * e - s;
    o = c(i, s, r + 1 / 3), n = c(i, s, r), a = c(i, s, r - 1 / 3)
  }
  return [Math.round(255 * o), Math.round(255 * n), Math.round(255 * a)]
}
exports.colorToDepth = function(a) {
  var c = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .5,
    s = t(a),
    i = r(s, 3),
    u = i[0],
    l = i[1],
    p = i[2],
    g = o(u, l, p),
    h = r(g, 3),
    x = h[0],
    f = h[1];
  h[2];
  return e(n(x, f, c))
};
exports.toHexColor = function(r, t) {
  if (r.startsWith("rgb")) {
    var e = r.match(/[0-9]+/g);
    return "#" + ("000000" + (e[0] << 16 | e[1] << 8 | e[2]).toString(16)).substr(-6)
  }
  return r.startsWith("#") ? r : t
};