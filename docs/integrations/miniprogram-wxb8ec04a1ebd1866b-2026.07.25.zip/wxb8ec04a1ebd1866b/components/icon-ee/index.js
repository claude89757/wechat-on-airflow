Component({
  properties: {
    icon: {
      type: String,
      value: ""
    },
    width: {
      type: String,
      value: "1em"
    },
    height: {
      type: String,
      value: "1em"
    },
    color: {
      type: String,
      value: ""
    }
  },
  data: {
    svg: ""
  },
  observers: {
    icon: function(t) {
      var o = this,
        e = /^https:\/\/.+\.svg$/.test(t) ? t : "https://imgw.pospal.cn//we/images/svgs/".concat(t, ".svg");
      wx.request({
        url: e,
        method: "GET",
        success: function(t) {
          t.statusCode >= 200 && t.statusCode < 300 ? o.setData({
            svg: "data:image/svg+xml," + encodeURIComponent(o.data.color ? t.data.split("currentColor").join(o.data.color) : t.data)
          }) : console.error("svg-icon加载 ".concat(e, " 失败: ").concat(t))
        },
        fail: function(t) {
          console.error("svg-icon加载 ".concat(e, " 失败: ").concat(t))
        }
      })
    }
  }
});