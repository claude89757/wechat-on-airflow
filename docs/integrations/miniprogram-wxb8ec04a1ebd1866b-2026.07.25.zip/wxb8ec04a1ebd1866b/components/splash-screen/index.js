var e = require("../../modules/promise/controller"),
  i = require("../../modules/store/theme"),
  t = require("../../modules/store/theme-style"),
  a = require("../../modules/store/preference-setting"),
  n = /\.(mp4|mpg|mpeg|m4v|mov|avi|wmv|flv|mkv|rm|rmvb|3gp|m3u8)(\?.*)?$/i;
Component({
  properties: {
    alwaysShow: {
      type: Boolean,
      value: !1
    },
    showLoadingView: {
      type: Boolean,
      value: !1
    },
    sikpSplashScreenShow: Boolean
  },
  observers: {
    showLoadingView: function(e) {
      "loading" == this.data.showType && this.setData({
        isShowSpclashScreen: e
      })
    }
  },
  data: {
    isShowSpclashScreen: !1,
    showType: null,
    loadingImage: (0, i.getLoadingImage)(),
    loadingMediaType: "image",
    loadingLabel: "",
    customImage: null,
    customImageLink: null,
    customImageRemainingTime: 0,
    skipButtonTop: 0,
    skipButtonRight: 0
  },
  methods: {
    agreeTermPopop: function() {
      var e;
      null === (e = this.selectComponent("#AgreeTerm")) || void 0 === e || e.checkPopupShow()
    },
    preventDefault: function() {},
    isVideoUrl: function() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
      return n.test(e)
    },
    getLoadingMediaType: function(e) {
      return e && this.isVideoUrl(e) ? "video" : "image"
    },
    shouldWaitSplashScreenMedia: function(e, i) {
      return !(i || !e) && !!this._waitSplashScreenMedia
    },
    startSplashMediaWaitTimer: function() {
      var e = this,
        i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1e4;
      this.clearSplashMediaWaitTimer(), this._splashMediaWaitTimer = setTimeout((function() {
        e.finishSplashScreenByMedia("timeout")
      }), i)
    },
    clearSplashMediaWaitTimer: function() {
      this._splashMediaWaitTimer && (clearTimeout(this._splashMediaWaitTimer), this._splashMediaWaitTimer = null)
    },
    finishSplashScreenByMedia: function(e) {
      this._waitingSplashScreenMedia && (this._waitingSplashScreenMedia = !1, this.setSplashScreenFinshed())
    },
    setSplashScreenFinshed: function() {
      this._waitingSplashScreenMedia = !1, this.clearSplashMediaWaitTimer(), e.initAppPromiseController.then((function() {
        e.splashScreenPromiseController.setFulfilled({
          type: "default"
        })
      }))
    },
    onSkipTap: function() {
      this.setSplashScreenFinshed()
    },
    onCustomImageTap: function(i) {
      if ("fulfilled" === e.initAppPromiseController.getState()) {
        var t = i.currentTarget.dataset.link;
        t && t.type && e.splashScreenPromiseController.setFulfilled({
          type: "splashScreentLink",
          data: t
        })
      }
    },
    showLoadingImage: function(e) {
      var i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        t = this.getLoadingMediaType(e),
        a = this.shouldWaitSplashScreenMedia(e, i);
      if (this.setPageStyle(), this.setData({
          loadingImage: e,
          showType: "loading",
          loadingMediaType: t
        }), a) return this._waitingSplashScreenMedia = !0, void this.startSplashMediaWaitTimer("video" === t ? 15e3 : 6e3);
      !i && this.setSplashScreenFinshed()
    },
    onLoadingImageLoad: function() {
      this.finishSplashScreenByMedia("image-load")
    },
    onLoadingVideoMeta: function(e) {
      var i;
      if (this._waitingSplashScreenMedia) {
        var t = Number(null == e || null === (i = e.detail) || void 0 === i ? void 0 : i.duration) || 0;
        if (t > 0) {
          var a = Math.min(Math.max(Math.ceil(1e3 * t) + 500, 1e3), 3e4);
          this.startSplashMediaWaitTimer(a)
        }
      }
    },
    onLoadingVideoEnded: function() {
      this.finishSplashScreenByMedia("video-ended")
    },
    onLoadingMediaError: function() {
      this.finishSplashScreenByMedia("media-error")
    },
    setPageStyle: function() {
      var e = wx.getStorageSync("themeColorsStoreage"),
        i = e ? e.split("|") : [t.themeStyleStore.get("themeColor1"), t.themeStyleStore.get("themeColor2")];
      this.setData({
        pageStyle: "--primary: ".concat(i[0], ";--second: ").concat(i[1], ";")
      })
    },
    showCustomImages: function(e) {
      var i = this,
        t = wx.getSystemInfoSync(),
        a = wx.getMenuButtonBoundingClientRect(),
        n = function() {
          return e.reduce((function(e, i) {
            return e + i.duration
          }), 0)
        },
        s = function(e) {
          i.setData({
            customImage: e.src,
            customImageLink: e.link,
            customImageRemainingTime: n()
          })
        },
        o = 0;
      s(e[o]), this.setData({
        showType: "custom",
        skipButtonTop: (t.screenHeight === t.windowHeight ? a.bottom : 0) + 20,
        skipButtonRight: t.windowWidth - a.right
      });
      var h = setInterval((function() {
        var t = e[o];
        t.duration--, t.duration <= 0 ? ++o >= e.length ? (clearInterval(h), i.setData({
          customImageRemainingTime: 0
        }), i.setSplashScreenFinshed()) : s(e[o]) : i.setData({
          customImageRemainingTime: n()
        })
      }), 1e3)
    }
  },
  lifetimes: {
    attached: function() {
      var t = this;
      this._waitSplashScreenMedia = !1, this._waitingSplashScreenMedia = !1, this.properties.sikpSplashScreenShow ? (this.setData({
        isShowSpclashScreen: !0
      }), this.showLoadingImage((0, i.getLoadingImage)(), !0)) : i.themeStore.get("isShowSplashScreen") ? (this._waitSplashScreenMedia = (0, a.getSplashScreenWaitFirstVideo)(), this.setData({
        isShowSpclashScreen: !0,
        showType: "init"
      }), e.splashScreenPromiseController.then((function() {
        t.setData({
          isShowSpclashScreen: !1
        })
      })), e.initThemeStorePromiseController.then((function() {
        i.themeStore.set("isShowSplashScreen", !1);
        var e = (0, i.getSplashScreenCustomImages)();
        e.length > 0 ? t.showCustomImages(e) : t.showLoadingImage((0, i.getLoadingImage)())
      })).catch((function() {
        t.showLoadingImage((0, i.getLoadingImage)())
      }))) : this.properties.alwaysShow ? (this.setData({
        isShowSpclashScreen: !0
      }), this.showLoadingImage((0, i.getLoadingImage)())) : this.properties.showLoadingView && (this.setData({
        isShowSpclashScreen: !0,
        showType: "loading"
      }), this.showLoadingImage((0, i.getLoadingImage)()))
    },
    detached: function() {
      this.clearSplashMediaWaitTimer(), this._waitingSplashScreenMedia = !1
    }
  }
});