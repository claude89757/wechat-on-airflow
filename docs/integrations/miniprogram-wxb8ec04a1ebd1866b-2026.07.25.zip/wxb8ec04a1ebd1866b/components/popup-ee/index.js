Component({
  options: {
    multipleSlots: !0
  },
  properties: {
    show: {
      type: Boolean,
      value: !1
    },
    position: {
      type: String,
      value: "center"
    },
    top: {
      type: String,
      value: "25%"
    },
    zIndex: {
      type: String,
      value: "100"
    },
    maskOpacity: {
      type: String,
      value: "0.6"
    },
    aboveTab: {
      type: Boolean,
      value: !1
    }
  },
  data: {},
  methods: {
    onMaskTap: function() {
      this.triggerEvent("masktap")
    }
  }
});