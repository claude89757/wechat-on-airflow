var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [996], {
    71435: function() {},
    12331: function(n, e, c) {
      c.g.currentInject = {
        moduleId: "_407ca25e"
      }
    },
    60930: function() {},
    81788: function(n, e, c) {
      c(97766), c.g.currentModuleId = "_407ca25e", c.g.currentCtor = Component, c.g.currentCtorType = "component", c.g.currentResourceType = "component", c(12331), c(60930), c(71435), c.g.currentSrcMode = "wx", c(8449)
    },
    8449: function(n, e, c) {
      c.r(e), (0, c(69996).A)({})
    }
  },
  function(n) {
    n(n.s = 81788)
  }
]);