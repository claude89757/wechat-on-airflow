var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [774], {
    33951: function() {},
    64126: function(e, r, n) {
      var t = n(72244);
      n.g.currentInject = {
        moduleId: "_0735bb64"
      }, n.g.currentInject.render = function(e, r, n, c) {
        c("hasMargin", this.hasMargin), e(c("imageList", this.imageList), (function(r, n) {
          r.src, e(r.areaList, (function(e, r) {
            t.s("", e.style), e.link, c("scopeId", this.scopeId)
          }))
        })), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "imageWrapper",
          selector: ".ref_imageWrapper_1",
          type: "node",
          all: !1
        }]
      }
    },
    19985: function() {},
    28576: function(e, r, n) {
      n(97766), n.g.currentModuleId = "_0735bb64", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(64126), n(19985), n(33951), n.g.currentSrcMode = "wx", n(68037)
    },
    68037: function(e, r, n) {
      n.r(r);
      var t = n(69996),
        c = n(14734);
      (0, t.A)({
        properties: {
          images: Array,
          scopeId: Number,
          hasMargin: Boolean
        },
        setup: function(e, r) {
          var n = r.refs;
          return {
            imageList: (0, c.t)(e.images, n.imageWrapper)
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 28576)
  }
]);