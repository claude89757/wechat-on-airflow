var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [6180], {
    3035: function() {},
    43645: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_fd67e42c"
      }, r.g.currentInject.render = function(n, e, r, c) {
        c("name", this.name), r()
      }
    },
    80707: function() {},
    54520: function() {},
    54554: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_fd67e42c", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(43645), r(54520), r(80707), r(3035), r.g.currentSrcMode = "wx", r(42427)
    },
    42427: function(n, e, r) {
      r.r(e), (0, r(69996).A)({
        properties: {
          name: String
        }
      })
    }
  },
  function(n) {
    n(n.s = 54554)
  }
]);