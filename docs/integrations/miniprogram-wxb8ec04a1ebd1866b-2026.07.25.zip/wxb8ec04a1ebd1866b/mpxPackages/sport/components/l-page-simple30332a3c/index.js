var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [5650], {
    97570: function() {},
    37637: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_30332a3c"
      }, n.g.currentInject.render = function(e, t, n, r) {
        r("themeStyle", this.themeStyle), r("height", this.height), n()
      }
    },
    86384: function() {},
    35160: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_30332a3c", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(37637), n(86384), n(97570), n.g.currentSrcMode = "wx", n(96232)
    },
    96232: function(e, t, n) {
      n.r(t);
      var r = n(66855),
        c = n(39347);
      (0, n(69996).A)({
        properties: {
          height: {
            type: String,
            value: "auto"
          }
        },
        setup: function() {
          var e = (0, r.Ct)();
          return {
            themeStyle: (0, c.E)((function() {
              return e.data.themeStyle
            }))
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 35160)
  }
]);