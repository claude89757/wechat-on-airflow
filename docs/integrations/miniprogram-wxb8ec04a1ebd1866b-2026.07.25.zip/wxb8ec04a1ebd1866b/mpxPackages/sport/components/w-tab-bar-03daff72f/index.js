var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [4475], {
    68093: function() {},
    53560: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_3daff72f"
      }, n.g.currentInject.render = function(t, e, n, r) {
        t(r("list", this.list), (function(e, n) {
          0 == n || (e.link, e.title, r("activeTab", this.activeTab) == n && t(e.sub, (function(t, e) {
            t.link, t.title
          })))
        })), r("activeTab", this.activeTab), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "tabBar",
          selector: ".ref_tabBar_1",
          type: "node",
          all: !1
        }]
      }
    },
    56633: function() {},
    30271: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_3daff72f", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(53560), n(56633), n(68093), n.g.currentSrcMode = "wx", n(28168)
    },
    28168: function(t, e, n) {
      n.r(e);
      var r = n(57187),
        c = n(70841),
        a = n(69996),
        i = n(6520);
      (0, a.A)({
        properties: {
          list: Array
        },
        setup: function(t, e) {
          var n = e.refs,
            a = e.triggerEvent,
            u = (0, c.KR)(-1);
          return (0, i.sV)((function() {
            n.tabBar.boundingClientRect((function(t) {
              a("update", {
                height: t.height,
                safeBottom: 0
              })
            })).exec()
          })), {
            activeTab: u,
            onTapTab: function(e) {
              var n = t.list[e],
                c = n.sub,
                a = n.link;
              c.length > 0 ? u.value = u.value === e ? -1 : e : (u.value = -1, r.F.switchTab(e, a))
            },
            unsetActiveTab: function() {
              u.value = -1
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 30271)
  }
]);