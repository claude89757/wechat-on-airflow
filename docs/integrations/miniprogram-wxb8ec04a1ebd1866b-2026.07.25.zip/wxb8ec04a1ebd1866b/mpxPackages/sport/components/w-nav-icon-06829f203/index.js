var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [1517], {
    49818: function() {},
    72676: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_6829f203"
      }, r.g.currentInject.render = function(n, e, r, t) {
        n(t("list", this.list), (function(n, e) {
          n.link, n.src, n.displayTitle
        })), r()
      }
    },
    22708: function() {},
    3555: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_6829f203", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(72676), r(22708), r(49818), r.g.currentSrcMode = "wx", r(23436)
    },
    23436: function(n, e, r) {
      r.r(e), (0, r(69996).A)({
        properties: {
          list: Array
        }
      })
    }
  },
  function(n) {
    n(n.s = 3555)
  }
]);