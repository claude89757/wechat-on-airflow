var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [583], {
    56903: function() {},
    61848: function(e, n, r) {
      r.g.currentInject = {
        moduleId: "_397f0fe4"
      }, r.g.currentInject.render = function(e, n, r, t) {
        t("disabled", this.disabled), t("disabled", this.disabled), r()
      }
    },
    36755: function() {},
    17108: function(e, n, r) {
      r(97766), r.g.currentModuleId = "_397f0fe4", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(61848), r(36755), r(56903), r.g.currentSrcMode = "wx", r(40618)
    },
    40618: function(e, n, r) {
      r.r(n), (0, r(69996).A)({
        properties: {
          disabled: Boolean
        },
        setup: function(e, n) {
          var r = n.triggerEvent;
          return {
            onTap: function() {
              e.disabled || r("press")
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 17108)
  }
]);