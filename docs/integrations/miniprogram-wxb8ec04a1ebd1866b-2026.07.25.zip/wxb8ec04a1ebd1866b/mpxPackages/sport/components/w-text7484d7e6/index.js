var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [7021], {
    63295: function() {},
    61080: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_7484d7e6"
      }, n.g.currentInject.render = function(t, e, n, o) {
        o("template", this.template) && (e("template.displayStyle", this.template.displayStyle), e("template.bgColor", this.template.bgColor), o("titleStyle", this.titleStyle), e("template.title", this.template.title), o("contentStyle", this.contentStyle), e("template.content", this.template.content)), n()
      }
    },
    21784: function() {},
    55408: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_7484d7e6", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(61080), n(21784), n(63295), n.g.currentSrcMode = "wx", n(17165)
    },
    17165: function(t, e, n) {
      n.r(e);
      var o = n(69996),
        r = n(90356);
      (0, o.A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          var e = t.template,
            n = e.fontColor,
            o = e.fontSize,
            p = e.isBlod;
          return {
            titleStyle: (0, r.W9)(o[0], n[0], p[0]),
            contentStyle: (0, r.W9)(o[1], n[1], p[1])
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 55408)
  }
]);