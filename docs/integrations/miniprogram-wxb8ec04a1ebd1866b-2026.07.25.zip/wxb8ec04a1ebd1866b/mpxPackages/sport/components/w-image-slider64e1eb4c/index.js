var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [6106], {
    15925: function() {},
    10993: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_64e1eb4c"
      }, n.g.currentInject.render = function(e, t, n, r) {
        r("template", this.template) && (t("template.displayStyle", this.template.displayStyle), t("template.isDisplayMargin", this.template.isDisplayMargin), e(r("images", this.images), (function(e, n) {
          e.link.type ? (e.link, e.src, t("template.layoutType", this.template.layoutType)) : (e.src, t("template.layoutType", this.template.layoutType))
        }))), n()
      }
    },
    96261: function() {},
    25866: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_64e1eb4c", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(10993), n(96261), n(15925), n.g.currentSrcMode = "wx", n(84743)
    },
    84743: function(e, t, n) {
      n.r(t);
      var r = n(93690),
        p = n.n(r),
        a = n(39347);
      (0, n(69996).A)({
        properties: {
          template: Object
        },
        setup: function(e) {
          return {
            images: (0, a.E)((function() {
              var t;
              return p()(t = e.template.images).call(t, (function(e, t) {
                return {
                  key: t,
                  src: e.src,
                  link: e.link
                }
              }))
            }))
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 25866)
  }
]);