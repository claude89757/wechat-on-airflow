var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [4778], {
    27008: function() {},
    28332: function(e, n, t) {
      t.g.currentInject = {
        moduleId: "_674925da"
      }, t.g.currentInject.render = function(e, n, t, a) {
        a("show", this.show) ? ("场地卡面" == a("name", this.name) || "场地卡说明" == a("name", this.name) || "文本" == a("name", this.name) || "标题" == a("name", this.name) || "公告" == a("name", this.name) || "辅助线" == a("name", this.name) || "热区图" == a("name", this.name) || "左图右文" == a("name", this.name) || "魔方模块" == a("name", this.name) || "音频" == a("name", this.name) || "视频" == a("name", this.name) || "图标分类" == a("name", this.name) || "文字分类" == a("name", this.name) || "轮播图" == a("name", this.name) || "单列图" == a("name", this.name) || "分格海报" == a("name", this.name) || "多图滑动" == a("name", this.name)) && a("template", this.template) : a("height", this.height), t()
      }
    },
    13343: function(e, n, t) {
      t(97766), t.g.currentModuleId = "_674925da", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "component", t(28332), t(27008), t.g.currentSrcMode = "wx", t(31539)
    },
    31539: function(e, n, t) {
      var a = t(69996),
        i = t(5431),
        m = t(70841);
      (0, a.A)({
        properties: {
          name: String,
          template: Object,
          safeBottom: String
        },
        setup: function(e, n) {
          var t = function(e, n, t) {
            var a = (0, m.IJ)(!n);
            if (!a.value) {
              var i = e.createIntersectionObserver({});
              i.relativeToViewport({
                bottom: 500
              }).observe(".virtual-widget", (function() {
                a.value = !0, i.disconnect()
              }))
            }
            return {
              show: a,
              height: n
            }
          }(n, i.m[e.name]);
          return {
            show: t.show,
            height: t.height
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 13343)
  }
]);