var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [8610], {
    55805: function() {},
    39653: function(e, t, o) {
      o.g.currentInject = {
        moduleId: "_a7f4a6e0"
      }, o.g.currentInject.render = function(e, t, o, r) {
        r("template", this.template) && (t("template.displayStyle", this.template.displayStyle), r("video", this.video) ? (t("video.src", this.video.src), t("video.poster", this.video.poster)) : r("videoList", this.videoList) && e(r("videoList", this.videoList), (function(e, t) {
          e.src, e.poster
        }))), o()
      }
    },
    47247: function() {},
    36976: function(e, t, o) {
      o(97766), o.g.currentModuleId = "_a7f4a6e0", o.g.currentCtor = Component, o.g.currentCtorType = "component", o.g.currentResourceType = "component", o(39653), o(47247), o(55805), o.g.currentSrcMode = "wx", o(66393)
    },
    66393: function(e, t, o) {
      o.r(t);
      var r = o(93690),
        n = o.n(r),
        c = o(60192),
        i = o.n(c);
      (0, o(69996).A)({
        properties: {
          template: Object
        },
        setup: function(e) {
          var t, o, r, c = function(t, o) {
            return e.template.isShowCover && o ? o : /.mp4$/.test(t) ? t.replace(/.mp4$/, ".jpg") : ""
          };
          switch (e.template.layoutType) {
            case 0:
              o = {
                src: e.template.video,
                poster: c(e.template.video, e.template.videoCover)
              };
              break;
            case 1:
              r = n()(t = e.template.videos).call(t, (function(e, t) {
                var o;
                return {
                  key: i()(o = "".concat(t, "-")).call(o, e.src),
                  src: e.src,
                  poster: c(e.src, e.cover)
                }
              }))
          }
          return {
            video: o,
            videoList: r
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 36976)
  }
]);