var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [2787], {
    77124: function() {},
    45082: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_438beb92"
      }, r.g.currentInject.render = function(n, e, r, t) {
        t("name", this.name), r()
      }
    },
    47114: function() {},
    32566: function() {},
    82643: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_438beb92", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(45082), r(32566), r(47114), r(77124), r.g.currentSrcMode = "wx", r(25136)
    },
    25136: function(n, e, r) {
      r.r(e), (0, r(69996).A)({
        properties: {
          name: String
        }
      })
    }
  },
  function(n) {
    n(n.s = 82643)
  }
]);