var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [9219], {
    59233: function() {},
    4704: function(e, n, r) {
      r.g.currentInject = {
        moduleId: "_7509866a"
      }, r.g.currentInject.render = function(e, n, r, t) {
        t("qrcodeImage", this.qrcodeImage), r()
      }
    },
    29471: function() {},
    28130: function(e, n, r) {
      r(97766), r.g.currentModuleId = "_7509866a", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(4704), r(29471), r(59233), r.g.currentSrcMode = "wx", r(58343)
    },
    58343: function(e, n, r) {
      r.r(n);
      var t = r(39347),
        c = r(69996),
        o = r(9087),
        u = r.n(o);
      (0, c.A)({
        properties: {
          code: String,
          size: {
            type: Number,
            value: 200
          }
        },
        setup: function(e) {
          return {
            qrcodeImage: (0, t.E)((function() {
              var n = u()(0, "L");
              return n.addData(e.code), n.make(), n.createDataURL(20, 0)
            }))
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 28130)
  }
]);