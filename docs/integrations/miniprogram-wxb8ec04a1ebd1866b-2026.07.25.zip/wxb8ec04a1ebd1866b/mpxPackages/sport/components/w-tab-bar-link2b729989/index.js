var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [4573], {
    79784: function() {},
    1923: function(n, t, e) {
      e.g.currentInject = {
        moduleId: "_2b729989"
      }, e.g.currentInject.render = function(n, t, e, c) {
        c("isContactBtn", this.isContactBtn), e()
      }
    },
    88536: function() {},
    28793: function(n, t, e) {
      e(97766), e.g.currentModuleId = "_2b729989", e.g.currentCtor = Component, e.g.currentCtorType = "component", e.g.currentResourceType = "component", e(1923), e(88536), e(79784), e.g.currentSrcMode = "wx", e(20336)
    },
    20336: function(n, t, e) {
      e.r(t);
      var c = e(57187),
        o = e(69996),
        r = e(50791);
      (0, o.A)({
        properties: {
          link: Object
        },
        setup: function(n, t) {
          var e = t.triggerEvent,
            o = (0, r.i)(n.link),
            i = o.isContactBtn,
            u = o.checkLink;
          return {
            isContactBtn: i,
            onTapLink: function() {
              e("taplink"), u((function() {
                c.F.navigateTo(n.link)
              }))
            },
            onTapContact: function() {
              e("taplink")
            }
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 28793)
  }
]);