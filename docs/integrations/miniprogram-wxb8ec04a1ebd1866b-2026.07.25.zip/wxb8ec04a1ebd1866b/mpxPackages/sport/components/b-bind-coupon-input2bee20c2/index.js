require("../../../../@babel/runtime/helpers/Arrayincludes");
var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [6242], {
    70032: function() {},
    10840: function(e, n, o) {
      var u = o(87843);
      o.g.currentInject = {
        moduleId: "_2bee20c2"
      }, o.g.currentInject.render = function(e, n, o, t) {
        t("icon", this.icon), t("placeholder", this.placeholder), t("couponCode", this.couponCode), t("couponCode", this.couponCode), t("bindCouponCodePending", this.bindCouponCodePending), t("popupShow", this.popupShow), e(t("couponList", this.couponList), (function(e, n) {
          e.code, e.bonded || u.includes(t("selectedCodes", this.selectedCodes), e.code)
        })), t("selectedCodes", this.selectedCodes).length, t("bindCouponCodePending", this.bindCouponCodePending), o()
      }
    },
    15593: function() {},
    77659: function(e, n, o) {
      o(97766), o.g.currentModuleId = "_2bee20c2", o.g.currentCtor = Component, o.g.currentCtorType = "component", o.g.currentResourceType = "component", o(10840), o(15593), o(70032), o.g.currentSrcMode = "wx", o(8188)
    },
    8188: function(e, n, o) {
      o.r(n);
      var u = o(27715),
        t = o(93690),
        c = o.n(t),
        r = o(78475),
        d = o.n(r),
        p = o(74058),
        i = o.n(p),
        s = o(60192),
        l = o.n(s),
        a = o(39164),
        C = o(11821),
        h = o(70841);
      (0, o(69996).A)({
        properties: {
          type: Number,
          icon: String,
          placeholder: String
        },
        setup: function(e, n) {
          var o = n.triggerEvent,
            t = (0, a.JX)(),
            r = (0, C.B8)("CustomerAccount/BindCouponCode"),
            p = r.pending,
            s = r.error,
            g = r.execute;
          (0, a.FB)([s]);
          var v = (0, h.IJ)(""),
            f = (0, h.IJ)([]),
            b = function() {
              t.toast({
                title: "兑换成功"
              }), o("success")
            },
            m = (0, h.IJ)(!1),
            y = (0, h.IJ)([]);
          return {
            bindCouponCodePending: p,
            couponCode: v,
            couponList: f,
            onPressBindCouponBtn: function() {
              v.value && g({
                codeType: e.type,
                code: v.value
              }).then((function(e) {
                var n;
                e.result.QueryExchangeOrderCouponResult && e.result.QueryExchangeOrderCouponResult.result.length > 0 ? (f.value = c()(n = e.result.QueryExchangeOrderCouponResult.result).call(n, (function(e) {
                  return {
                    code: e.thirdCouponCode,
                    bonded: e.isExchangeSuccess
                  }
                })), m.value = !0) : b()
              }))
            },
            popupShow: m,
            selectedCodes: y,
            onMaskTap: function() {
              m.value = !1
            },
            onTapCouponPopupItem: function(e) {
              var n, o, t, c = e.code;
              e.bonded || (d()(n = y.value).call(n, c) ? y.value = i()(o = y.value).call(o, (function(e) {
                return e !== c
              })) : y.value = l()(t = []).call(t, (0, u.A)(y.value), [c]))
            },
            onPressBindSelectedCouponBtn: function() {
              g({
                codeType: e.type,
                code: v.value,
                v: 1,
                codes: y.value
              }).then((function() {
                m.value = !1, b()
              }))
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 77659)
  }
]);