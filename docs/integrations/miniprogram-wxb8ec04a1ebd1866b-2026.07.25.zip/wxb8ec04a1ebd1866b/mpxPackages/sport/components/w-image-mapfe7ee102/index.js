var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [518], {
    42498: function() {},
    38805: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_fe7ee102"
      }, n.g.currentInject.render = function(e, t, n, a) {
        a("template", this.template) && (t("template.displayStyle", this.template.displayStyle), "0" == t("template.selectedTabId", this.template.selectedTabId) ? (t("template.images", this.template.images), a("scopeId", this.scopeId), t("template.isShowChangeBtn", this.template.isShowChangeBtn)) : "1" == t("template.selectedTabId", this.template.selectedTabId) && (t("template.images", this.template.images), a("scopeId", this.scopeId), t("template.isDisplayMargin", this.template.isDisplayMargin))), n()
      }
    },
    21475: function() {},
    86593: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_fe7ee102", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(38805), n(21475), n(42498), n.g.currentSrcMode = "wx", n(75678)
    },
    75678: function(e, t, n) {
      n.r(t);
      var a = n(69996),
        p = n(11215),
        s = n(45184),
        c = n(57187);
      (0, a.A)({
        properties: {
          template: Object
        },
        setup: function(e) {
          var t = (0, s.G)((function() {
            return c.F.getSubscribeMessage()
          }));
          return {
            scopeId: (0, p.P)((function(n) {
              e.template.randomId && e.template.subscribeTemplates ? t(e.template.subscribeTemplates).then((function() {
                n()
              })) : n()
            }))
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 86593)
  }
]);