var e = require("../../../../@babel/runtime/helpers/slicedToArray"),
  t = require("../../../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../../../@babel/runtime/helpers/classCallCheck"),
  i = require("../../../../@babel/runtime/helpers/createClass"),
  o = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper"),
  a = require("../../../../@babel/runtime/helpers/typeof"),
  c = {};
c.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (c.webpackChunk_mpxapp_decoration = c.webpackChunk_mpxapp_decoration || []).push([
  [8886], {
    1679: function() {},
    45597: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_0406a74f"
      }, n.g.currentInject.render = function(e, t, n, r) {
        r("info", this.info) && (r("show", this.show), r("posterImage", this.posterImage) && r("posterImage", this.posterImage)), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "posterCanvas",
          selector: ".ref_posterCanvas_1",
          type: "node",
          all: !1
        }]
      }
    },
    78029: function() {},
    73338: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_0406a74f", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(45597), n(78029), n(1679), n.g.currentSrcMode = "wx", n(78433)
    },
    78433: function(c, s, u) {
      var l = u(49466),
        f = u(43955),
        h = u.n(f),
        p = u(60192),
        d = u.n(p),
        v = u(57391),
        g = u.n(v),
        m = u(69996),
        y = u(40519),
        w = u(61740),
        b = u(39164),
        x = u(9087),
        k = u.n(x),
        C = u(84665),
        j = u.n(C),
        I = function() {
          var e = {};
          return e.promise = new Promise((function(t, n) {
            e.resolve = t, e.reject = n
          })), e
        },
        O = function(e) {
          return "function" == typeof e
        },
        P = function(e) {
          return a(e) > "u"
        };

      function T(e, t) {
        var n, r = t.validate,
          i = t.interval,
          o = t.retries,
          c = t.onCancel,
          s = t.onSuccess,
          u = t.onFail,
          l = I(),
          f = l.promise,
          h = l.resolve,
          p = l.reject,
          d = 0,
          v = function(e) {
            O(r) && r(e) ? (O(s) && s(e), h(e)) : (O(o) ? o({
              retried: d
            }) : d !== o) ? n = setTimeout(g, O(i) ? i({
              retried: d
            }) : i) : (O(u) && u(e), p(e)), d++
          },
          g = function() {
            var t = e({
              retried: d,
              cancel: m
            });
            ! function(e) {
              return function(e) {
                return null !== e && "object" == a(e)
              }(e) && O(e.then) && O(e.catch)
            }(t) ? v(t): t.then(v).catch(v)
          },
          m = function() {
            clearTimeout(n), O(c) && c()
          };
        return g(), Object.assign(f, {
          cancel: m
        })
      }

      function S(e, t, n) {
        var r = 0;
        return function i() {
          return e().then((function(e) {
            return r = 0, e
          })).catch((function(e) {
            if (r >= t) throw e;
            var o = n ? function(e, t) {
              return new Promise((function(n) {
                return setTimeout((function() {
                  n(null == t ? void 0 : t())
                }), e)
              }))
            }(O(n) ? n({
              retried: r
            }) : n, i) : i();
            return r++, o
          }))
        }()
      }
      T.create = function() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        return function() {
          return T.apply(void 0, t)
        }
      }, S.create = function() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        return function() {
          return S.apply(void 0, t)
        }
      };
      var A = Object.defineProperty,
        M = Object.defineProperties,
        F = Object.getOwnPropertyDescriptors,
        R = Object.getOwnPropertySymbols,
        z = Object.prototype.hasOwnProperty,
        H = Object.prototype.propertyIsEnumerable,
        D = function(e, t, n) {
          return t in e ? A(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
          }) : e[t] = n
        },
        _ = function(e, t) {
          for (var n in t || (t = {})) z.call(t, n) && D(e, n, t[n]);
          if (R) {
            var r, i = o(R(t));
            try {
              for (i.s(); !(r = i.n()).done;) {
                n = r.value;
                H.call(t, n) && D(e, n, t[n])
              }
            } catch (e) {
              i.e(e)
            } finally {
              i.f()
            }
          }
          return e
        },
        q = function(e, t) {
          return M(e, F(t))
        },
        E = "object" == ("undefined" == typeof wx ? "undefined" : a(wx)),
        W = "object" == ("undefined" == typeof my ? "undefined" : a(my)),
        B = function() {
          var e;
          return E ? e = wx : W && (e = my), e
        }(),
        Y = Object.defineProperty,
        L = Object.defineProperties,
        N = Object.getOwnPropertyDescriptors,
        G = Object.getOwnPropertySymbols,
        U = Object.prototype.hasOwnProperty,
        V = Object.prototype.propertyIsEnumerable,
        J = function(e, t, n) {
          return t in e ? Y(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
          }) : e[t] = n
        },
        K = function(e, t) {
          for (var n in t || (t = {})) U.call(t, n) && J(e, n, t[n]);
          if (G) {
            var r, i = o(G(t));
            try {
              for (i.s(); !(r = i.n()).done;) {
                n = r.value;
                V.call(t, n) && J(e, n, t[n])
              }
            } catch (e) {
              i.e(e)
            } finally {
              i.f()
            }
          }
          return e
        },
        Q = function(e, t, n) {
          for (; e < t;) {
            var r = e + (t - e >> 1);
            n(r) ? t = r : e = r + 1
          }
          return t - 1
        },
        X = function(e) {
          var t = e.left,
            n = e.textAlign,
            r = e.textWidth,
            i = e.width;
          if (P(i)) return t;
          var o = i - (r || 0);
          switch (n) {
            case "center":
              return t + o / 2;
            case "right":
              return t + o;
            default:
              return t
          }
        },
        Z = function(e, t) {
          if (P(t)) return e;
          var n = O(e.left) ? e.left() : e.left,
            r = O(e.top) ? e.top() : e.top;
          return function(e, t) {
            return L(e, N(t))
          }(K({}, e), {
            left: t.left + n,
            top: t.top + r
          })
        },
        $ = function(e) {
          var t = K({}, e);
          return O(e.left) && (t.left = e.left()), O(e.top) && (t.top = e.top()), t
        },
        ee = Object.defineProperty,
        te = Object.defineProperties,
        ne = Object.getOwnPropertyDescriptors,
        re = Object.getOwnPropertySymbols,
        ie = Object.prototype.hasOwnProperty,
        oe = Object.prototype.propertyIsEnumerable,
        ae = function(e, t, n) {
          return t in e ? ee(e, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: n
          }) : e[t] = n
        },
        ce = function(e, t) {
          for (var n in t || (t = {})) ie.call(t, n) && ae(e, n, t[n]);
          if (re) {
            var r, i = o(re(t));
            try {
              for (i.s(); !(r = i.n()).done;) {
                n = r.value;
                oe.call(t, n) && ae(e, n, t[n])
              }
            } catch (e) {
              i.e(e)
            } finally {
              i.f()
            }
          }
          return e
        },
        se = function() {
          function a(e, t) {
            r(this, a), this.images = new Map, this.fonts = new Map, this.sizes = new Map, this.canvas = e, this.context = e.getContext("2d"), this.options = t
          }
          var c, s, u, l, f;
          return i(a, [{
            key: "render",
            value: (f = n(t().mark((function e(n) {
              var r, i, o, a, c, s, u, l;
              return t().wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = this.canvas, i = this.context, o = this.options, a = ce(ce({}, o), n), c = a.width, s = a.height, u = a.pixelRatio, l = void 0 === u ? 1 : u, c && s) {
                      e.next = 3;
                      break
                    }
                    throw Error("缺少 width 或 height 参数");
                  case 3:
                    return r.width = c * l, r.height = s * l, i.scale(l, l), e.next = 8, this.renderContainer(function(e, t) {
                      return te(e, ne(t))
                    }(ce({
                      type: "container"
                    }, n), {
                      left: 0,
                      top: 0,
                      width: c,
                      height: s
                    }));
                  case 8:
                  case "end":
                    return e.stop()
                }
              }), e, this)
            }))), function(e) {
              return f.apply(this, arguments)
            })
          }, {
            key: "draw",
            value: (l = n(t().mark((function e(n) {
              var r, i, a;
              return t().wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.prev = 0, !Array.isArray(n)) {
                      e.next = 21;
                      break
                    }
                    r = o(n), e.prev = 3, r.s();
                  case 5:
                    if ((i = r.n()).done) {
                      e.next = 11;
                      break
                    }
                    return a = i.value, e.next = 9, this.draw(a);
                  case 9:
                    e.next = 5;
                    break;
                  case 11:
                    e.next = 16;
                    break;
                  case 13:
                    e.prev = 13, e.t0 = e.catch(3), r.e(e.t0);
                  case 16:
                    return e.prev = 16, r.f(), e.finish(16);
                  case 19:
                    e.next = 33;
                    break;
                  case 21:
                    if (e.t1 = "container" === n.type, !e.t1) {
                      e.next = 25;
                      break
                    }
                    return e.next = 25, this.renderContainer($(n));
                  case 25:
                    if (e.t2 = "image" === n.type, !e.t2) {
                      e.next = 29;
                      break
                    }
                    return e.next = 29, this.renderImage($(n));
                  case 29:
                    if (e.t3 = "text" === n.type, !e.t3) {
                      e.next = 33;
                      break
                    }
                    return e.next = 33, this.renderText($(n));
                  case 33:
                    e.next = 37;
                    break;
                  case 35:
                    e.prev = 35, e.t4 = e.catch(0);
                  case 37:
                  case "end":
                    return e.stop()
                }
              }), e, this, [
                [0, 35],
                [3, 13, 16, 19]
              ])
            }))), function(e) {
              return l.apply(this, arguments)
            })
          }, {
            key: "renderContainer",
            value: (u = n(t().mark((function e(n) {
              var r, i, a, c, s, u, l, f, h, p, d, v, g, m;
              return t().wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = this.context, i = n.left, a = n.top, c = n.width, s = n.height, u = n.backgroundColor, l = n.borderRadius, f = void 0 === l ? 0 : l, h = n.overflow, p = n.children, r.save(), this.drawRoundedRect(i, a, c, s, f), r.clip(), u && (r.fillStyle = u, r.fillRect(i, a, c, s)), "hidden" !== h && r.restore(), ! function(e) {
                        return Array.isArray(e) && e.length > 0
                      }(p)) {
                      e.next = 21;
                      break
                    }
                    this.loadAssets(p), d = o(p), e.prev = 4, d.s();
                  case 6:
                    if ((v = d.n()).done) {
                      e.next = 13;
                      break
                    }
                    return g = v.value, m = Z(g, {
                      left: i,
                      top: a
                    }), e.next = 11, this.draw(m);
                  case 11:
                    e.next = 6;
                    break;
                  case 13:
                    e.next = 18;
                    break;
                  case 15:
                    e.prev = 15, e.t0 = e.catch(4), d.e(e.t0);
                  case 18:
                    return e.prev = 18, d.f(), e.finish(18);
                  case 21:
                    "hidden" === h && r.restore();
                  case 22:
                  case "end":
                    return e.stop()
                }
              }), e, this, [
                [4, 15, 18, 21]
              ])
            }))), function(e) {
              return u.apply(this, arguments)
            })
          }, {
            key: "renderImage",
            value: (s = n(t().mark((function n(r) {
              var i, o, a, c, s, u, l, f, h, p, d, v, g, m, y, w, b, x, k, C, j;
              return t().wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = this.context, o = r.src, a = r.backgroundColor, c = r.borderRadius, s = void 0 === c ? 0 : c, u = r.objectFit, l = void 0 === u ? "fill" : u, f = this.images.get(o), h = e(f, 2), p = h[0], d = h[1], v = r.left, g = r.top, m = r.width, y = r.height, t.next = 4, d;
                  case 4:
                    i.save(), this.drawRoundedRect(v, g, m, y, s), i.clip(), a && (i.fillStyle = a, i.fillRect(v, g, m, y)), w = p.width / p.height, b = m / y, "fill" === l || w === b || "contain" !== l && "cover" !== l || (("contain" === l ? w > b : w < b) ? (x = p.width / m, k = y, y = p.height / x, g += .5 * (k - y)) : (C = p.height / y, j = m, m = p.width / C, v += .5 * (j - m))), i.drawImage(p, v, g, m, y), i.restore();
                  case 11:
                  case "end":
                    return t.stop()
                }
              }), n, this)
            }))), function(e) {
              return s.apply(this, arguments)
            })
          }, {
            key: "renderText",
            value: (c = n(t().mark((function e(n) {
              var r, i, o, a, c, s, u, l, f, h, p, d, v, g, m, y, w, b, x, k, C, j;
              return t().wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = this.context, i = n.id, o = n.content, a = n.left, c = n.top, s = n.width, u = n.fontSize, l = void 0 === u ? 14 : u, f = n.lineHeight, h = void 0 === f ? 1.43 * l : f, p = n.color, d = void 0 === p ? "#333" : p, v = n.fontFamily, g = void 0 === v ? "sans-serif" : v, m = n.fontWeight, y = void 0 === m ? 400 : m, w = n.fontSrc, b = n.textAlign, x = void 0 === b ? "left" : b, k = n.textDecoration, e.t0 = w, !e.t0) {
                      e.next = 5;
                      break
                    }
                    return e.next = 5, this.fonts.get(w);
                  case 5:
                    r.save(), s && (r.textAlign = x), r.textBaseline = "alphabetic", r.fillStyle = d, r.font = "".concat(y, " ").concat(l, "px ").concat(g), C = X({
                      left: a,
                      textAlign: x,
                      width: s
                    }), (j = s ? this.getAllLines(n) : [o]).forEach((function(e, t) {
                      var n = c + (h - l) / 2 + h * t;
                      if (r.fillText(e, C, n + l), "line-through" === k) {
                        var i = r.measureText(e).width,
                          o = X({
                            left: a,
                            textAlign: x,
                            textWidth: i,
                            width: s
                          });
                        r.fillRect(o, n + .64 * l, i, l / 14)
                      }
                    })), i && this.sizes.set(i, {
                      width: s || r.measureText(o).width,
                      height: h * j.length
                    }), r.restore();
                  case 12:
                  case "end":
                    return e.stop()
                }
              }), e, this)
            }))), function(e) {
              return c.apply(this, arguments)
            })
          }, {
            key: "getAllLines",
            value: function(e) {
              for (var t = this.context, n = e.width, r = e.content, i = e.lineClamp, o = void 0 === i ? 1 / 0 : i, a = r.length, c = [], s = 0; s < a && c.length < o;) {
                var u = s;
                (s = Q(s, a, (function(e) {
                  return t.measureText(r.slice(s, e + 1)).width > n
                })) + 1) === u && (s = u + 1), o === c.length + 1 && s < a ? c.push(r.slice(u, s - 1) + "...") : c.push(r.slice(u, s))
              }
              return c
            }
          }, {
            key: "getSize",
            value: function(e) {
              return this.sizes.get(e)
            }
          }, {
            key: "drawRoundedRect",
            value: function(t, n, r, i, o) {
              var a = this.context;
              "number" == typeof o ? o = [o, o, o, o] : 1 === o.length ? o = [o[0], o[0], o[0], o[0]] : 2 === o.length ? o = [o[0], o[1], o[0], o[1]] : 3 === o.length && (o = [o[0], o[1], o[2], o[1]]);
              var c = o.map((function(e) {
                  return Math.min(e, r / 2, i / 2)
                })),
                s = e(c, 4),
                u = s[0],
                l = s[1],
                f = s[2],
                h = s[3];
              a.save(), a.translate(t, n), a.beginPath(), a.moveTo(u, 0), a.lineTo(r - l, 0), a.arc(r - l, l, l, 3 * Math.PI / 2, 0, !1), a.lineTo(r, i - f), a.arc(r - f, i - f, f, 0, Math.PI / 2, !1), a.lineTo(h, i), a.arc(h, i - h, h, Math.PI / 2, Math.PI, !1), a.lineTo(0, u), a.arc(u, u, u, Math.PI, 3 * Math.PI / 2, !1), a.closePath(), a.restore()
            }
          }, {
            key: "loadAssets",
            value: function(e) {
              var t = this;
              e.forEach((function(e) {
                var n = e.type;
                "image" === n && t.loadImage(e), "text" === n && e.fontFamily && e.fontSrc && t.loadFont(e)
              }))
            }
          }, {
            key: "loadImage",
            value: function(e) {
              var t = e.src;
              if (!this.images.has(t)) {
                var n = this.canvas.createImage();
                n.src = t, this.images.set(t, [n, new Promise((function(e, t) {
                  n.onload = e, n.onerror = t
                }))])
              }
            }
          }, {
            key: "loadFont",
            value: function(e) {
              var t = e.fontFamily,
                n = e.fontSrc;
              this.fonts.has(n) || this.fonts.set(n, function(e) {
                var t = e.fontFamily,
                  n = e.fontSrc,
                  r = I(),
                  i = r.resolve,
                  o = r.reject,
                  a = r.promise;
                return B ? B.loadFontFace(q(_({
                  family: t,
                  source: "url('".concat(n, "')")
                }, E && {
                  scopes: ["native"]
                }), {
                  success: i,
                  fail: o
                })) : o("platform sdk not found"), a
              }({
                fontFamily: t,
                fontSrc: n
              }))
            }
          }, {
            key: "export",
            value: function(e) {
              var t = this.canvas;
              return function(e, t) {
                var n, r = I(),
                  i = r.resolve,
                  o = r.reject,
                  a = r.promise;
                return W ? n = e.toTempFilePath : E ? n = B.canvasToTempFilePath : o("platform sdk not found"), n && n(q(_(_({}, t), E && {
                  canvas: e
                }), {
                  success: i,
                  fail: o
                })), a
              }(t, ce({
                x: 0,
                y: 0,
                width: t.width,
                height: t.height,
                destWidth: t.width,
                destHeight: t.height
              }, e))
            }
          }]), a
        }(),
        ue = u(66855),
        le = u(98886),
        fe = u(39295),
        he = function(e) {
          for (var t = e.qr, n = e.left, r = e.top, i = e.size, o = t.getModuleCount(), a = Math.floor(i / (o + 0)), c = a * (o + 0), s = n + (i - c) / 2 + 0 * a, u = r + (i - c) / 2 + 0 * a, l = [{
              type: "container",
              left: n,
              top: r,
              width: i,
              height: i,
              backgroundColor: "#ffffff"
            }], f = 0; f < o; f += 1)
            for (var h = 0; h < o; h += 1) t.isDark(f, h) && l.push({
              type: "container",
              left: s + h * a,
              top: u + f * a,
              width: a,
              height: a,
              backgroundColor: "#000000"
            });
          return l
        };
      (0, m.A)({
        properties: {
          show: Boolean,
          info: Object
        },
        setup: function(e, t) {
          var n = t.refs,
            r = t.triggerEvent,
            i = (0, ue.Ct)({
              immediate: !1
            }),
            o = (0, w.e6)((0, l.A)(h().mark((function t() {
              var r, o, a, c, s, u, l, f, p, v, m, y, w, b, x, C, I, O, P, T, S, A;
              return h().wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.info) {
                      t.next = 1;
                      break
                    }
                    return t.abrupt("return", "");
                  case 1:
                    return a = e.info, c = a.apptItemId, s = a.classroomName, u = a.startDate, l = a.endData, f = a.storeId, p = a.storeName, v = a.storeAddress, t.next = 2, i.promise();
                  case 2:
                    return m = t.sent, y = m.primaryColor, t.next = 3, (0, fe.S1)("Store/GetUserConfig", {
                      params: {
                        userId: f,
                        configTypeNumber: 1408
                      }
                    }).then((function(e) {
                      var t;
                      return null === (t = e.result) || void 0 === t ? void 0 : t.configValue
                    }));
                  case 3:
                    return w = t.sent, (b = k()(0, "L")).addData("CDM".concat(c)), b.make(), x = he({
                      qr: b,
                      top: 24,
                      left: 41,
                      size: 220
                    }), C = d()(r = "".concat(j()(u).format("YYYY.MM.DD(ddd) HH:mm"), "-")).call(r, j()(l).format("HH:mm")), I = w ? "约场时间开始前".concat(w, "分钟至约场结束均可核销") : "约场时间开始至约场结束均可核销", O = d()(o = "".concat(s, "（")).call(o, p, "）"), P = v, t.next = 4, new(g())((function(e) {
                      return n.posterCanvas.fields({
                        node: !0
                      }, (function(t) {
                        return e(t.node)
                      })).exec()
                    }));
                  case 4:
                    return T = t.sent, S = new se(T, {
                      width: 302,
                      height: 500,
                      pixelRatio: 3
                    }), t.next = 5, S.render({
                      backgroundColor: "#fff",
                      borderRadius: 20,
                      overflow: "hidden",
                      children: [{
                        type: "container",
                        backgroundColor: y,
                        top: 0,
                        left: 0,
                        width: 302,
                        height: 94,
                        children: [{
                          type: "image",
                          top: 0,
                          left: 0,
                          width: 302,
                          height: 94,
                          src: (0, le.s)("img", "venue_poster_bg"),
                          objectFit: "cover"
                        }, {
                          type: "text",
                          content: "".concat(s, "入场码"),
                          top: 24,
                          left: 0,
                          width: 302,
                          color: "#ffffff",
                          fontSize: 17,
                          lineHeight: 26,
                          textAlign: "center",
                          lineClamp: 1
                        }, {
                          type: "text",
                          content: "请出示此码入场",
                          top: 54,
                          left: 0,
                          width: 302,
                          color: "#ffffff",
                          fontSize: 14,
                          lineHeight: 16,
                          textAlign: "center",
                          lineClamp: 1
                        }]
                      }, {
                        type: "container",
                        top: 94,
                        left: 0,
                        width: 302,
                        height: 264,
                        children: x
                      }, {
                        type: "container",
                        top: 358,
                        left: 32,
                        width: 238,
                        height: 1,
                        backgroundColor: "#f4f4f4"
                      }, {
                        type: "container",
                        top: 378,
                        left: 32,
                        width: 238,
                        height: 98,
                        children: [{
                          type: "container",
                          top: 0,
                          left: 0,
                          width: 238,
                          height: 35,
                          children: [{
                            type: "image",
                            src: (0, le.s)("img", "clock"),
                            top: 0,
                            left: 0,
                            width: 20,
                            height: 20
                          }, {
                            type: "text",
                            content: C,
                            top: 0,
                            left: 24,
                            width: 214,
                            color: "#333333",
                            fontSize: 14,
                            lineHeight: 20,
                            fontWeight: "bold"
                          }, {
                            type: "text",
                            content: I,
                            top: 22,
                            left: 24,
                            width: 214,
                            color: "#757575",
                            fontSize: 11,
                            lineHeight: 14
                          }]
                        }, {
                          type: "container",
                          top: 47,
                          left: 0,
                          width: 238,
                          height: 50,
                          children: [{
                            type: "image",
                            src: (0, le.s)("img", "venue"),
                            top: 0,
                            left: 0,
                            width: 20,
                            height: 20
                          }, {
                            type: "text",
                            content: O,
                            top: 0,
                            left: 24,
                            width: 214,
                            color: "#333333",
                            fontSize: 14,
                            lineHeight: 20,
                            fontWeight: "bold",
                            lineClamp: 1
                          }, {
                            type: "text",
                            content: P,
                            top: 22,
                            left: 24,
                            width: 214,
                            color: "#757575",
                            fontSize: 11,
                            lineHeight: 14,
                            lineClamp: 2
                          }]
                        }]
                      }]
                    });
                  case 5:
                    return t.next = 6, S.export({});
                  case 6:
                    return A = t.sent, t.abrupt("return", A.tempFilePath);
                  case 7:
                  case "end":
                    return t.stop()
                }
              }), t)
            })))),
            a = o.data,
            c = o.pending,
            s = o.error,
            u = o.execute;
          return (0, b.BU)([c]), (0, b.FB)([s]), (0, y.nT)((function() {
            e.show && u()
          })), {
            onTapPopupMask: function() {
              r("tapmask")
            },
            posterImage: a
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 73338)
  }
]);