var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [4743], {
    92025: function() {},
    24754: function(t, n, e) {
      e.g.currentInject = {
        moduleId: "_3dda3db2"
      }, e.g.currentInject.render = function(t, n, e, r) {
        t(r("list", this.list), (function(t, n) {
          r("tab", this.tab), t.link, 2 == t.customImgs.length ? t.customImgs[r("tab", this.tab) == n ? 1 : 0] : t.icons[r("tab", this.tab) == n ? 1 : 0], t.title || t.name
        })), e()
      }, e.g.currentInject.getRefsData = function() {
        return [{
          key: "tabBar",
          selector: ".ref_tabBar_1",
          type: "node",
          all: !1
        }]
      }
    },
    83232: function() {},
    45498: function(t, n, e) {
      e(97766), e.g.currentModuleId = "_3dda3db2", e.g.currentCtor = Component, e.g.currentCtorType = "component", e.g.currentResourceType = "component", e(24754), e(83232), e(92025), e.g.currentSrcMode = "wx", e(68431)
    },
    68431: function(t, n, e) {
      e.r(n);
      var r = e(57187),
        c = e(69996),
        o = e(6520);
      (0, c.A)({
        properties: {
          list: Array,
          tab: Number
        },
        setup: function(t, n) {
          var e = n.refs,
            c = n.triggerEvent;
          return (0, o.sV)((function() {
            e.tabBar.boundingClientRect((function(t) {
              c("update", {
                height: t.height,
                safeBottom: 0
              })
            })).exec()
          })), {
            onTapTab: function(n) {
              r.F.switchTab(n, t.list[n].link)
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 45498)
  }
]);