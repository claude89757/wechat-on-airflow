var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [3448], {
    93470: function() {},
    33705: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_14d44f29"
      }, n.g.currentInject.render = function(e, t, n, o) {
        o("moreLink", this.moreLink), o("scopeId", this.scopeId), o("showIcon", this.showIcon) && o("icon", this.icon), o("textStyle", this.textStyle), o("text", this.text), o("showMore", this.showMore), n()
      }
    },
    92744: function() {},
    29203: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_14d44f29", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(33705), n(92744), n(93470), n.g.currentSrcMode = "wx", n(828)
    },
    828: function(e, t, n) {
      n.r(t), (0, n(69996).A)({
        properties: {
          icon: String,
          text: String,
          textStyle: String,
          moreLink: Object,
          scopeId: Number,
          showMore: Boolean,
          showIcon: Boolean
        }
      })
    }
  },
  function(e) {
    e(e.s = 29203)
  }
]);