var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [5071], {
    433: function() {},
    62550: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_6d481cc8"
      }, n.g.currentInject.render = function(t, e, n, r) {
        r("template", this.template) && r("list", this.list) && (e("template.displayStyle", this.template.displayStyle), (0 == e("template.layoutType", this.template.layoutType) || 1 == e("template.layoutType", this.template.layoutType) || 2 == e("template.layoutType", this.template.layoutType)) && r("list", this.list)), n()
      }
    },
    75870: function() {},
    59166: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_6d481cc8", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(62550), n(75870), n(433), n.g.currentSrcMode = "wx", n(56379)
    },
    56379: function(t, e, n) {
      n.r(e);
      var r = n(49e3),
        c = n.n(r),
        p = n(17195),
        a = n.n(p),
        u = n(74058),
        o = n.n(u),
        l = n(82567),
        i = n.n(l),
        s = n(87802),
        y = n.n(s),
        f = n(39298),
        m = n(93690),
        d = n.n(m),
        h = n(60192),
        b = n.n(h);

      function T(t, e) {
        var n = c()(t);
        if (a()) {
          var r = a()(t);
          e && (r = o()(r).call(r, (function(e) {
            return i()(t, e).enumerable
          }))), n.push.apply(n, r)
        }
        return n
      }(0, n(69996).A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          var e;
          return {
            list: d()(e = t.template.list).call(e, (function(t, e) {
              var n;
              return function(t) {
                for (var e = 1; e < arguments.length; e++) {
                  var n = null != arguments[e] ? arguments[e] : {};
                  e % 2 ? T(Object(n), !0).forEach((function(e) {
                    (0, f.A)(t, e, n[e])
                  })) : y() ? Object.defineProperties(t, y()(n)) : T(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, i()(n, e))
                  }))
                }
                return t
              }({
                key: b()(n = "".concat(e, "-")).call(n, t.displayTitle)
              }, t)
            }))
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 59166)
  }
]);