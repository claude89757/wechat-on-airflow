var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [5587], {
    35479: function() {},
    45913: function(n, t, c) {
      c.g.currentInject = {
        moduleId: "_593593b4"
      }, c.g.currentInject.render = function(n, t, c, e) {
        e("isContactBtn", this.isContactBtn), e("custom", this.custom), c()
      }
    },
    84945: function() {},
    40528: function(n, t, c) {
      c(97766), c.g.currentModuleId = "_593593b4", c.g.currentCtor = Component, c.g.currentCtorType = "component", c.g.currentResourceType = "component", c(45913), c(84945), c(35479), c.g.currentSrcMode = "wx", c(69085)
    },
    69085: function(n, t, c) {
      c.r(t);
      var e = c(69996),
        o = c(50791),
        r = c(11215),
        u = c(57187);
      (0, e.A)({
        properties: {
          link: Object,
          custom: String,
          scopeId: Number
        },
        setup: function(n) {
          var t = (0, o.i)(n.link),
            c = t.isContactBtn,
            e = t.checkLink,
            i = n.scopeId && (0, r.V)(n.scopeId),
            p = function() {
              e((function() {
                n.link.type && u.F.navigateTo(n.link)
              }))
            };
          return {
            isContactBtn: c,
            onTapLink: function() {
              i ? i(p) : p()
            }
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 40528)
  }
]);