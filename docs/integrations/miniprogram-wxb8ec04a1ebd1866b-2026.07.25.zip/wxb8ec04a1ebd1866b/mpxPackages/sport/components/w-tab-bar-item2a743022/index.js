var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [4887], {
    11085: function() {},
    89529: function(n, t, c) {
      c.g.currentInject = {
        moduleId: "_2a743022"
      }, c.g.currentInject.render = function(n, t, c, e) {
        e("isContactBtn", this.isContactBtn), c()
      }
    },
    19590: function() {},
    88128: function(n, t, c) {
      c(97766), c.g.currentModuleId = "_2a743022", c.g.currentCtor = Component, c.g.currentCtorType = "component", c.g.currentResourceType = "component", c(89529), c(19590), c(11085), c.g.currentSrcMode = "wx", c(13513)
    },
    13513: function(n, t, c) {
      c.r(t);
      var e = c(69996),
        o = c(50791);
      (0, e.A)({
        properties: {
          link: Object
        },
        setup: function(n, t) {
          var c = t.triggerEvent,
            e = (0, o.i)(n.link),
            r = e.isContactBtn,
            u = e.checkLink;
          return {
            isContactBtn: r,
            onTapTab: function() {
              c("taplink"), u((function() {
                c("taptab")
              }))
            },
            onTapContact: function() {
              c("taplink")
            }
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 88128)
  }
]);