var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [9860], {
    1279: function() {},
    97806: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_68380984"
      }, r.g.currentInject.render = function(n, e, r, t) {
        n(t("list", this.list), (function(n, e) {
          n.link, n.src, n.displayTitle
        })), r()
      }
    },
    58135: function() {},
    98164: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_68380984", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(97806), r(58135), r(1279), r.g.currentSrcMode = "wx", r(53937)
    },
    53937: function(n, e, r) {
      r.r(e), (0, r(69996).A)({
        properties: {
          list: Array
        }
      })
    }
  },
  function(n) {
    n(n.s = 98164)
  }
]);