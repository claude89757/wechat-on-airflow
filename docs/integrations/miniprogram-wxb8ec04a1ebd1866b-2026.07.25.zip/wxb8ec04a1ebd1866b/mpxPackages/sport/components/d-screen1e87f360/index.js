var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [560], {
    59794: function() {},
    45559: function(e, n, r) {
      r.g.currentInject = {
        moduleId: "_1e87f360"
      }, r.g.currentInject.render = function(e, n, r, t) {
        "场地预约" == t("name", this.name) && (t("query", this.query), t("safeBottom", this.safeBottom), t("sharedId", this.sharedId)), r()
      }
    },
    56674: function(e, n, r) {
      r(97766), r.g.currentModuleId = "_1e87f360", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(45559), r(59794), r.g.currentSrcMode = "wx", r(67658)
    },
    67658: function(e, n, r) {
      r.r(n), (0, r(69996).A)({
        properties: {
          name: String,
          query: Object,
          safeBottom: String,
          sharedId: Number
        }
      })
    }
  },
  function(e) {
    e(e.s = 56674)
  }
]);