var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [6170], {
    39107: function() {},
    66958: function(t, e, s) {
      s.g.currentInject = {
        moduleId: "_9b9713bc"
      }, s.g.currentInject.render = function(t, e, s, l) {
        l("template", this.template) && e("template.data", this.template.data) && (e("template.bgColor", this.template.bgColor), e("styles.titleStyle", this.styles.titleStyle), e("template.data.name", this.template.data.name), e("styles.contentStyle", this.styles.contentStyle), e("styles.colorStyle1", this.styles.colorStyle1), e("template.data.price", this.template.data.price), e("styles.colorStyle1", this.styles.colorStyle1), e("template.data.times", this.template.data.times), e("styles.colorStyle1", this.styles.colorStyle1), e("styles.colorStyle2", this.styles.colorStyle2), e("template.data.periodOfUse", this.template.data.periodOfUse), e("template.data.autoActiveDate", this.template.data.autoActiveDate) && e("template.data.autoActiveDate", this.template.data.autoActiveDate), e("styles.colorStyle1", this.styles.colorStyle1), e("styles.colorStyle2", this.styles.colorStyle2), e("template.data.ruleOfUse", this.template.data.ruleOfUse), e("template.data.usageForAll", this.template.data.usageForAll) ? (e("styles.colorStyle1", this.styles.colorStyle1), e("styles.colorStyle2", this.styles.colorStyle2), e("template.data.usageAssignmentUsers", this.template.data.usageAssignmentUsers).length) : (e("template.data.userProjects", this.template.data.userProjects).length && (e("styles.colorStyle1", this.styles.colorStyle1), e("template.data.userProjectsText", this.template.data.userProjectsText) && (e("styles.colorStyle2", this.styles.colorStyle2), e("template.data.userProjectsText", this.template.data.userProjectsText))), e("template.data.userClassrooms", this.template.data.userClassrooms).length && (e("styles.colorStyle1", this.styles.colorStyle1), e("template.data.userClassroomsText", this.template.data.userClassroomsText) && (e("styles.colorStyle2", this.styles.colorStyle2), e("template.data.userClassroomsText", this.template.data.userClassroomsText)))), e("template.data.usageLimitText", this.template.data.usageLimitText) && (e("styles.colorStyle1", this.styles.colorStyle1), e("styles.colorStyle2", this.styles.colorStyle2), e("template.data.usageLimitText", this.template.data.usageLimitText)), e("template.data.limitsText", this.template.data.limitsText).length && (e("styles.colorStyle1", this.styles.colorStyle1), e("styles.colorStyle2", this.styles.colorStyle2), t(e("template.data.limitsText", this.template.data.limitsText), (function(t, e) {}))), e("template.data.usageAssignmentUsers", this.template.data.usageAssignmentUsers).length && (l("isStorePopupShow", this.isStorePopupShow), t(e("template.data.usageAssignmentUsers", this.template.data.usageAssignmentUsers), (function(t, e) {
          t.userName, t.tel
        }))), e("template.data.userProjects", this.template.data.userProjects).length && (l("isProjectPopupShow", this.isProjectPopupShow), t(e("template.data.userProjects", this.template.data.userProjects), (function(t, e) {
          t.userName, t.tel, t.projectsText
        }))), e("template.data.userClassrooms", this.template.data.userClassrooms).length && (l("isClassroomPopupShow", this.isClassroomPopupShow), t(e("template.data.userClassrooms", this.template.data.userClassrooms), (function(t, e) {
          t.userName, t.tel, t.classroomsText
        }))), e("template.data.limitsText", this.template.data.limitsText).length && (l("isLimitPopupShow", this.isLimitPopupShow), t(e("template.data.limitsText", this.template.data.limitsText), (function(t, e) {})))), s()
      }
    },
    96845: function() {},
    80835: function(t, e, s) {
      s(97766), s.g.currentModuleId = "_9b9713bc", s.g.currentCtor = Component, s.g.currentCtorType = "component", s.g.currentResourceType = "component", s(66958), s(96845), s(39107), s.g.currentSrcMode = "wx", s(10169)
    },
    10169: function(t, e, s) {
      s.r(e);
      var l = s(39347),
        a = s(69996),
        o = s(61458),
        r = s(90356);
      (0, a.A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          var e = (0, l.E)((function() {
              var e = t.template,
                s = e.fontColor,
                l = e.fontSize,
                a = e.isBold;
              return {
                titleStyle: (0, r.W9)(l[0], s[0], a[0]),
                contentStyle: (0, r.W9)(l[1], s[1], a[1]),
                colorStyle1: "color: ".concat(s[1]),
                colorStyle2: "color: ".concat(s[2])
              }
            })),
            s = (0, o.C)(),
            a = s.value,
            i = s.open,
            p = s.close,
            m = (0, o.C)(),
            c = m.value,
            u = m.open,
            n = m.close,
            y = (0, o.C)(),
            h = y.value,
            d = y.open,
            S = y.close,
            g = (0, o.C)();
          return {
            styles: e,
            isStorePopupShow: a,
            openStorePopup: i,
            closeStorePopup: p,
            isProjectPopupShow: c,
            openProjectPopup: u,
            closeProjectPopup: n,
            isClassroomPopupShow: h,
            openClassroomPopup: d,
            closeClassroomPopup: S,
            isLimitPopupShow: g.value,
            openLimitPopup: g.open,
            closeLimitPopup: g.close
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 80835)
  }
]);