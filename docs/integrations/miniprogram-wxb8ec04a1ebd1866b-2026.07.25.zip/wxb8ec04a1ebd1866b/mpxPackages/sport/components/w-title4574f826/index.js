var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [9023], {
    23254: function() {},
    33102: function(t, e, p) {
      p.g.currentInject = {
        moduleId: "_4574f826"
      }, p.g.currentInject.render = function(t, e, p, l) {
        l("template", this.template) && (e("template.displayStyle", this.template.displayStyle), e("template.bgColor", this.template.bgColor), 0 == e("template.layoutType", this.template.layoutType) || 1 == e("template.layoutType", this.template.layoutType) ? (e("template.icon", this.template.icon), e("template.titleText", this.template.titleText), l("textStyle", this.textStyle), e("template.moreLink", this.template.moreLink), l("scopeId", this.scopeId), e("template.isShowMore", this.template.isShowMore), e("template.layoutType", this.template.layoutType)) : 2 != e("template.layoutType", this.template.layoutType) && 3 != e("template.layoutType", this.template.layoutType) || (e("template.icon", this.template.icon), e("template.titleText", this.template.titleText), l("textStyle", this.textStyle), e("template.moreLink", this.template.moreLink), l("scopeId", this.scopeId), e("template.isShowMore", this.template.isShowMore), e("template.layoutType", this.template.layoutType))), p()
      }
    },
    6733: function(t, e, p) {
      p(97766), p.g.currentModuleId = "_4574f826", p.g.currentCtor = Component, p.g.currentCtorType = "component", p.g.currentResourceType = "component", p(33102), p(23254), p.g.currentSrcMode = "wx", p(6382)
    },
    6382: function(t, e, p) {
      p.r(e);
      var l = p(69996),
        o = p(90356),
        a = p(11215),
        i = p(45184),
        n = p(57187);
      (0, l.A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          var e = (0, o.W9)(t.template.fontSize, t.template.fontColor, t.template.isBlod),
            p = (0, i.G)((function() {
              return n.F.getSubscribeMessage()
            }));
          return {
            textStyle: e,
            scopeId: (0, a.P)((function(e) {
              t.template.randomId && t.template.subscribeTemplates ? p(t.template.subscribeTemplates).then((function() {
                t.template.isShowMore && e()
              })) : e()
            }))
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 6733)
  }
]);