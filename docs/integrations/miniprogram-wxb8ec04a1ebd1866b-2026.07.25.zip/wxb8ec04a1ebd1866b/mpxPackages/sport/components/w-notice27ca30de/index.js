var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [1054], {
    35102: function() {},
    95832: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_27ca30de"
      }, n.g.currentInject.render = function(e, t, n, o) {
        o("template", this.template) && !o("closed", this.closed) && (t("template.displayStyle", this.template.displayStyle), t("template.bgColor", this.template.bgColor), t("template.link", this.template.link), o("scopeId", this.scopeId), t("template.fontColor", this.template.fontColor), "0" == t("template.selectedTabId", this.template.selectedTabId) && t("template.isShowClose", this.template.isShowClose), o("textOverflow", this.textOverflow), t("template.notice", this.template.notice), "1" == t("template.selectedTabId", this.template.selectedTabId) || "0" == t("template.selectedTabId", this.template.selectedTabId) && t("template.isShowClose", this.template.isShowClose)), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "noticeContent",
          selector: ".ref_noticeContent_1",
          type: "node",
          all: !1
        }, {
          key: "noticeText",
          selector: ".ref_noticeText_2",
          type: "node",
          all: !1
        }]
      }
    },
    37557: function() {},
    77355: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_27ca30de", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(95832), n(37557), n(35102), n.g.currentSrcMode = "wx", n(43008)
    },
    43008: function(e, t, n) {
      n.r(t);
      var o = n(70841),
        c = n(69996),
        l = n(6520),
        a = n(61458),
        i = n(11215),
        s = n(45184),
        p = n(57187);
      (0, c.A)({
        properties: {
          template: Object
        },
        setup: function(e, t) {
          var n = t.refs,
            c = (0, s.G)((function() {
              return p.F.getSubscribeMessage()
            })),
            r = (0, i.P)((function(t) {
              e.template.randomId && e.template.subscribeTemplates ? c(e.template.subscribeTemplates).then((function() {
                "1" === e.template.selectedTabId && t()
              })) : t()
            })),
            u = (0, a.C)(),
            d = u.value,
            m = u.open,
            h = (0, o.KR)(!1);
          return (0, l.sV)((function() {
            n.noticeContent.boundingClientRect((function(e) {
              n.noticeText.boundingClientRect((function(t) {
                t.width > e.width && (h.value = !0)
              })).exec()
            })).exec()
          })), {
            scopeId: r,
            closed: d,
            onCloseTap: m,
            textOverflow: h
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 77355)
  }
]);