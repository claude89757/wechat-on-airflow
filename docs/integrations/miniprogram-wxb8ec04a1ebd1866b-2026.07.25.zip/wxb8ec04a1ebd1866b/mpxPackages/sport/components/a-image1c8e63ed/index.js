var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [5753], {
    90255: function() {},
    16380: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_1c8e63ed"
      }, r.g.currentInject.render = function(n, e, r, t) {
        t("imageSrc", this.imageSrc), t("mode", this.mode), r()
      }
    },
    54525: function() {},
    36487: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_1c8e63ed", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(16380), r(54525), r(90255), r.g.currentSrcMode = "wx", r(90049)
    },
    90049: function(n, e, r) {
      var t = r(60192),
        c = r.n(t),
        a = r(69996),
        u = r(70841),
        o = r(39347),
        i = r(40519),
        l = r(53888),
        p = r(93690),
        f = r.n(p),
        s = r(80173),
        v = r.n(s);

      function d(n, e, r) {
        if (e) {
          var t = function(n, e) {
              var r, t = f()(r = e.split("x")).call(r, m),
                c = (0, l.A)(t, 2),
                a = c[0],
                u = void 0 === a ? 0 : a,
                o = c[1],
                i = void 0 === o ? 0 : o,
                p = g[n];
              if (p) {
                var s = v()(p).call(p, (function(n) {
                  var e = (0, l.A)(n, 2),
                    r = e[0],
                    t = e[1];
                  return (0 === r || r >= u && u > 0) && (0 === t || t >= i && i > 0)
                }));
                if (s) return s
              } else g[n] = p = [];
              var d = [u, i];
              return p.push(d), d
            }(e, r),
            c = (0, l.A)(t, 2),
            a = c[0],
            u = c[1];
          if (function(n) {
              return /^(https:)?\/\/(img|imgw|imgu).pospal.cn/.test(n)
            }(e)) return function(n, e, r, t) {
            switch (n) {
              case 0:
                return e.replace(/(_200x200|_640x640)/, "") + "!/format/webp" + h(r, t);
              case 1:
                return e.replace(/(_200x200|_640x640)/, "") + h(r, t);
              default:
                return e
            }
          }(n, e, a, u)
        }
        return e
      }
      var g = {};

      function m(n) {
        return n ? Math.round(2 * (parseInt(n, 10) || 0)) : 0
      }

      function h(n, e) {
        var r;
        return n > 0 && e > 0 ? c()(r = "/fwfh/".concat(n, "x")).call(r, e) : n > 0 ? "/fw/".concat(n) : e > 0 ? "/fh/".concat(e) : "/fw/".concat(750)
      }
      var _ = r(70026);
      (0, a.A)({
        properties: {
          src: String,
          name: String,
          alt: String,
          size: String,
          mode: {
            type: String,
            value: "scaleToFill"
          }
        },
        setup: function(n, e) {
          var r = e.triggerEvent,
            t = (0, u.KR)(!n.src),
            a = (0, u.KR)(0),
            l = (0, o.E)((function() {
              var e, r;
              return d(a.value, t.value && n.alt ? c()(e = "".concat(_.k.altBaseUrl)).call(e, n.alt, ".png") : n.src || n.name && c()(r = "".concat(_.k.imgBaseUrl)).call(r, n.name, ".png"), n.size)
            }));
          return (0, i.wB)((function() {
            return n.src
          }), (function(n) {
            a.value = 0, n ? t.value && (t.value = !1) : t.value || (t.value = !0)
          })), {
            imageSrc: l,
            onError: function(n) {
              /404 \(Not Found\)$/.test(n.detail.errMsg) && !t.value ? (t.value = !0, a.value = 0) : a.value < 9 && a.value++
            },
            onLoad: function(n) {
              r("load", n.detail)
            }
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 36487)
  }
]);