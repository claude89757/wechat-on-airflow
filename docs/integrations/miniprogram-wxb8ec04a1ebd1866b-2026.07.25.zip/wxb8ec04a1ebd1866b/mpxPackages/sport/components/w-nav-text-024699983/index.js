var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [3889], {
    59082: function() {},
    1594: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_24699983"
      }, n.g.currentInject.render = function(e, t, n, r) {
        r("fontStyle", this.fontStyle), e(r("list", this.list), (function(e, t) {
          e.link, e.displayTitle
        })), r("showArrow", this.showArrow) && r("background", this.background), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "scrollView",
          selector: ".ref_scrollView_1",
          type: "node",
          all: !1
        }, {
          key: "scrollContent",
          selector: ".ref_scrollContent_2",
          type: "node",
          all: !1
        }]
      }
    },
    91554: function() {},
    41711: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_24699983", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(1594), n(91554), n(59082), n.g.currentSrcMode = "wx", n(87648)
    },
    87648: function(e, t, n) {
      n.r(t);
      var r = n(70841),
        o = n(69996),
        c = n(6520);
      (0, o.A)({
        properties: {
          list: Array,
          fontStyle: String,
          background: String
        },
        setup: function(e, t) {
          var n = t.refs,
            o = t.createIntersectionObserver,
            i = (0, r.KR)(!1);
          return (0, c.sV)((function() {
            n.scrollView.boundingClientRect((function(e) {
              var t = e.width;
              n.scrollContent.boundingClientRect((function(e) {
                e.width > t && (i.value = !0, o({}).relativeTo(".nav-text-scroll").observe(".nav-text-obitem", (function(e) {
                  i.value = 0 === e.intersectionRatio
                })))
              })).exec()
            })).exec()
          })), {
            showArrow: i
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 41711)
  }
]);