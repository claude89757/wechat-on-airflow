var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [6664], {
    4676: function() {},
    11637: function(e, t, n) {
      var o = n(72244),
        r = n(29003);
      n.g.currentInject = {
        moduleId: "_0ec4e00c"
      }, n.g.currentInject.render = function(e, t, n, a) {
        a("showSelectHeader", this.showSelectHeader) && (a("meituanBookingMode", this.meituanBookingMode) || (a("storeLocation", this.storeLocation), a("showChainStore", this.showChainStore), a("currentStore", this.currentStore)), a("showProjectSelect", this.showProjectSelect) && r.g(a("selectedProject", this.selectedProject), ["name"])), a("calendarMinDate", this.calendarMinDate), a("calendarMaxDate", this.calendarMaxDate), a("advanceDays", this.advanceDays), a("currentTime", this.currentTime), a("selectedProject", this.selectedProject) && (a("selectedProject", this.selectedProject), a("venueSettingData", this.venueSettingData), a("allowedClassroomUids", this.allowedClassroomUids), a("venueTimeLimit", this.venueTimeLimit), a("showBookedAvatar", this.showBookedAvatar)), a("safeBottom", this.safeBottom), a("showSelectHeader", this.showSelectHeader) && (a("showProjectPopup", this.showProjectPopup), e(a("projectList", this.projectList), (function(e, t) {
          o.c("px-4 py-6 border-1 border-solid rounded-2 mb-2 bg-white flex items-center", r.g(a("selectedProject", this.selectedProject), ["txtUid"]) === e.txtUid ? "text-primary border-primary font-500" : "text-gray-33 border-gray-e8"), e.name, r.g(a("selectedProject", this.selectedProject), ["txtUid"]), e.txtUid
        }))), a("venueAppointmentNoticeContent", this.venueAppointmentNoticeContent) && (a("venueAppointmentNoticePopupShow", this.venueAppointmentNoticePopupShow), a("venueAppointmentNoticeContent", this.venueAppointmentNoticeContent)), n()
      }
    },
    33956: function() {},
    91993: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_0ec4e00c", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(11637), n(33956), n(4676), n.g.currentSrcMode = "wx", n(42674)
    },
    42674: function(e, t, n) {
      var o = n(49e3),
        r = n.n(o),
        a = n(17195),
        i = n.n(a),
        u = n(82567),
        l = n.n(u),
        c = n(87802),
        d = n.n(c),
        s = n(39298),
        v = n(27715),
        p = n(80492),
        m = n.n(p),
        f = n(74058),
        h = n.n(f),
        g = n(93690),
        y = n.n(g),
        S = n(57391),
        I = n.n(S),
        A = n(78475),
        C = n.n(A),
        j = n(69996),
        D = n(70841),
        P = n(39347),
        U = n(6520),
        w = n(40519),
        b = n(74665),
        N = n(61458),
        _ = n(61740),
        O = n(11821),
        x = n(39164),
        T = n(80535),
        B = n(84665),
        L = n.n(B),
        k = n(31328),
        M = n(39295),
        V = n(46902),
        E = n(88089),
        q = n(92345),
        Y = n(17942),
        R = n(41932),
        J = "THIRD_PARTY_COUPON_ORDER_VENUE_BOOKING",
        F = n(66855),
        H = n(79135),
        G = n(6355);

      function Q(e, t) {
        var n = r()(e);
        if (i()) {
          var o = i()(e);
          t && (o = h()(o).call(o, (function(t) {
            return l()(e, t).enumerable
          }))), n.push.apply(n, o)
        }
        return n
      }

      function K(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? Q(Object(n), !0).forEach((function(t) {
            (0, s.A)(e, t, n[t])
          })) : d() ? Object.defineProperties(e, d()(n)) : Q(Object(n)).forEach((function(t) {
            Object.defineProperty(e, t, l()(n, t))
          }))
        }
        return e
      }(0, j.A)({
        properties: {
          safeBottom: String,
          query: Object,
          sharedId: Number
        },
        setup: function(e) {
          var t = (0, b.r)(),
            n = (0, F.g3)(),
            o = (0, F.a1)({
              immediate: !1
            }),
            r = (0, H.bP)(n),
            a = r.data,
            i = r.pending,
            u = r.error,
            l = (0, H.bP)(o),
            c = l.pending,
            d = l.error,
            s = (0, q.s)(e.sharedId),
            p = L()().startOf("date").valueOf(),
            f = (0, D.IJ)(L()().startOf("date")),
            g = (0, P.E)({
              get: function() {
                return f.value.valueOf()
              },
              set: function(e) {
                f.value = L()(e)
              }
            }),
            S = (0, D.IJ)(),
            A = (0, N.C)(!1),
            j = A.value,
            B = A.close,
            Q = (0, D.IJ)(),
            W = !e.query.projectUid || !e.query.projectType,
            z = (0, D.IJ)(),
            X = (0, D.IJ)(W),
            Z = function() {
              return V.mp.removeStorage({
                key: J
              }).catch((function() {}))
            };
          if (W && V.mp.getStorage({
              key: J
            }).then((function(t) {
              var n, o, r = t.data,
                a = Array.isArray(null == r ? void 0 : r.classroomUids) ? (0, v.A)(new(m())(h()(n = y()(o = r.classroomUids).call(o, String)).call(n, Boolean))) : [],
                i = Number(null == r ? void 0 : r.storeId),
                u = Number(null == r ? void 0 : r.createdAt);
              "meituan" === (null == r ? void 0 : r.platform) && Boolean(r.couponCode) && a.length > 0 && i > 0 && i === Number(e.query.storeId) && u > 0 && Date.now() - u <= 6e5 ? z.value = K(K({}, r), {}, {
                classroomUids: a,
                storeId: i,
                createdAt: u
              }) : Z()
            })).catch((function() {})).finally((function() {
              X.value = !1
            })), (0, U.hi)((function() {
              z.value && (z.value = void 0, Z())
            })), !W) {
            var $ = (0, _.fV)((function() {
                return (0, M.S1)("Store/GetStoreDataFast", {
                  params: {
                    includeLatLon: !0,
                    igornVipCheck: !0
                  },
                  headers: {
                    storeId: e.query.storeId
                  }
                })
              }), {
                transform: Y.W,
                default: function() {
                  return Y.p
                }
              }),
              ee = $.data,
              te = $.pending,
              ne = $.error,
              oe = $.promise;
            (0, w.nT)((function() {
              if (!te.value && !i.value) {
                var e = ee.value,
                  t = a.value,
                  n = void 0 === e.venueappointmentnoticeForChildrenStore ? e.venueappointmentnotice : e.venueappointmentnoticeForChildrenStore,
                  o = void 0 === t._venueAppointmentNoticeSetting ? "1" === e.venueAppointmentNoticeSetting : "1" === t._venueAppointmentNoticeSetting;
                n && o && (j.value = !0, Q.value = n), S.value = "1" === t._showCourseAppointedAvatar
              }
            }));
            var re = (0, D.IJ)({
                id: 0,
                name: "",
                txtUid: e.query.projectUid,
                type: Number(e.query.projectType),
                userId: Number(e.query.storeId),
                _belongtUserId: Number(e.query.storeId)
              }),
              ae = (0, O._y)("AppointmentVenue/LoadValidClassRoomApptSettingV2", {
                params: function() {
                  return {
                    dateTime: f.value.format("YYYY-MM-DD"),
                    projectUid: re.value.txtUid,
                    userId: re.value._belongtUserId
                  }
                },
                transform: function(e) {
                  return e.result
                },
                default: function() {
                  return {
                    slots: [],
                    validClassRooms: [],
                    hasAppointTime: 0
                  }
                }
              }),
              ie = ae.data,
              ue = ae.pending,
              le = ae.error,
              ce = ae.execute,
              de = (0, O._y)("AppointmentVenue/AppointmentVenueConfig", {
                params: function() {
                  return {
                    storeId: Number(e.query.storeId)
                  }
                },
                transform: function(e) {
                  return e.result
                }
              }),
              se = de.data,
              ve = de.pending,
              pe = de.error,
              me = (0, P.E)((function() {
                var e, t;
                return null !== (e = null === (t = se.value) || void 0 === t ? void 0 : t.venueTimeLimit) && void 0 !== e ? e : 0
              })),
              fe = (0, P.E)((function() {
                var e, t = null === (e = se.value) || void 0 === e || null === (e = e.currentSetting) || void 0 === e ? void 0 : e.advanceDays;
                return void 0 !== t && t > 0 ? L()().add(t, "days").startOf("date").valueOf() : L()().add(60, "days").startOf("date").valueOf()
              })),
              he = (0, P.E)((function() {
                var e;
                return null === (e = se.value) || void 0 === e || null === (e = e.currentSetting) || void 0 === e ? void 0 : e.advanceDays
              })),
              ge = (0, G.J)(oe, o);
            return (0, x.BU)([i, c, te, ue, ve]), (0, x.FB)([u, d, ne, le, pe]), (0, T.c)(ce), {
              calendarMinDate: p,
              calendarMaxDate: fe,
              advanceDays: he,
              currentTime: g,
              venueAppointmentNoticePopupShow: j,
              venueAppointmentNoticePopupClose: B,
              venueAppointmentNoticeContent: Q,
              showSelectHeader: W,
              selectedProject: re,
              venueSettingData: ie,
              venueTimeLimit: me,
              onVenueBookingOrder: function(e) {
                var n;
                t.navigateTo({
                  page: "/sport/pages/venue-booking-payment",
                  query: {
                    largeQueryId: (0, R.AV)({
                      userId: re.value._belongtUserId,
                      projectType: re.value.type,
                      classrooms: y()(n = e.detail.slots).call(n, (function(e) {
                        return {
                          classroomUid: e.classroomUid,
                          beginDatetime: e.beginDatetime,
                          endDatetime: e.endDatetime,
                          peopleNum: e.peopleNum
                        }
                      }))
                    })
                  },
                  guard: ge
                })
              },
              showBookedAvatar: S
            }
          }
          var ye = (0, _.fV)((function() {
              return V.mp.getLocation({}).then((function(t) {
                return (0, M.S1)("Store/GetStoreDataFast", {
                  params: {
                    includeLatLon: !0,
                    igornVipCheck: !0,
                    includePointRule: !0,
                    latitude: t.latitude,
                    longitude: t.longitude
                  },
                  headers: {
                    storeId: e.query.storeId
                  }
                }).then((function(e) {
                  return I().resolve({
                    store: e,
                    location: t
                  })
                }))
              }), (function() {
                return (0, M.S1)("Store/GetStoreDataFast", {
                  params: {
                    includeLatLon: !0,
                    igornVipCheck: !0
                  },
                  headers: {
                    storeId: e.query.storeId
                  }
                }).then((function(e) {
                  return I().resolve({
                    store: e
                  })
                }))
              }))
            }), {
              transform: E.D,
              default: function() {
                return E.C
              }
            }),
            Se = ye.pending,
            Ie = ye.data,
            Ae = ye.error,
            Ce = ye.execute,
            je = ye.promise,
            De = (0, P.E)((function() {
              return Ie.value.location
            })),
            Pe = (0, P.E)((function() {
              var e = Ie.value.store;
              return e.IsChainStore && e.IsOpenMulMiniAppStore
            })),
            Ue = (0, D.IJ)({
              id: 0,
              name: "-",
              distance: "-"
            });
          (0, w.wB)(Ue, (function(e) {
            s.id = null == e ? void 0 : e.id
          })), (0, w.nT)((function() {
            var e, t = Ie.value.store;
            t.storeUserId && (Ue.value = {
              id: t.storeUserId,
              name: t.storeName,
              distance: (0, k.B)(null !== (e = t.distanceInMeter) && void 0 !== e ? e : 0)
            })
          })), (0, w.nT)((function() {
            if (!Se.value && !i.value) {
              var e = Ie.value.store,
                t = a.value,
                n = void 0 === e.venueappointmentnoticeForChildrenStore ? e.venueappointmentnotice : e.venueappointmentnoticeForChildrenStore,
                o = void 0 === t._venueAppointmentNoticeSetting ? "1" === e.venueAppointmentNoticeSetting : "1" === t._venueAppointmentNoticeSetting;
              n && o && (j.value = !0, Q.value = n), S.value = "1" === t._showCourseAppointedAvatar
            }
          }));
          var we = (0, O._y)("AppointmentVenue/LoadClassroomProjectList", {
              params: function() {
                return Ue.value ? {
                  userId: Ue.value.id
                } : _.Oy
              },
              transform: function(e) {
                var t, n = e.data,
                  o = e.params;
                return y()(t = n.result).call(t, (function(e) {
                  return K(K({}, e), {}, {
                    _belongtUserId: o.userId
                  })
                }))
              },
              default: function() {
                return []
              }
            }, {
              details: !0
            }),
            be = we.data,
            Ne = we.pending,
            _e = we.error,
            Oe = (0, P.E)((function() {
              return be.value
            })),
            xe = (0, D.IJ)(),
            Te = (0, N.C)(!1),
            Be = Te.value,
            Le = Te.toggle,
            ke = (0, O._y)("AppointmentVenue/LoadValidClassRoomApptSettingV2", {
              params: function() {
                return X.value ? _.Oy : z.value ? {
                  dateTime: f.value.format("YYYY-MM-DD"),
                  userId: z.value.storeId
                } : xe.value ? {
                  dateTime: f.value.format("YYYY-MM-DD"),
                  userId: xe.value._belongtUserId,
                  projectUid: xe.value.txtUid
                } : _.Oy
              },
              transform: function(e) {
                return e.result
              },
              default: function() {
                return {
                  slots: [],
                  validClassRooms: [],
                  hasAppointTime: 0
                }
              }
            }),
            Me = ke.data,
            Ve = ke.pending,
            Ee = ke.error,
            qe = ke.execute,
            Ye = (0, P.E)((function() {
              var e;
              return (null === (e = z.value) || void 0 === e ? void 0 : e.classroomUids) || []
            })),
            Re = (0, P.E)((function() {
              var e, t;
              if (!Ye.value.length) return [];
              var n = new(m())(Ye.value);
              return (0, v.A)(new(m())(y()(e = h()(t = Me.value.slots).call(t, (function(e) {
                var t;
                return n.has(e.txtClassroomUid) || (null === (t = e.chargeParts) || void 0 === t ? void 0 : t.some((function(e) {
                  return n.has(e.txtClassroomUid)
                })))
              }))).call(e, (function(e) {
                return e.txtProjectUid || "0"
              }))))
            })),
            Je = (0, P.E)((function() {
              var e;
              return z.value ? h()(e = Oe.value).call(e, (function(e) {
                var t;
                return C()(t = Re.value).call(t, e.txtUid)
              })) : Oe.value
            })),
            Fe = (0, P.E)((function() {
              return Je.value.length > 0
            }));
          (0, w.wB)(Je, (function(e) {
            e.some((function(e) {
              var t;
              return e.txtUid === (null === (t = xe.value) || void 0 === t ? void 0 : t.txtUid)
            })) || (xe.value = e[0])
          }));
          var He = (0, O._y)("AppointmentVenue/AppointmentVenueConfig", {
              params: function() {
                return Ue.value ? {
                  storeId: Ue.value.id
                } : _.Oy
              },
              transform: function(e) {
                return e.result
              }
            }),
            Ge = He.data,
            Qe = He.pending,
            Ke = He.error,
            We = (0, P.E)((function() {
              var e, t;
              return null !== (e = null === (t = Ge.value) || void 0 === t ? void 0 : t.venueTimeLimit) && void 0 !== e ? e : 0
            })),
            ze = (0, P.E)((function() {
              var e, t = null === (e = Ge.value) || void 0 === e || null === (e = e.currentSetting) || void 0 === e ? void 0 : e.advanceDays;
              return void 0 !== t && t > 0 ? L()().add(t, "days").startOf("date").valueOf() : L()().add(60, "days").startOf("date").valueOf()
            })),
            Xe = (0, P.E)((function() {
              var e;
              return null === (e = Ge.value) || void 0 === e || null === (e = e.currentSetting) || void 0 === e ? void 0 : e.advanceDays
            })),
            Ze = (0, G.J)((function() {
              return je().then((function(e) {
                return e.store
              }))
            }), o);
          return (0, x.BU)([i, c, Se, Ne, X, Ve, Qe]), (0, x.FB)([u, d, Ae, _e, Ee, Ke]), (0, T.c)(qe), {
            calendarMinDate: p,
            calendarMaxDate: ze,
            currentTime: g,
            venueAppointmentNoticePopupShow: j,
            venueAppointmentNoticePopupClose: B,
            venueAppointmentNoticeContent: Q,
            showSelectHeader: W,
            meituanBookingMode: (0, P.E)((function() {
              return Boolean(z.value)
            })),
            storeLocation: De,
            showChainStore: Pe,
            currentStore: Ue,
            onStoreSelectReload: function() {
              Ce()
            },
            showProjectSelect: Fe,
            projectList: Je,
            selectedProject: xe,
            showProjectPopup: Be,
            toggleProjectPopup: Le,
            onSelectProject: function(e) {
              xe.value = e, Le()
            },
            venueSettingData: Me,
            allowedClassroomUids: Ye,
            onVenueBookingOrder: function(e) {
              var n, o, r, a;
              t.navigateTo({
                page: "/sport/pages/venue-booking-payment",
                query: {
                  largeQueryId: (0, R.AV)({
                    userId: null === (n = xe.value) || void 0 === n ? void 0 : n._belongtUserId,
                    projectType: null === (o = xe.value) || void 0 === o ? void 0 : o.type,
                    meituanCouponCode: null === (r = z.value) || void 0 === r ? void 0 : r.couponCode,
                    classrooms: y()(a = e.detail.slots).call(a, (function(e) {
                      return {
                        classroomUid: e.classroomUid,
                        beginDatetime: e.beginDatetime,
                        endDatetime: e.endDatetime,
                        peopleNum: e.peopleNum
                      }
                    }))
                  })
                },
                guard: Ze
              }).then(Z).catch((function() {}))
            },
            venueTimeLimit: We,
            showBookedAvatar: S,
            advanceDays: Xe
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 91993)
  }
]);