var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [3166], {
    89539: function() {},
    2162: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_53770a98"
      }, n.g.currentInject.render = function(t, e, n, l) {
        l("template", this.template) && (e("template.displayStyle", this.template.displayStyle), e("template.bgColor", this.template.bgColor), e("template.link", this.template.link), l("linkGuardId", this.linkGuardId), e("template.img", this.template.img), l("titleStyle", this.titleStyle), e("template.title", this.template.title), l("contentStyle", this.contentStyle), e("template.content", this.template.content)), n()
      }
    },
    46389: function() {},
    57852: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_53770a98", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(2162), n(46389), n(89539), n.g.currentSrcMode = "wx", n(75069)
    },
    75069: function(t, e, n) {
      n.r(e);
      var l = n(69996),
        i = n(11215),
        r = n(90356),
        o = n(45184),
        p = n(57187);
      (0, l.A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          var e = t.template,
            n = e.fontColor,
            l = e.fontSize,
            a = e.isBlod,
            c = (0, r.W9)(l[0], n[0], a[0]),
            u = (0, r.W9)(l[1], n[1], a[1]),
            m = (0, o.G)((function() {
              return p.F.getSubscribeMessage()
            }));
          return {
            titleStyle: c,
            contentStyle: u,
            linkGuardId: (0, i.P)((function(e) {
              t.template.randomId && t.template.subscribeTemplates ? m(t.template.subscribeTemplates).then((function() {
                e()
              })) : e()
            }))
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 57852)
  }
]);