var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [938], {
    80623: function() {},
    31517: function(e, t, l) {
      var n = l(72244);
      l.g.currentInject = {
        moduleId: "_c270c642"
      }, l.g.currentInject.render = function(e, t, l, a) {
        a("tabList", this.tabList).length > 0 && (a("tabIndex", this.tabIndex), e(a("tabList", this.tabList), (function(e, t) {
          e.title
        }))), a("tableData", this.tableData).length > 0 && (e(a("tableData", this.tableData), (function(e, t) {
          e.title1, e.title2
        })), e(a("tableData", this.tableData), (function(e, t) {
          "enroll" == e.slotType ? (n.c("booking-btn", ["enabled" == e.type && a("checkedMap", this.checkedMap)[e.key] ? "checked" : e.type]), e.btnLabel1, e.btnLabel3 && e.btnLabel3, e.btnLabel2 && e.btnLabel2) : (n.c("booking-btn", ["enabled" == e.type && a("checkedMap", this.checkedMap)[e.key] ? "checked" : e.type]), e.btnLabel1, e.btnLabel2 && e.btnLabel2)
        }))), a("hasEnrollSlot", this.hasEnrollSlot) ? (a("enrollmentDetailsShow", this.enrollmentDetailsShow) && (t("enrollDataList[0].timeRange", this.enrollDataList[0].timeRange), t("enrollDataList[0].name", this.enrollDataList[0].name), t("enrollDataList[0].enrollmentTitle", this.enrollDataList[0].enrollmentTitle), t("enrollDataList[0].participateCount", this.enrollDataList[0].participateCount), t("enrollDataList[0].enrollmentLimitNum", this.enrollDataList[0].enrollmentLimitNum), e(t("enrollDataList[0].customerModels", this.enrollDataList[0].customerModels), (function(e, t) {
          e.photoPath
        })), t("enrollDataList[0].customerModels", this.enrollDataList[0].customerModels).length), a("currencySymbol", this.currencySymbol), t("enrollDataList[0].enrollmentFee", this.enrollDataList[0].enrollmentFee), a("enrollDataList", this.enrollDataList).length > 0 && n.c("flex-none ml-1", [a("enrollmentDetailsShow", this.enrollmentDetailsShow) ? "rotate-0" : "rotate-180"]), a("enrollDataList", this.enrollDataList).length) : (t("orderData.items", this.orderData.items).length > 0 && (e(t("orderData.items", this.orderData.items), (function(e, l) {
          t("orderData.items", this.orderData.items).length > 0 && (e.name1, e.name2, a("currencySymbol", this.currencySymbol), e.amount, e.peopleNum)
        })), a("showBookedAvatar", this.showBookedAvatar) && a("venueRecord", this.venueRecord) && t("venueRecord.venueCount", this.venueRecord.venueCount) && (t("venueRecord.venueCount", this.venueRecord.venueCount), t("venueRecord.serviceClassroom.capacity", this.venueRecord.serviceClassroom.capacity), e(t("venueRecord.customerModels", this.venueRecord.customerModels), (function(e, t) {
          e.photoPath
        })), t("venueRecord.customerModels", this.venueRecord.customerModels) && t("venueRecord.customerModels", this.venueRecord.customerModels).length)), a("currencySymbol", this.currencySymbol), t("orderData.totalAmount", this.orderData.totalAmount), t("orderData.items", this.orderData.items).length), l()
      }, l.g.currentInject.getRefsData = function() {
        return [{
          key: "tabs",
          selector: ".ref_tabs_1",
          type: "component",
          all: !1
        }]
      }
    },
    92140: function() {},
    79444: function(e, t, l) {
      l(97766), l.g.currentModuleId = "_c270c642", l.g.currentCtor = Component, l.g.currentCtorType = "component", l.g.currentResourceType = "component", l(31517), l(92140), l(80623), l.g.currentSrcMode = "wx", l(58257)
    },
    58257: function(e, t, l) {
      l.r(t);
      var n = l(49e3),
        a = l.n(n),
        o = l(17195),
        r = l.n(o),
        i = l(82567),
        u = l.n(i),
        s = l(87802),
        c = l.n(s),
        d = l(27715),
        m = l(39298),
        p = l(93690),
        v = l.n(p),
        f = l(74058),
        b = l.n(f),
        h = l(78475),
        D = l.n(h),
        g = l(60192),
        y = l.n(g),
        L = l(91630),
        R = l.n(L),
        C = l(43454),
        U = l.n(C),
        I = l(10144),
        T = l.n(I),
        k = l(12736),
        x = l.n(k),
        E = l(84665),
        N = l.n(E),
        M = l(31259),
        w = l.n(M),
        A = l(61458),
        S = l(39164),
        j = l(74665),
        O = l(11821),
        B = l(40519),
        P = l(70841),
        _ = l(39347),
        F = l(69996),
        H = l(24129),
        J = l(46943),
        q = l(66855);

      function V(e, t) {
        var l = a()(e);
        if (r()) {
          var n = r()(e);
          t && (n = b()(n).call(n, (function(t) {
            return u()(e, t).enumerable
          }))), l.push.apply(l, n)
        }
        return l
      }

      function z(e) {
        for (var t = 1; t < arguments.length; t++) {
          var l = null != arguments[t] ? arguments[t] : {};
          t % 2 ? V(Object(l), !0).forEach((function(t) {
            (0, m.A)(e, t, l[t])
          })) : c() ? Object.defineProperties(e, c()(l)) : V(Object(l)).forEach((function(t) {
            Object.defineProperty(e, t, u()(l, t))
          }))
        }
        return e
      }(0, F.A)({
        properties: {
          projectUid: String,
          settingData: Object,
          allowedClassroomUids: Array,
          showBookedAvatar: Boolean
        },
        setup: function(e, t) {
          var l = t.refs,
            n = t.triggerEvent,
            a = (0, S.JX)(),
            o = (0, j.r)(),
            r = (0, q.uP)(),
            i = (0, _.E)((function() {
              return r.data.currency
            })),
            u = (0, _.E)((function() {
              var t, l, n = (0, J.to)(e.projectUid),
                a = e.allowedClassroomUids || [],
                o = e.settingData.enrollSlots || [],
                r = v()(t = b()(l = e.settingData.slots).call(l, (function(e) {
                  return e.txtProjectUid === n && (!a.length || D()(a).call(a, e.txtClassroomUid))
                }))).call(t, (function(e) {
                  var t, l;
                  return {
                    id: y()(t = y()(l = "".concat(e.txtClassroomUid, "-")).call(l, e.beginDatetime, "-")).call(t, e.endDatetime),
                    slot: z(z({}, e), {}, {
                      peopleNum: 1
                    }),
                    slotType: "appt"
                  }
                })),
                i = [];
              return o.forEach((function(e) {
                i.push({
                  start: N()(e.beginDatetime).valueOf(),
                  end: N()(e.endDatetime).add(1, "minute").valueOf(),
                  classroomUid: e.txtClassroomUid
                })
              })), b()(r).call(r, (function(e) {
                var t = e.slot;
                return i.every((function(e) {
                  var l = e.start,
                    n = e.end,
                    a = e.classroomUid;
                  return N()(t.beginDatetime).valueOf() >= n || N()(t.endDatetime).valueOf() <= l || a !== t.txtClassroomUid
                }))
              }))
            })),
            s = (0, _.E)((function() {
              var t;
              if (null !== (t = e.allowedClassroomUids) && void 0 !== t && t.length) return [];
              var l = e.settingData.enrollSlots || [];
              return v()(l).call(l, (function(e) {
                var t, l;
                return {
                  id: y()(t = y()(l = "".concat(e.txtClassroomUid, "-")).call(l, e.beginDatetime, "-")).call(t, e.endDatetime),
                  slot: z({}, e),
                  slotType: "enroll"
                }
              }))
            })),
            c = (0, _.E)((function() {
              var t, l;
              return v()(t = b()(l = e.settingData.validClassRooms).call(l, (function(t) {
                var l, n;
                return (t.projectUidTxt || "") === (0, J.to)(e.projectUid) && (!(null !== (l = e.allowedClassroomUids) && void 0 !== l && l.length) || D()(n = e.allowedClassroomUids).call(n, t.uid))
              }))).call(t, (function(e) {
                return {
                  key: e.uid,
                  title: e.name,
                  userId: e.userId
                }
              }))
            })),
            m = (0, P.IJ)(0);
          (0, B.wB)(c, (function() {
            m.value = 0, (0, H.dY)((function() {
              var e;
              null === (e = l.tabs) || void 0 === e || e.resize()
            }))
          }));
          var p = (0, _.E)((function() {
              return c.value[m.value]
            })),
            f = (0, _.E)((function() {
              var e;
              return p.value ? R()(e = u.value).call(e, (function(e, t) {
                return t.slot.txtClassroomUid === p.value.key && e.push(z(z({}, t), {}, {
                  classroomUserId: p.value.userId
                })), e
              }), []) : []
            })),
            h = (0, _.E)((function() {
              var e;
              return p.value ? R()(e = s.value).call(e, (function(e, t) {
                return t.slot.txtClassroomUid === p.value.key && e.push(z(z({}, t), {}, {
                  classroomUserId: p.value.userId
                })), e
              }), []) : []
            })),
            g = function(e) {
              var t, l, n, a;
              if ("enroll" === e.slotType) {
                var o, r, u, s, c, d = e.slot,
                  m = d.enrollmentRule.title;
                return {
                  type: "enabled",
                  title1: "报名活动",
                  title2: y()(o = "".concat(U()(r = d.enrollmentRule.beginDate).call(r, 11, 16), "-")).call(o, U()(u = d.enrollmentRule.endDate).call(u, 11, 16)),
                  btnLabel1: m,
                  btnLabel2: 1 === d.enrollmentRule.hasEnrollmentFee ? y()(s = "".concat(i.value)).call(s, d.enrollmentRule.enrollmentFee || 0) : "免费",
                  btnLabel3: d.enrollmentRule.enrollmentLimitNum ? y()(c = "报名人数".concat(d.enrollmentRule.ParticipateCount, "/")).call(c, d.enrollmentRule.enrollmentLimitNum) : ""
                }
              }
              var p, v, f, b, h, D, g, L, R = e.slot,
                C = R.name || "-",
                I = y()(t = "".concat(U()(l = R.beginDatetime).call(l, 11, 16), "-")).call(t, U()(n = R.endDatetime).call(n, 11, 16));
              return R.apptInfo.canApptOrNot ? {
                type: "enabled",
                title1: C,
                title2: I,
                btnLabel1: y()(p = "".concat(i.value)).call(p, R.cost),
                btnLabel2: "余位".concat((null !== (v = R.capacity) && void 0 !== v ? v : 0) - (null !== (f = R.apptInfo.hadApptCount) && void 0 !== f ? f : 0))
              } : 1 === R.status ? {
                type: "disabled",
                title1: C,
                title2: I,
                btnLabel1: y()(b = "".concat(i.value)).call(b, R.cost, "（已约满）")
              } : 5 === R.status ? {
                type: "disabled",
                title1: C,
                title2: I,
                btnLabel1: y()(h = "".concat(i.value)).call(h, R.cost, "（已过时）")
              } : 8 === R.status ? {
                type: "enabled",
                title1: C,
                title2: I,
                btnLabel1: y()(D = "".concat(i.value)).call(D, R.cost),
                btnLabel2: "余位".concat((null !== (g = R.capacity) && void 0 !== g ? g : 0) - (null !== (L = R.apptInfo.hadApptCount) && void 0 !== L ? L : 0))
              } : {
                type: "disabled",
                title1: C,
                title2: I,
                btnLabel1: y()(a = "".concat(i.value)).call(a, R.cost)
              }
            },
            L = (0, _.E)((function() {
              var e = [];
              return h.value.forEach((function(t) {
                if ("enroll" === t.slotType) {
                  var l, n = t.slot;
                  e.push(z(z({}, g(t)), {}, {
                    key: t.id,
                    data: t,
                    slotType: "enroll",
                    enrollmentNum: y()(l = "".concat(n.enrollmentRule.ParticipateCount, "/")).call(l, n.enrollmentRule.enrollmentLimitNum),
                    enrollmentTitle: n.enrollmentRule.title
                  }))
                }
              })), f.value.forEach((function(t) {
                e.push(z(z({}, g(t)), {}, {
                  key: t.id,
                  data: t,
                  slotType: "appt"
                }))
              })), T()(e).call(e, (function(e, t) {
                var l = function(e) {
                  return "enroll" === e.slotType && "enroll" === e.data.slotType ? N()(e.data.slot.enrollmentRule.beginDate).valueOf() : N()(e.data.slot.beginDatetime).valueOf()
                };
                return l(e) - l(t)
              })), e
            })),
            C = (0, A.C)(),
            I = C.value,
            k = C.toggle,
            E = (0, _.E)((function() {
              return M.value.length > 0
            })),
            M = (0, _.E)((function() {
              var e = [];
              return F.value.forEach((function(t) {
                var l = t;
                if ("enroll" === l.slotType) {
                  var n, a, o, r, i, u = l.slot;
                  e.push({
                    enrollmentTitle: u.enrollmentRule.title,
                    name: u.classRoomName || "",
                    customerModels: (null === (n = u.enrollmentRule) || void 0 === n ? void 0 : n.customerModels) || [],
                    timeRange: y()(a = "".concat(N()(u.enrollmentRule.beginDate).format("HH:mm"), "-")).call(a, N()(u.enrollmentRule.endDate).format("HH:mm")),
                    enrollmentFee: (null === (o = u.enrollmentRule) || void 0 === o ? void 0 : o.enrollmentFee) || 0,
                    enrollmentLimitNum: (null === (r = u.enrollmentRule) || void 0 === r ? void 0 : r.enrollmentLimitNum) || 0,
                    participateCount: (null === (i = u.enrollmentRule) || void 0 === i ? void 0 : i.ParticipateCount) || 0
                  })
                }
              })), e
            })),
            F = (0, P.IJ)([]);
          (0, B.wB)((function() {
            return e.settingData
          }), (function() {
            F.value = []
          }));
          var V = (0, _.E)((function() {
              var e;
              return R()(e = F.value).call(e, (function(e, t) {
                return e[t.id] = !0, e
              }), {})
            })),
            X = (0, _.E)((function() {
              var e = w()(0),
                t = [];
              return F.value.forEach((function(l) {
                var n;
                e = e.add(w()(l.slot.cost).multiply(l.slot.peopleNum).value), t.push({
                  id: l.id,
                  name1: l.slot.classRoomName,
                  name2: null !== (n = l.slot.name) && void 0 !== n ? n : "-",
                  amount: l.slot.cost,
                  peopleNum: l.slot.peopleNum
                })
              })), {
                totalAmount: e.value,
                items: t
              }
            })),
            Y = (0, O.B8)("AppointmentVenue/VenueRecord", {
              transform: function(e) {
                return e.result
              }
            }),
            G = Y.data,
            K = Y.pending,
            Q = Y.error,
            W = Y.execute;
          return (0, S.BU)([K]), (0, S.FB)([Q]), {
            currencySymbol: i,
            tabList: c,
            tabIndex: m,
            tableData: L,
            checkedMap: V,
            onTapCellBtn: function(e) {
              var t, l = L.value[e].data;
              if ("appt" === l.slotType) {
                var n = l.slot.apptInfo,
                  o = n.canApptOrNot,
                  r = n.status,
                  i = n.errorMessage;
                if (!o) return void(8 === r && i && a.toast({
                  title: i
                }))
              }
              if (F.value.some((function(e) {
                  return e.id === l.id
                }))) F.value = b()(t = F.value).call(t, (function(e) {
                return e.id !== l.id
              }));
              else if ("appt" === l.slotType) {
                var u, s, c = b()(u = F.value).call(u, (function(e) {
                  return "appt" === e.slotType
                }));
                F.value = y()(s = []).call(s, (0, d.A)(c), [l]);
                var m = l.slot,
                  p = m.txtClassroomUid,
                  v = m.beginDatetime,
                  f = m.endDatetime,
                  h = l.classroomUserId;
                W({
                  classroomUid: p,
                  beginDatetime: v,
                  endDatetime: f,
                  classroomUserId: h
                })
              } else "enroll" === l.slotType && (F.value = [l])
            },
            orderData: X,
            onPressOrderBtn: function() {
              var e;
              n("order", {
                slots: v()(e = F.value).call(e, (function(e) {
                  return {
                    classroomUid: e.slot.txtClassroomUid,
                    beginDatetime: e.slot.beginDatetime,
                    endDatetime: e.slot.endDatetime,
                    classroomUserId: e.classroomUserId,
                    peopleNum: e.slot.peopleNum
                  }
                }))
              })
            },
            venueRecord: G,
            onBookedNameList: function() {
              var e = F.value[0],
                t = e.slot,
                l = t.txtClassroomUid,
                n = t.beginDatetime,
                a = t.endDatetime,
                r = t.name,
                i = e.classroomUserId;
              o.navigateTo({
                page: "/sport/pages/venue-booked-list",
                query: {
                  classroomUserId: i,
                  classroomUid: l,
                  beginDatetime: n,
                  endDatetime: a,
                  name: r && encodeURIComponent(r)
                }
              })
            },
            onTapBtn: function(e, t) {
              var l = F.value[t];
              if ("appt" === l.slotType && l) {
                var n, o, r = l.slot,
                  i = r.peopleNum,
                  u = (null !== (n = r.capacity) && void 0 !== n ? n : 0) - (null !== (o = r.apptInfo.hadApptCount) && void 0 !== o ? o : 0);
                if (e > 0 && i >= u) return void a.toast({
                  title: "当前时段余位".concat(u)
                });
                var s = Math.max(1, Math.min(u, w()(i).add(e).value)),
                  c = (0, d.A)(F.value);
                1 === s && e < 0 && 1 === i ? x()(c).call(c, t, 1) : c[t] = z(z({}, l), {}, {
                  slot: z(z({}, r), {}, {
                    peopleNum: s
                  })
                }), F.value = c
              }
            },
            onPeopleNumInput: function(e) {
              var t, l, n = e.currentTarget.dataset.index,
                a = e.detail.value || 1;
              if ("appt" === F.value[n].slotType) {
                var o = F.value[n].slot,
                  r = (null !== (t = o.capacity) && void 0 !== t ? t : 0) - (null !== (l = o.apptInfo.hadApptCount) && void 0 !== l ? l : 0),
                  i = Math.max(1, Math.min(a, r));
                if (F.value[n]) {
                  var u = (0, d.A)(F.value);
                  u[n] = z(z({}, u[n]), {}, {
                    slot: z(z({}, o), {}, {
                      peopleNum: i
                    }),
                    slotType: "appt"
                  }), F.value = u
                }
              }
            },
            goEnrollment: function() {
              var e = F.value[0];
              if ("enroll" === e.slotType) {
                var t, l, n, a = e.slot,
                  o = a.enrollmentRule,
                  r = o.uidTxt,
                  i = o.userId,
                  u = o.id;
                wx.navigateTo({
                  url: y()(t = y()(l = y()(n = "/marketingSubpages/pages/sportActivity/details/index?ruleUid=".concat(r, "&ruleUserId=")).call(n, i, "&id=")).call(l, u, "&storeId=")).call(t, a.userId)
                })
              }
            },
            onTapEnrollmentDetails: function() {
              k()
            },
            enrollmentDetailsShow: I,
            onEnrollmentNames: function() {
              var e = F.value[0];
              if ("enroll" === e.slotType) {
                var t, l = e.slot.enrollmentRule,
                  n = l.uidTxt,
                  a = l.userId;
                wx.navigateTo({
                  url: y()(t = "/marketingSubpages/pages/sportActivity/enrolled-list/index?uid=".concat(n, "&userId=")).call(t, a)
                })
              }
            },
            hasEnrollSlot: E,
            enrollDataList: M
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 79444)
  }
]);