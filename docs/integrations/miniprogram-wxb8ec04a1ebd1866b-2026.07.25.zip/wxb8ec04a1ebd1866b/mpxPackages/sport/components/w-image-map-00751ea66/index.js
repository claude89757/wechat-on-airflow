var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [441], {
    51962: function() {},
    15162: function(e, t, n) {
      var r = n(72244);
      n.g.currentInject = {
        moduleId: "_0751ea66"
      }, n.g.currentInject.render = function(e, t, n, o) {
        e(o("imageList", this.imageList), (function(t, n) {
          o("current", this.current), t.src, e(t.areaList, (function(e, t) {
            r.s("", e.style), e.link, o("scopeId", this.scopeId)
          }))
        })), o("showBtn", this.showBtn) && o("imageList", this.imageList).length > 1 && o("btnIconState", this.btnIconState) >= 0 && o("btnIconState", this.btnIconState), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "imageWrapper",
          selector: ".ref_imageWrapper_1",
          type: "node",
          all: !1
        }]
      }
    },
    10411: function() {},
    19263: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_0751ea66", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(15162), n(10411), n(51962), n.g.currentSrcMode = "wx", n(40576)
    },
    40576: function(e, t, n) {
      n.r(t);
      var r = n(70841),
        o = n(69996),
        c = n(14734);
      (0, o.A)({
        properties: {
          images: Array,
          scopeId: Number,
          showBtn: Boolean
        },
        setup: function(e, t) {
          var n, o = t.refs,
            a = (0, c.t)(e.images, o.imageWrapper),
            u = (0, r.KR)(-1),
            i = function e() {
              u.value = (u.value + 1) % a.value.length, a.value.length > 1 && (n = setTimeout((function() {
                e()
              }), 3e3))
            };
          i();
          var s = (0, r.KR)(-1);
          return {
            imageList: a,
            current: u,
            btnIconState: s,
            onBtnTap: function() {
              clearTimeout(n), s.value = (s.value + 1) % 2, i()
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 19263)
  }
]);