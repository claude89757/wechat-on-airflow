var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [5907], {
    38603: function() {},
    3529: function(e, n, t) {
      t.g.currentInject = {
        moduleId: "_bea670b2"
      }, t.g.currentInject.render = function(e, n, t, i) {
        n("value.name", this.value.name), i("showChainStore", this.showChainStore), n("location.hasPerssion", this.location.hasPerssion) && n("value.distance", this.value.distance), i("showChainStore", this.showChainStore) && (i("storePopupShow", this.storePopupShow), i("searchKeyword", this.searchKeyword), i("searchKeyword", this.searchKeyword), n("location.hasPerssion", this.location.hasPerssion) && (0 == i("storeList", this.storeList).length || e(i("storeList", this.storeList), (function(e, t) {
          e.id, n("value.id", this.value.id), e.isClosed, e.businessStatus, e.name, e.openingHours, e.address, e.distance
        })))), t()
      }
    },
    49532: function() {},
    16328: function(e, n, t) {
      t(97766), t.g.currentModuleId = "_bea670b2", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "component", t(3529), t(49532), t(38603), t.g.currentSrcMode = "wx", t(70537)
    },
    70537: function(e, n, t) {
      t.r(n);
      var i = t(93690),
        o = t.n(i),
        s = t(70841),
        r = t(39347),
        a = t(69996),
        u = t(61740),
        c = t(61458),
        d = t(39164),
        p = t(11821),
        l = t(46902),
        h = t(31328);
      (0, a.A)({
        properties: {
          value: Object,
          location: Object,
          showChainStore: Boolean
        },
        setup: function(e, n) {
          var t = n.triggerEvent,
            i = (0, c.C)(),
            a = i.value,
            f = i.open,
            m = i.close,
            g = (0, s.IJ)(""),
            S = function(e) {
              return "string" == typeof e ? e.substring(0, 5) : e
            },
            C = function(e) {
              var n = [];
              return e.BizTimeConfig && e.BizTimeConfig.BusinessBeginTime && n.push(S(e.BizTimeConfig.BusinessBeginTime) + "~" + S(e.BizTimeConfig.BusinessEndTime)), e.BizTimeConfig.BusinessTimePlus && JSON.parse(e.BizTimeConfig.BusinessTimePlus).forEach((function(e) {
                n.push(S(e.begin) + "~" + S(e.end))
              })), n.join(";")
            },
            v = (0, p.H3)("Store/NearbyStoreList", {
              params: function(n) {
                return a.value && e.location.hasPerssion ? {
                  forMiniAppOnly: !0,
                  includeBizDetail: !0,
                  includeCloseStore: !0,
                  includeShippingRule: !0,
                  isGcj02: !1,
                  isShareCustomer: !1,
                  pageIndex: n,
                  pageSize: 20,
                  filter: g.value,
                  latitude: e.location.latitude,
                  longitude: e.location.longitude
                } : u.Oy
              },
              immediate: !1,
              checkend: function(e, n) {
                return e.data.stores.length < n.pageSize
              },
              transform: function(e) {
                var n;
                return o()(n = e.data.stores).call(n, (function(e) {
                  return {
                    id: e.StoreId,
                    name: e.StoreName,
                    distance: (0, h.B)(Math.floor(1e3 * e.DistanceInKm)),
                    distanceKm: e.DistanceInKm,
                    address: e.Address,
                    businessStatus: (n = e, 0 === n.Status ? "暂停营业" : n.IsBizClosed ? "打烊" : n.IsOutOfBizTime ? "接受预定" : "营业中"),
                    openingHours: C(e),
                    isClosed: 0 === e.Status || e.IsBizClosed
                  };
                  var n
                }))
              }
            }),
            w = v.data,
            B = v.pending,
            T = v.error,
            b = v.executeNext,
            I = (0, r.E)((function() {
              return w.value.pageData
            }));
          return (0, d.BU)([B]), (0, d.FB)([T]), {
            storePopupShow: a,
            onTapPopupMask: m,
            searchKeyword: g,
            onKeywordInputConfirm: function(e) {
              g.value = e.detail.value
            },
            onKeywordInputClear: function() {
              g.value = ""
            },
            storeList: I,
            onScrollToLower: b,
            onTapShopListItem: function(e) {
              m(), t("input", {
                value: {
                  id: e.id,
                  name: e.name,
                  distance: e.distance
                }
              })
            },
            onTapCurrentStore: function() {
              e.showChainStore && f()
            },
            openSetting: function() {
              return l.mp.openSetting().then((function(e) {
                e.authSetting["scope.userLocation"] && t("reload")
              }))
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 16328)
  }
]);