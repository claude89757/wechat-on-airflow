var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [3091], {
    28924: function() {},
    57136: function(e, n, t) {
      t.g.currentInject = {
        moduleId: "_e748cbc8"
      }, t.g.currentInject.render = function(e, n, t, c) {
        c("image", this.image), t()
      }
    },
    81686: function() {},
    60455: function(e, n, t) {
      t(97766), t.g.currentModuleId = "_e748cbc8", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "component", t(57136), t(81686), t(28924), t.g.currentSrcMode = "wx", t(47796)
    },
    47796: function(e, n, t) {
      t.r(n), (0, t(69996).A)({
        properties: {
          image: {
            type: String,
            value: "empty_nothing"
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 60455)
  }
]);