var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [4857], {
    49734: function() {},
    28946: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_bb82c79e"
      }, n.g.currentInject.render = function(e, t, n, p) {
        p("template", this.template) && (t("template.displayStyle", this.template.displayStyle), t("template.layoutType", this.template.layoutType), t("template.isDisplayMargin", this.template.isDisplayMargin), e(p("images", this.images), (function(e, n) {
          e.link.type ? (e.link, t("template.layoutType", this.template.layoutType), e.src) : (t("template.layoutType", this.template.layoutType), e.src)
        }))), n()
      }
    },
    70624: function() {},
    6036: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_bb82c79e", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(28946), n(70624), n(49734), n.g.currentSrcMode = "wx", n(90532)
    },
    90532: function(e, t, n) {
      n.r(t);
      var p = n(93690),
        r = n.n(p),
        a = n(39347);
      (0, n(69996).A)({
        properties: {
          template: Object
        },
        setup: function(e) {
          return {
            images: (0, a.E)((function() {
              var t;
              return r()(t = e.template.imgArr).call(t, (function(e, t) {
                return {
                  key: t,
                  src: e.src,
                  link: e.link
                }
              }))
            }))
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 6036)
  }
]);