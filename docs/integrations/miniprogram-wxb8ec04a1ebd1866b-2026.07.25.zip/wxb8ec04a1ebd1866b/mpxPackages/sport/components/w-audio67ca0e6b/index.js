var t = require("../../../../@babel/runtime/helpers/typeof"),
  e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [5973], {
    58978: function() {},
    75763: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_67ca0e6b"
      }, n.g.currentInject.render = function(t, e, n, s) {
        s("template", this.template) && (e("template.displayStyle", this.template.displayStyle), s("playing", this.playing), s("moving", this.moving), s("titleStyle", this.titleStyle), e("template.titleText", this.template.titleText) || e("template.audioName", this.template.audioName), s("progress", this.progress), s("progressTimeFt", this.progressTimeFt), s("durationFt", this.durationFt)), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "progressArea",
          selector: ".ref_progressArea_1",
          type: "node",
          all: !1
        }]
      }
    },
    56626: function() {},
    65981: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_67ca0e6b", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(75763), n(56626), n(58978), n.g.currentSrcMode = "wx", n(57394)
    },
    57394: function(t, e, n) {
      n.r(e);
      var s = n(70841),
        i = n(39347),
        r = n(69996),
        o = n(3582),
        u = n(84665),
        a = n.n(u),
        c = n(15180),
        d = n.n(c),
        h = n(50553),
        l = n(90356);
      a().extend(d()), (0, r.A)({
        properties: {
          template: Object
        },
        setup: function(t, e) {
          var n, r = e.refs,
            u = (0, l.W9)(t.template.fontSize, t.template.fontColor, t.template.isBlod),
            c = (0, o.R)(t.template.audio, t.template.isAutoPlay, t.template.duration),
            d = c.playing,
            m = c.duration,
            f = c.currentTime,
            p = c.play,
            $ = c.pause,
            v = c.seek,
            g = (0, s.KR)(!1),
            y = (0, s.KR)(0),
            M = (0, i.E)((function() {
              return g.value ? y.value : f.value
            })),
            S = function(t) {
              return a().duration(t, "s").format("mm:ss")
            },
            b = (0, i.E)((function() {
              return m.value ? S(m.value) : "--:--"
            })),
            k = (0, i.E)((function() {
              return S(M.value)
            })),
            w = (0, i.E)((function() {
              return "".concat(m.value ? (0, h.c)(100 * Math.min(1, M.value / m.value)) : 0, "%")
            }));
          return {
            titleStyle: u,
            playing: d,
            durationFt: b,
            progressTimeFt: k,
            progress: w,
            onTapBtn: function() {
              d.value ? $() : p()
            },
            onTapProgressArea: function(t) {
              r.progressArea.boundingClientRect((function(e) {
                var n = (t.detail.x - e.left) / e.width * m.value;
                v(n), d.value || p()
              })).exec()
            },
            moving: g,
            onDotTouchStart: function() {
              n = void 0, r.progressArea.boundingClientRect((function(t) {
                n = t, g.value = !0, y.value = f.value
              })).exec()
            },
            onDotTouchMove: function(t) {
              if (n) {
                var e = (t.touches[0].clientX - n.left) / n.width;
                e < 0 ? e = 0 : e > 1 && (e = 1), y.value = m.value * e
              }
            },
            onDotTouchEnd: function() {
              g.value = !1, v(y.value), d.value || p()
            }
          }
        }
      })
    },
    15180: function(e) {
      e.exports = function() {
        var e, n, s = 1e3,
          i = 6e4,
          r = 36e5,
          o = 864e5,
          u = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
          a = 31536e6,
          c = 2628e6,
          d = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/,
          h = {
            years: a,
            months: c,
            days: o,
            hours: r,
            minutes: i,
            seconds: s,
            milliseconds: 1,
            weeks: 6048e5
          },
          l = function(t) {
            return t instanceof y
          },
          m = function(t, e, n) {
            return new y(t, n, e.$l)
          },
          f = function(t) {
            return n.p(t) + "s"
          },
          p = function(t) {
            return t < 0
          },
          $ = function(t) {
            return p(t) ? Math.ceil(t) : Math.floor(t)
          },
          v = function(t) {
            return Math.abs(t)
          },
          g = function(t, e) {
            return t ? p(t) ? {
              negative: !0,
              format: "" + v(t) + e
            } : {
              negative: !1,
              format: "" + t + e
            } : {
              negative: !1,
              format: ""
            }
          },
          y = function() {
            function p(e, n, s) {
              var i = this;
              if (this.$d = {}, this.$l = s, void 0 === e && (this.$ms = 0, this.parseFromMilliseconds()), n) return m(e * h[f(n)], this);
              if ("number" == typeof e) return this.$ms = e, this.parseFromMilliseconds(), this;
              if ("object" == t(e)) return Object.keys(e).forEach((function(t) {
                i.$d[f(t)] = e[t]
              })), this.calMilliseconds(), this;
              if ("string" == typeof e) {
                var r = e.match(d);
                if (r) {
                  var o = r.slice(2).map((function(t) {
                    return null != t ? Number(t) : 0
                  }));
                  return this.$d.years = o[0], this.$d.months = o[1], this.$d.weeks = o[2], this.$d.days = o[3], this.$d.hours = o[4], this.$d.minutes = o[5], this.$d.seconds = o[6], this.calMilliseconds(), this
                }
              }
              return this
            }
            var v = p.prototype;
            return v.calMilliseconds = function() {
              var t = this;
              this.$ms = Object.keys(this.$d).reduce((function(e, n) {
                return e + (t.$d[n] || 0) * h[n]
              }), 0)
            }, v.parseFromMilliseconds = function() {
              var t = this.$ms;
              this.$d.years = $(t / a), t %= a, this.$d.months = $(t / c), t %= c, this.$d.days = $(t / o), t %= o, this.$d.hours = $(t / r), t %= r, this.$d.minutes = $(t / i), t %= i, this.$d.seconds = $(t / s), t %= s, this.$d.milliseconds = t
            }, v.toISOString = function() {
              var t = g(this.$d.years, "Y"),
                e = g(this.$d.months, "M"),
                n = +this.$d.days || 0;
              this.$d.weeks && (n += 7 * this.$d.weeks);
              var s = g(n, "D"),
                i = g(this.$d.hours, "H"),
                r = g(this.$d.minutes, "M"),
                o = this.$d.seconds || 0;
              this.$d.milliseconds && (o += this.$d.milliseconds / 1e3, o = Math.round(1e3 * o) / 1e3);
              var u = g(o, "S"),
                a = t.negative || e.negative || s.negative || i.negative || r.negative || u.negative,
                c = i.format || r.format || u.format ? "T" : "",
                d = (a ? "-" : "") + "P" + t.format + e.format + s.format + c + i.format + r.format + u.format;
              return "P" === d || "-P" === d ? "P0D" : d
            }, v.toJSON = function() {
              return this.toISOString()
            }, v.format = function(t) {
              var e = t || "YYYY-MM-DDTHH:mm:ss",
                s = {
                  Y: this.$d.years,
                  YY: n.s(this.$d.years, 2, "0"),
                  YYYY: n.s(this.$d.years, 4, "0"),
                  M: this.$d.months,
                  MM: n.s(this.$d.months, 2, "0"),
                  D: this.$d.days,
                  DD: n.s(this.$d.days, 2, "0"),
                  H: this.$d.hours,
                  HH: n.s(this.$d.hours, 2, "0"),
                  m: this.$d.minutes,
                  mm: n.s(this.$d.minutes, 2, "0"),
                  s: this.$d.seconds,
                  ss: n.s(this.$d.seconds, 2, "0"),
                  SSS: n.s(this.$d.milliseconds, 3, "0")
                };
              return e.replace(u, (function(t, e) {
                return e || String(s[t])
              }))
            }, v.as = function(t) {
              return this.$ms / h[f(t)]
            }, v.get = function(t) {
              var e = this.$ms,
                n = f(t);
              return "milliseconds" === n ? e %= 1e3 : e = "weeks" === n ? $(e / h[n]) : this.$d[n], e || 0
            }, v.add = function(t, e, n) {
              var s;
              return s = e ? t * h[f(e)] : l(t) ? t.$ms : m(t, this).$ms, m(this.$ms + s * (n ? -1 : 1), this)
            }, v.subtract = function(t, e) {
              return this.add(t, e, !0)
            }, v.locale = function(t) {
              var e = this.clone();
              return e.$l = t, e
            }, v.clone = function() {
              return m(this.$ms, this)
            }, v.humanize = function(t) {
              return e().add(this.$ms, "ms").locale(this.$l).fromNow(!t)
            }, v.valueOf = function() {
              return this.asMilliseconds()
            }, v.milliseconds = function() {
              return this.get("milliseconds")
            }, v.asMilliseconds = function() {
              return this.as("milliseconds")
            }, v.seconds = function() {
              return this.get("seconds")
            }, v.asSeconds = function() {
              return this.as("seconds")
            }, v.minutes = function() {
              return this.get("minutes")
            }, v.asMinutes = function() {
              return this.as("minutes")
            }, v.hours = function() {
              return this.get("hours")
            }, v.asHours = function() {
              return this.as("hours")
            }, v.days = function() {
              return this.get("days")
            }, v.asDays = function() {
              return this.as("days")
            }, v.weeks = function() {
              return this.get("weeks")
            }, v.asWeeks = function() {
              return this.as("weeks")
            }, v.months = function() {
              return this.get("months")
            }, v.asMonths = function() {
              return this.as("months")
            }, v.years = function() {
              return this.get("years")
            }, v.asYears = function() {
              return this.as("years")
            }, p
          }(),
          M = function(t, e, n) {
            return t.add(e.years() * n, "y").add(e.months() * n, "M").add(e.days() * n, "d").add(e.hours() * n, "h").add(e.minutes() * n, "m").add(e.seconds() * n, "s").add(e.milliseconds() * n, "ms")
          };
        return function(t, s, i) {
          e = i, n = i().$utils(), i.duration = function(t, e) {
            var n = i.locale();
            return m(t, {
              $l: n
            }, e)
          }, i.isDuration = l;
          var r = s.prototype.add,
            o = s.prototype.subtract;
          s.prototype.add = function(t, e) {
            return l(t) ? M(this, t, 1) : r.bind(this)(t, e)
          }, s.prototype.subtract = function(t, e) {
            return l(t) ? M(this, t, -1) : o.bind(this)(t, e)
          }
        }
      }()
    }
  },
  function(t) {
    t(t.s = 65981)
  }
]);