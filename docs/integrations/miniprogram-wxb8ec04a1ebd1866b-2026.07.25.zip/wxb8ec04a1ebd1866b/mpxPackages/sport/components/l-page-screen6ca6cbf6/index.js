var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [2237], {
    15107: function() {},
    36429: function(e, t, a) {
      a.g.currentInject = {
        moduleId: "_6ca6cbf6"
      }, a.g.currentInject.render = function(e, t, a, r) {
        r("pageData", this.pageData) && (r("themeStyle", this.themeStyle), r("navHeight", this.navHeight), t("pageData.title", this.pageData.title), t("pageData.background", this.pageData.background), t("pageData.customScrollView", this.pageData.customScrollView) ? (t("pageData.name", this.pageData.name), r("query", this.query), r("tabBarVisible", this.tabBarVisible) ? r("tabBarSafeBottom", this.tabBarSafeBottom) : r("safeBottom", this.safeBottom), r("pageSharedId", this.pageSharedId)) : (t("pageData.name", this.pageData.name), r("query", this.query), r("pageSharedId", this.pageSharedId), r("tabBarVisible", this.tabBarVisible) ? r("tabBarSafeBottom", this.tabBarSafeBottom) : r("safeBottom", this.safeBottom)), r("tabBarVisible", this.tabBarVisible) && (r("formattedTabBarTemplate", this.formattedTabBarTemplate), r("tabBarTab", this.tabBarTab))), a()
      }
    },
    32938: function() {},
    1140: function(e, t, a) {
      a(97766), a.g.currentModuleId = "_6ca6cbf6", a.g.currentCtor = Component, a.g.currentCtorType = "component", a.g.currentResourceType = "component", a(36429), a(32938), a(15107), a.g.currentSrcMode = "wx", a(9142)
    },
    9142: function(e, t, a) {
      var r = a(69996),
        n = a(39347),
        o = a(70841),
        i = a(49e3),
        u = {
          "/sport/pages/venue-booking": {
            name: "场地预约",
            title: "场地预约",
            background: "#f5f5f5",
            customScrollView: !0
          }
        },
        p = (a.n(i)()(u), a(46867)),
        s = a(71328),
        c = a(98328),
        b = a(80173),
        l = a.n(b),
        m = a(79135),
        g = (a(57391), a(60192), a(64448), {
          "首页": "/pages/index",
          "场地预约": "/sport/pages/venue-booking"
        });

      function f(e) {
        var t, a, r = e.type,
          n = e.data;
        switch (r) {
          case "pages":
            t = g[n.name];
            break;
          case "classroom-project":
            t = "/sport/pages/venue-booking", a = {
              projectUid: n.uid,
              projectType: n.type
            }
        }
        return t ? {
          page: t,
          query: a
        } : null
      }
      var d = a(66855),
        h = (0, m.nY)("tab-bar", (function() {
          var e = (0, d.Ct)(),
            t = (0, d.SA)(),
            a = (0, n.E)((function() {
              return e.data.themeStyle
            })),
            r = (0, n.E)((function() {
              return t.pending
            })),
            o = (0, n.E)((function() {
              var e, a;
              return null === (e = l()(a = t.data.footerTemplates).call(a, (function(e) {
                return "底部标签栏" === e.name
              }))) || void 0 === e ? void 0 : e.template
            })),
            i = (0, n.E)((function() {
              return o.value && (0, p.e6)(o.value)
            })),
            u = (0, n.E)((function() {
              return i.value ? (0, p.Hj)(i.value, f) : []
            }));
          return {
            themeStyle: a,
            tabBarLoading: r,
            tabBarTemplate: o,
            formattedTabBarTemplate: i,
            formattedTabBarRoutes: u
          }
        }));
      (0, r.A)({
        properties: {
          page: String,
          query: {
            type: Object,
            value: {}
          },
          safeBottom: {
            type: String,
            value: "env(safe-area-inset-bottom)"
          },
          sharedId: Number
        },
        setup: function(e) {
          var t = (0, c.C)(),
            a = h(),
            r = (0, n.E)((function() {
              return t.navigationBarInfo.totalHeight
            })),
            i = (0, n.E)((function() {
              return a.themeStyle
            })),
            b = (0, n.E)((function() {
              return t = e.page, u[t] || null;
              var t
            })),
            l = e.sharedId || (0, s.bz)(),
            m = (0, n.E)((function() {
              return a.formattedTabBarTemplate
            })),
            g = (0, n.E)((function() {
              return (0, p.Us)(a.formattedTabBarRoutes, {
                page: e.page,
                query: e.query
              })
            })),
            f = (0, n.E)((function() {
              return Boolean(m.value) && g.value > -1
            })),
            d = (0, o.IJ)("0px");
          return {
            navHeight: r,
            themeStyle: i,
            pageData: b,
            pageSharedId: l,
            formattedTabBarTemplate: m,
            tabBarTab: g,
            tabBarVisible: f,
            tabBarSafeBottom: d,
            onTabBarUpdate: function(e) {
              d.value = e.detail.safeBottom + "px"
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 1140)
  }
]);