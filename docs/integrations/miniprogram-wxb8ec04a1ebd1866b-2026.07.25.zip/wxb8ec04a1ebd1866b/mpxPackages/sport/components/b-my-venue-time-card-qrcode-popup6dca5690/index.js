var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [827], {
    12018: function() {},
    13292: function(n, r, c) {
      c.g.currentInject = {
        moduleId: "_6dca5690"
      }, c.g.currentInject.render = function(n, r, c, e) {
        e("card", this.card) && (e("show", this.show), r("card.name", this.card.name), r("card.uid", this.card.uid), r("card.customerUid", this.card.customerUid)), c()
      }
    },
    94990: function() {},
    49885: function(n, r, c) {
      c(97766), c.g.currentModuleId = "_6dca5690", c.g.currentCtor = Component, c.g.currentCtorType = "component", c.g.currentResourceType = "component", c(13292), c(94990), c(12018), c.g.currentSrcMode = "wx", c(82910)
    },
    82910: function(n, r, c) {
      c.r(r), (0, c(69996).A)({
        properties: {
          show: Boolean,
          card: Object
        },
        setup: function(n, r) {
          var c = r.triggerEvent;
          return {
            onTapPopupMask: function() {
              c("tapmask")
            }
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 49885)
  }
]);