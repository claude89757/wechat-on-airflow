var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [3399], {
    43722: function() {},
    2144: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_5967eb33"
      }, n.g.currentInject.render = function(t, e, n, r) {
        r("template", this.template) && (e("template.displayStyle", this.template.displayStyle), t(r("images", this.images), (function(n, c) {
          r("isTextInBottom", this.isTextInBottom), n.link.type ? (n.link, n.src, 1 === e("template.layoutType", this.template.layoutType) && n.text && n.text.length > 0 && (n.textAnima, n.flexStyle, t(n.text, (function(t, e) {
            t.fontStyles, t.content
          })))) : (n.src, 1 === e("template.layoutType", this.template.layoutType) && n.text && n.text.length > 0 && (n.textAnima, n.flexStyle, t(n.text, (function(t, e) {
            t.fontStyles, t.content
          }))))
        }))), n()
      }
    },
    79702: function() {},
    64295: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_5967eb33", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(2144), n(79702), n(43722), n.g.currentSrcMode = "wx", n(46112)
    },
    46112: function(t, e, n) {
      n.r(e);
      var r = n(49e3),
        c = n.n(r),
        o = n(17195),
        i = n.n(o),
        l = n(74058),
        a = n.n(l),
        u = n(82567),
        p = n.n(u),
        s = n(87802),
        f = n.n(s),
        m = n(39298),
        x = n(93690),
        y = n.n(x),
        g = n(60192),
        h = n.n(g),
        d = n(39347),
        b = n(69996),
        k = n(90356);

      function j(t, e) {
        var n = c()(t);
        if (i()) {
          var r = i()(t);
          e && (r = a()(r).call(r, (function(e) {
            return p()(t, e).enumerable
          }))), n.push.apply(n, r)
        }
        return n
      }

      function v(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2 ? j(Object(n), !0).forEach((function(e) {
            (0, m.A)(t, e, n[e])
          })) : f() ? Object.defineProperties(t, f()(n)) : j(Object(n)).forEach((function(e) {
            Object.defineProperty(t, e, p()(n, e))
          }))
        }
        return t
      }
      var S = ["flex-start", "center", "flex-end"];
      (0, b.A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          return {
            images: (0, d.E)((function() {
              var e;
              return y()(e = t.template.images).call(e, (function(t, e) {
                var n, r;
                return {
                  key: e,
                  src: t.src,
                  link: t.link,
                  text: t.text && t.text.length > 0 && y()(n = t.text).call(n, (function(t) {
                    return v(v({}, t), {}, {
                      fontStyles: (0, k.W9)(t.size, t.color, t.isBlod)
                    })
                  })),
                  textAnima: t.textAnima,
                  flexStyle: h()(r = "justify-content:".concat(S[t.textVerticalAlgin], "; align-items:")).call(r, S[t.textAlgin], ";")
                }
              }))
            }))
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 64295)
  }
]);