var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [8011], {
    20669: function() {},
    8725: function(t, n, e) {
      e.g.currentInject = {
        moduleId: "_955c0a88"
      }, e.g.currentInject.render = function(t, n, e, i) {
        n("info.statusBarHeight", this.info.statusBarHeight), i("opacity", this.opacity), i("customStyle", this.customStyle), n("info.paddingY", this.info.paddingY), n("info.paddingX", this.info.paddingX), n("info.titleSafeX", this.info.titleSafeX), n("info.contentHeight", this.info.contentHeight), n("info.contentHeight", this.info.contentHeight), i("canBack", this.canBack), n("info.contentHeight", this.info.contentHeight), n("info.contentHeight", this.info.contentHeight), i("title", this.title), n("info.titleSafeX", this.info.titleSafeX), e()
      }
    },
    58828: function() {},
    95948: function(t, n, e) {
      e(97766), e.g.currentModuleId = "_955c0a88", e.g.currentCtor = Component, e.g.currentCtorType = "component", e.g.currentResourceType = "component", e(8725), e(58828), e(20669), e.g.currentSrcMode = "wx", e(59831)
    },
    59831: function(t, n, e) {
      e.r(n);
      var i = e(69996),
        o = e(74665),
        c = e(46902),
        a = e(98328);
      (0, i.A)({
        properties: {
          title: {
            type: String,
            value: ""
          },
          opacity: {
            type: Number,
            value: 1
          },
          customStyle: {
            type: String,
            value: ""
          }
        },
        setup: function() {
          var t = (0, a.C)(),
            n = (0, o.r)(),
            e = c.mp.getCurrentPages().length > 1;
          return {
            info: t.navigationBarInfo,
            canBack: e,
            onBtnTap: function() {
              e ? n.navigateBack() : wx.reLaunch({
                url: "/pages/index/index"
              })
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 95948)
  }
]);