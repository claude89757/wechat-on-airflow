var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [9441], {
    49631: function() {},
    94877: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_8cf4ff60"
      }, n.g.currentInject.render = function(t, e, n, o) {
        o("template", this.template) && o("list", this.list) && (e("template.displayStyle", this.template.displayStyle), e("template.bgColor", this.template.bgColor), 0 == e("template.layoutType", this.template.layoutType) ? (o("list", this.list), o("fontStyle", this.fontStyle), e("template.bgColor", this.template.bgColor)) : 1 == e("template.layoutType", this.template.layoutType) && (o("list", this.list), o("fontStyle", this.fontStyle))), n()
      }
    },
    61540: function() {},
    33608: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_8cf4ff60", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(94877), n(61540), n(49631), n.g.currentSrcMode = "wx", n(41525)
    },
    41525: function(t, e, n) {
      n.r(e);
      var o = n(49e3),
        l = n.n(o),
        r = n(17195),
        p = n.n(r),
        a = n(74058),
        i = n.n(a),
        c = n(82567),
        u = n.n(c),
        f = n(87802),
        s = n.n(f),
        m = n(39298),
        y = n(93690),
        h = n.n(y),
        d = n(60192),
        b = n.n(d),
        g = n(69996),
        C = n(90356);

      function S(t, e) {
        var n = l()(t);
        if (p()) {
          var o = p()(t);
          e && (o = i()(o).call(o, (function(e) {
            return u()(t, e).enumerable
          }))), n.push.apply(n, o)
        }
        return n
      }(0, g.A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          var e;
          return {
            list: h()(e = t.template.list).call(e, (function(t, e) {
              var n;
              return function(t) {
                for (var e = 1; e < arguments.length; e++) {
                  var n = null != arguments[e] ? arguments[e] : {};
                  e % 2 ? S(Object(n), !0).forEach((function(e) {
                    (0, m.A)(t, e, n[e])
                  })) : s() ? Object.defineProperties(t, s()(n)) : S(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, u()(n, e))
                  }))
                }
                return t
              }({
                key: b()(n = "".concat(e, "-")).call(n, t.displayTitle)
              }, t)
            })),
            fontStyle: (0, C.W9)(t.template.fontSize, t.template.fontColor, t.template.isBlod)
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 33608)
  }
]);