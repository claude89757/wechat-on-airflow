var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [2629], {
    71091: function() {},
    82234: function(t, n, e) {
      e.g.currentInject = {
        moduleId: "_e741be72"
      }, e.g.currentInject.render = function(t, n, e, u) {
        0 === u("cardType", this.cardType) && (u("currencySymbol", this.currencySymbol), u("total", this.total), u("quantity", this.quantity)), u("isContactBtn", this.isContactBtn), u("quantity", this.quantity) >= u("minQuantity", this.minQuantity) && (u("quantity", this.quantity), u("maxQuantity", this.maxQuantity)), u("btnSpinning", this.btnSpinning), e()
      }
    },
    99514: function() {},
    16476: function(t, n, e) {
      e(97766), e.g.currentModuleId = "_e741be72", e.g.currentCtor = Component, e.g.currentCtorType = "component", e.g.currentResourceType = "component", e(82234), e(99514), e(71091), e.g.currentSrcMode = "wx", e(63893)
    },
    63893: function(t, n, e) {
      e.r(n);
      var u = e(66855),
        i = e(74665),
        r = e(39347);
      (0, e(69996).A)({
        properties: {
          total: Number,
          quantity: Number,
          minQuantity: {
            type: Number,
            value: 1
          },
          maxQuantity: {
            type: Number,
            value: 999
          },
          btnSpinning: Boolean,
          cardType: Number
        },
        setup: function(t, n) {
          var e = n.triggerEvent,
            a = ((0, i.r)(), (0, u.g3)()),
            o = (0, u.uP)(),
            c = (0, r.E)((function() {
              return o.data.currency
            })),
            p = (0, r.E)((function() {
              return a.data._customerServiceType
            })),
            y = (0, r.E)((function() {
              return "0" === p.value
            }));
          return {
            currencySymbol: c,
            isContactBtn: y,
            onTapContactBtn: function() {
              y.value || wx.navigateTo({
                url: "/subPages/shopping/customerService/customerService"
              })
            },
            onTapHomeBtn: function() {
              wx.reLaunch({
                url: "/pages/index/index?nogostoplist=1&nogoparent=1"
              })
            },
            onTapReduceBtn: function() {
              t.quantity - 1 >= t.minQuantity && e("change", t.quantity - 1)
            },
            onTapAddBtn: function() {
              t.quantity + 1 <= t.maxQuantity && e("change", t.quantity + 1)
            },
            onPressBuyBtn: function() {
              e("buy", t.quantity + 1)
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 16476)
  }
]);