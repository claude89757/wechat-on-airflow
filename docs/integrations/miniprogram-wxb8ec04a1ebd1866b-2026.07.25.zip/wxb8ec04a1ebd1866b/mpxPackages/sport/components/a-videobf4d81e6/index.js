var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [2572], {
    44686: function() {},
    80571: function(n, e, t) {
      t.g.currentInject = {
        moduleId: "_bf4d81e6"
      }, t.g.currentInject.render = function(n, e, t, r) {
        r("playing", this.playing) ? (r("src", this.src), e("info.initialTime", this.info.initialTime)) : r("poster", this.poster) && r("poster", this.poster), r("playing", this.playing), t()
      }
    },
    65390: function() {},
    70545: function(n, e, t) {
      t(97766), t.g.currentModuleId = "_bf4d81e6", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "component", t(80571), t(65390), t(44686), t.g.currentSrcMode = "wx", t(66530)
    },
    66530: function(n, e, t) {
      t.r(e);
      var r = t(69996),
        i = t(3582);
      (0, r.A)({
        properties: {
          src: String,
          poster: String
        },
        setup: function() {
          var n = (0, i.y)();
          return {
            playing: n.playing,
            info: n.info,
            play: n.play,
            onTimeUpdate: n.onTimeUpdate,
            onEnded: n.onEnded,
            onFullScreenChange: n.onFullScreenChange
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 70545)
  }
]);