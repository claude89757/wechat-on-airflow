var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [2686], {
    97097: function() {},
    12658: function(t, e, a) {
      a.g.currentInject = {
        moduleId: "_8a28ab20"
      }, a.g.currentInject.render = function(t, e, a, l) {
        0 == e("ftemplate.layoutType", this.ftemplate.layoutType) && (e("ftemplate.list", this.ftemplate.list), l("customStyle", this.customStyle)), 1 == e("ftemplate.layoutType", this.ftemplate.layoutType) && (e("ftemplate.list", this.ftemplate.list), e("ftemplate.rudderTab", this.ftemplate.rudderTab), l("tab", this.tab), l("customStyle", this.customStyle)), 2 == e("ftemplate.layoutType", this.ftemplate.layoutType) && (e("ftemplate.list", this.ftemplate.list), l("tab", this.tab), l("customStyle", this.customStyle)), 3 == e("ftemplate.layoutType", this.ftemplate.layoutType) && (e("ftemplate.list", this.ftemplate.list), l("tab", this.tab), l("customStyle", this.customStyle)), 4 == e("ftemplate.layoutType", this.ftemplate.layoutType) && (e("ftemplate.list", this.ftemplate.list), l("tab", this.tab), l("customStyle", this.customStyle)), a()
      }
    },
    43455: function() {},
    20312: function(t, e, a) {
      a(97766), a.g.currentModuleId = "_8a28ab20", a.g.currentCtor = Component, a.g.currentCtorType = "component", a.g.currentResourceType = "component", a(12658), a(43455), a(97097), a.g.currentSrcMode = "wx", a(36229)
    },
    36229: function(t, e, a) {
      a.r(e);
      var l = a(91630),
        o = a.n(l),
        p = a(49e3),
        r = a.n(p),
        u = a(60192),
        n = a.n(u),
        c = a(39347);
      (0, a(69996).A)({
        properties: {
          ftemplate: Object,
          tab: Number
        },
        setup: function(t, e) {
          var a = e.triggerEvent;
          return {
            customStyle: (0, c.E)((function() {
              var e, a = t.ftemplate.colors,
                l = {
                  "--w-tab-bar-text-color": a.textColor,
                  "--w-tab-bar-active-text-color": a.activeTextColor,
                  "--w-tab-bar-bg-color": a.bgColor
                };
              return o()(e = r()(l)).call(e, (function(t, e) {
                var a;
                return l[e] && (t += n()(a = "".concat(e, ":")).call(a, l[e], ";")), t
              }), "")
            })),
            onUpdate: function(t) {
              a("update", t.detail)
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 20312)
  }
]);