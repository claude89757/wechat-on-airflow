var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [2368], {
    57821: function() {},
    4389: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_a1dd569c"
      }, r.g.currentInject.render = function(n, e, r, c) {
        c("name", this.name), r()
      }
    },
    30699: function() {},
    42454: function() {},
    93616: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_a1dd569c", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(4389), r(42454), r(30699), r(57821), r.g.currentSrcMode = "wx", r(47777)
    },
    47777: function(n, e, r) {
      r.r(e), (0, r(69996).A)({
        properties: {
          name: String
        }
      })
    }
  },
  function(n) {
    n(n.s = 93616)
  }
]);