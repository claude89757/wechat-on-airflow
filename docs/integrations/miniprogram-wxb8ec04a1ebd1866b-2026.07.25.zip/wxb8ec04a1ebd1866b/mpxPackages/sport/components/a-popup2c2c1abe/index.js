var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [2366], {
    58521: function() {},
    37391: function(n, o, e) {
      var t = e(72244);
      e.g.currentInject = {
        moduleId: "_2c2c1abe"
      }, e.g.currentInject.render = function(n, o, e, r) {
        t.c("a-popup", [r("position", this.position), {
          show: r("show", this.show),
          endshow: r("endshow", this.endshow)
        }]), e()
      }
    },
    68448: function() {},
    30600: function(n, o, e) {
      e(97766), e.g.currentModuleId = "_2c2c1abe", e.g.currentCtor = Component, e.g.currentCtorType = "component", e.g.currentResourceType = "component", e(37391), e(68448), e(58521), e.g.currentSrcMode = "wx", e(58813)
    },
    58813: function(n, o, e) {
      e.r(o);
      var t = e(70841);
      (0, e(69996).A)({
        options: {
          multipleSlots: !0
        },
        properties: {
          show: {
            type: Boolean,
            value: !1
          },
          position: {
            type: String,
            value: "center"
          }
        },
        setup: function(n, o) {
          var e = o.triggerEvent,
            r = (0, t.IJ)(!1);
          return {
            endshow: r,
            onAnimationEnd: function() {
              r.value = n.show
            },
            onMaskTap: function() {
              e("masktap")
            }
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 30600)
  }
]);