var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [5217], {
    71151: function() {},
    14596: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_3dbe0eb0"
      }, n.g.currentInject.render = function(t, e, n, r) {
        t(r("list", this.list), (function(t, n) {
          r("tab", this.tab), t.link, t.key == e("rudder.key", this.rudder.key) ? t.customImgs.length > 0 ? t.customImgs[0] : t.icons[0] : (2 == t.customImgs.length ? t.customImgs[r("tab", this.tab) == n ? 1 : 0] : t.icons[r("tab", this.tab) == n ? 1 : 0], t.title || t.name)
        })), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "tabBar",
          selector: ".ref_tabBar_1",
          type: "node",
          all: !1
        }]
      }
    },
    83678: function() {},
    39584: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_3dbe0eb0", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(14596), n(83678), n(71151), n.g.currentSrcMode = "wx", n(87885)
    },
    87885: function(t, e, n) {
      n.r(e);
      var r = n(57187),
        c = n(69996),
        o = n(6520);
      (0, c.A)({
        properties: {
          list: Array,
          rudder: Object,
          tab: Number
        },
        setup: function(t, e) {
          var n = e.refs,
            c = e.triggerEvent;
          return (0, o.sV)((function() {
            n.tabBar.boundingClientRect((function(t) {
              c("update", {
                height: t.height,
                safeBottom: 0
              })
            })).exec()
          })), {
            onTapTab: function(e) {
              r.F.switchTab(e, t.list[e].link)
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 39584)
  }
]);