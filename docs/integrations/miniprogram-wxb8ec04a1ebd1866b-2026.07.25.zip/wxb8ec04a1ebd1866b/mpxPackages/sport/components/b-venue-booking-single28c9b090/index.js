require("../../../../@babel/runtime/helpers/Arrayincludes");
var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [1819], {
    95102: function() {},
    56500: function(t, e, n) {
      var a = n(87843),
        o = n(72244),
        l = n(29003);
      n.g.currentInject = {
        moduleId: "_28c9b090"
      }, n.g.currentInject.render = function(t, e, n, r) {
        e("tableData.classrooms", this.tableData.classrooms).length > 0 && e("tableData.times", this.tableData.times).length > 0 && (r("scrollTop", this.scrollTop), e("tableData.classRoomGroups", this.tableData.classRoomGroups) ? t(e("tableData.classRoomGroups", this.tableData.classRoomGroups), (function(e, n) {
          e.columns.length, e.title, t(e.columns, (function(t, e) {
            t.title
          }))
        })) : t(e("tableData.classrooms", this.tableData.classrooms), (function(t, e) {
          t.name
        })), t(e("tableData.times", this.tableData.times), (function(t, n) {
          t.startText, e("tableData.times", this.tableData.times).length - 1 === n && t.endText
        })), t(e("tableData.columns", this.tableData.columns), (function(e, n) {
          t(e.items, (function(t, e) {
            t.rowspan, "enroll" === t.slotType ? (o.c("booking-tcell-btn text-3 leading-4 text-gray-55", ["enabled" == t.type && r("checkedMap", this.checkedMap)[t.key] ? "checked" : t.type]), 1 === t.rowspan || t.rowspan, t.enrollmentTitle, t.rowspan > 1 && (t.enrollmentNum, t.label)) : (o.c("booking-tcell-btn", ["enabled" == t.type && r("checkedMap", this.checkedMap)[t.key] ? "checked" : t.type]), t.label)
          }))
        }))), r("hasEnrollSlot", this.hasEnrollSlot) ? (r("enrollmentDetailsShow", this.enrollmentDetailsShow) && (e("enrollDataList[0].timeRange", this.enrollDataList[0].timeRange), e("enrollDataList[0].name", this.enrollDataList[0].name), e("enrollDataList[0].enrollmentTitle", this.enrollDataList[0].enrollmentTitle), e("enrollDataList[0].participateCount", this.enrollDataList[0].participateCount), e("enrollDataList[0].enrollmentLimitNum", this.enrollDataList[0].enrollmentLimitNum), t(e("enrollDataList[0].customerModels", this.enrollDataList[0].customerModels), (function(t, e) {
          t.photoPath
        })), e("enrollDataList[0].customerModels", this.enrollDataList[0].customerModels).length), r("currencySymbol", this.currencySymbol), e("enrollDataList[0].enrollmentFee", this.enrollDataList[0].enrollmentFee), r("enrollDataList", this.enrollDataList).length > 0 && o.c("flex-none ml-1", [r("enrollmentDetailsShow", this.enrollmentDetailsShow) ? "rotate-0" : "rotate-180"]), r("enrollDataList", this.enrollDataList).length) : (r("orderDetailsShow", this.orderDetailsShow) && t(e("orderData.items", this.orderData.items), (function(t, e) {
          t.name, t.timeRange, t.feeAmount > 0 && r("extraFeeText", this.extraFeeText), r("currencySymbol", this.currencySymbol), t.amount, t.feeAmount > 0 && (r("currencySymbol", this.currencySymbol), t.feeAmount), t.slotIds
        })), e("orderData.items", this.orderData.items).length > 0 && (r("currencySymbol", this.currencySymbol), e("orderData.totalAmount", this.orderData.totalAmount), e("orderData.totalHours", this.orderData.totalHours), o.c("flex-none ml-1", [r("orderDetailsShow", this.orderDetailsShow) ? "rotate-0" : "rotate-180"]), e("orderData.items", this.orderData.items).length)), l.g(r("newFormattedSlot", this.newFormattedSlot), ["slot", "chargeParts", "length"]) > 0 && (r("partsVenuePopupShow", this.partsVenuePopupShow), r("checkedType", this.checkedType), 10 === e("newFormattedSlot.slot.status", this.newFormattedSlot.slot.status) || 11 === e("newFormattedSlot.slot.status", this.newFormattedSlot.slot.status) || e("newFormattedSlot.slot.status", this.newFormattedSlot.slot.status), e("newFormattedSlot.slot.classRoomName", this.newFormattedSlot.slot.classRoomName), r("currencySymbol", this.currencySymbol), e("newFormattedSlot.slot.cost", this.newFormattedSlot.slot.cost), e("newFormattedSlot.slot.status", this.newFormattedSlot.slot.status), t(e("newFormattedSlot.slot.chargeParts", this.newFormattedSlot.slot.chargeParts), (function(t, e) {
          1 === r("checkedType", this.checkedType) && a.includes(r("checkedPopupClassroomUids", this.checkedPopupClassroomUids), t.txtClassroomUid), t.apptCount, t.classRoomName, r("currencySymbol", this.currencySymbol), t.cost, t.apptCount
        })), r("checkedType", this.checkedType)), n()
      }
    },
    28011: function() {},
    40669: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_28c9b090", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(56500), n(28011), n(95102), n.g.currentSrcMode = "wx", n(49754)
    },
    49754: function(t, e, n) {
      n.r(e);
      var a = n(49e3),
        o = n.n(a),
        l = n(17195),
        r = n.n(l),
        s = n(82567),
        i = n.n(s),
        u = n(87802),
        c = n.n(u),
        d = n(21982),
        f = n.n(d),
        p = n(12636),
        m = n.n(p),
        v = n(22009),
        h = n.n(v),
        y = n(53888),
        g = n(39298),
        D = n(27715),
        S = n(93690),
        b = n.n(S),
        T = n(74058),
        x = n.n(T),
        A = n(80492),
        w = n.n(A),
        C = n(95364),
        P = n.n(C),
        I = n(80173),
        k = n.n(I),
        F = n(91630),
        U = n.n(F),
        E = n(78475),
        M = n.n(E),
        R = n(60192),
        L = n.n(R),
        N = n(21983),
        O = n.n(N),
        z = n(92501),
        j = n.n(z),
        G = n(31714),
        V = n.n(G),
        B = n(57391),
        H = n.n(B),
        X = n(43454),
        _ = n.n(X),
        K = n(10144),
        J = n.n(K),
        W = n(12736),
        q = n.n(W),
        Q = n(40519),
        $ = n(70841),
        Y = n(39347),
        Z = n(69996),
        tt = n(84665),
        et = n.n(tt),
        nt = n(35684),
        at = n.n(nt),
        ot = n(22297),
        lt = n.n(ot),
        rt = n(46943),
        st = n(61458),
        it = n(39164),
        ut = n(31259),
        ct = n.n(ut),
        dt = n(44865),
        ft = n(83887),
        pt = n(66855);

      function mt(t, e) {
        var n = void 0 !== m() && h()(t) || t["@@iterator"];
        if (!n) {
          if (Array.isArray(t) || (n = function(t, e) {
              if (t) {
                var n;
                if ("string" == typeof t) return vt(t, e);
                var a = _()(n = {}.toString.call(t)).call(n, 8, -1);
                return "Object" === a && t.constructor && (a = t.constructor.name), "Map" === a || "Set" === a ? f()(t) : "Arguments" === a || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? vt(t, e) : void 0
              }
            }(t)) || e && t && "number" == typeof t.length) {
            n && (t = n);
            var a = 0,
              o = function() {};
            return {
              s: o,
              n: function() {
                return a >= t.length ? {
                  done: !0
                } : {
                  done: !1,
                  value: t[a++]
                }
              },
              e: function(t) {
                throw t
              },
              f: o
            }
          }
          throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }
        var l, r = !0,
          s = !1;
        return {
          s: function() {
            n = n.call(t)
          },
          n: function() {
            var t = n.next();
            return r = t.done, t
          },
          e: function(t) {
            s = !0, l = t
          },
          f: function() {
            try {
              r || null == n.return || n.return()
            } finally {
              if (s) throw l
            }
          }
        }
      }

      function vt(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, a = Array(e); n < e; n++) a[n] = t[n];
        return a
      }

      function ht(t, e) {
        var n = o()(t);
        if (r()) {
          var a = r()(t);
          e && (a = x()(a).call(a, (function(e) {
            return i()(t, e).enumerable
          }))), n.push.apply(n, a)
        }
        return n
      }

      function yt(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2 ? ht(Object(n), !0).forEach((function(e) {
            (0, g.A)(t, e, n[e])
          })) : c() ? Object.defineProperties(t, c()(n)) : ht(Object(n)).forEach((function(e) {
            Object.defineProperty(t, e, i()(n, e))
          }))
        }
        return t
      }(0, Z.A)({
        properties: {
          projectUid: String,
          settingData: Object,
          allowedClassroomUids: Array,
          maxDuration: Number,
          zonePartDisplayType: String
        },
        setup: function(t, e) {
          var n = e.triggerEvent,
            a = e.createSelectorQuery,
            o = (0, it.JX)(),
            l = (0, ft.G)(),
            r = (0, pt.uP)(),
            s = (0, Y.E)((function() {
              return l.messages.extraFee
            })),
            i = (0, Y.E)((function() {
              return r.data.currency
            }));
          et().extend(at()), et().extend(lt());
          var u = (0, Y.E)((function() {
              var e, n, a = t.settingData,
                o = a.slots,
                l = void 0 === o ? [] : o,
                r = a.enrollSlots,
                s = void 0 === r ? [] : r,
                i = a.resaleSlot,
                u = void 0 === i ? [] : i,
                c = a.validClassRooms,
                d = void 0 === c ? [] : c,
                f = (0, rt.to)(t.projectUid),
                p = t.allowedClassroomUids || [],
                m = t.zonePartDisplayType,
                v = b()(e = x()(d).call(d, (function(t) {
                  return (t.projectUidTxt || "") === f
                }))).call(e, (function(t) {
                  return {
                    uid: t.uid,
                    name: t.name
                  }
                })),
                h = [];
              s.forEach((function(t) {
                h.push({
                  start: et()(t.beginDatetime).valueOf(),
                  end: et()(t.endDatetime).add(1, "minute").valueOf(),
                  classroomUid: t.txtClassroomUid
                })
              })), u.forEach((function(t) {
                h.push({
                  start: et()(t.beginDatetime).valueOf(),
                  end: et()(t.endDatetime).add(1, "minute").valueOf(),
                  classroomUid: t.txtClassroomUid
                })
              }));
              var y, g = b()(n = x()(l).call(l, (function(t) {
                  return t.txtProjectUid === f
                }))).call(n, (function(t) {
                  return (0, rt.gs)({
                    slotType: "appt",
                    slot: t,
                    relatedSlots: []
                  })
                })),
                S = (0, D.A)(g);
              if (g.length > 0 && 2 === g[0].slot.projectType && "flat" === m) {
                var T = {};
                g.forEach((function(t) {
                  var e = t.chargeGroupId;
                  (T[e] || (T[e] = [])).push(t)
                }));
                var A = (0, rt.yv)(v, g, T);
                v = A.classrooms, g = A.slots, y = A.classRoomGroups
              }
              if (p.length) {
                var C = new(w())(p);
                y && (y = x()(y).call(y, (function(t) {
                  return t.columns.every((function(t) {
                    return C.has(t.key)
                  }))
                })), C = new(w())(P()(y).call(y, (function(t) {
                  var e;
                  return b()(e = t.columns).call(e, (function(t) {
                    return t.key
                  }))
                })))), v = x()(v).call(v, (function(t) {
                  return C.has(t.uid)
                })), g = x()(g).call(g, (function(t) {
                  return C.has(t.slot.txtClassroomUid)
                })), S = (0, D.A)(g)
              }
              var I = U()(g).call(g, (function(t, e) {
                  var n = e.startDateTime,
                    a = e.endDateTime,
                    o = e.slot,
                    l = U()(h).call(h, (function(t, e) {
                      var l = e.start,
                        r = e.end,
                        s = e.classroomUid;
                      return t || n >= r || a <= l ? t : function(t, e) {
                        if (t === e) return "same";
                        if (y) {
                          var n = k()(y).call(y, (function(e) {
                              return e.columns.some((function(e) {
                                return e.key === t
                              }))
                            })),
                            a = k()(y).call(y, (function(t) {
                              return t.columns.some((function(t) {
                                return t.key === e
                              }))
                            }));
                          if (n && n === a) return t === n.key ? "whole-blocks-part" : e === a.key ? "part-blocks-whole" : void 0
                        }
                      }(s, o.txtClassroomUid)
                    }), void 0);
                  return l ? "whole-blocks-part" === l ? t.push((0, rt.gs)({
                    slotType: "appt",
                    slot: yt(yt({}, o), {}, {
                      status: -1,
                      apptInfo: yt(yt({}, o.apptInfo), {}, {
                        canApptOrNot: !1
                      })
                    }),
                    relatedSlots: e.relatedSlots,
                    zonePartFlat: e.zonePartFlat
                  })) : "part-blocks-whole" === l && t.push((0, rt.gs)({
                    slotType: "appt",
                    slot: yt(yt({}, o), {}, {
                      status: 10,
                      apptInfo: yt(yt({}, o.apptInfo), {}, {
                        canApptOrNot: !1
                      })
                    }),
                    relatedSlots: e.relatedSlots,
                    zonePartFlat: e.zonePartFlat
                  })) : t.push(e), t
                }), []),
                F = {};
              return I.forEach((function(t) {
                var e = t.chargeGroupId;
                (F[e] || (F[e] = [])).push(t)
              })), {
                classrooms: v,
                formattedSlots: I,
                classRoomGroups: y,
                chargeIdFormattedSlotsMap: F,
                formattedSlotsBeforeFilter: S
              }
            })),
            c = (0, Y.E)((function() {
              var e, n = t.settingData.resaleSlot,
                a = void 0 === n ? [] : n,
                o = (0, rt.to)(t.projectUid),
                l = t.allowedClassroomUids || [];
              return b()(e = x()(a).call(a, (function(t) {
                return t.txtProjectUid === o && (!l.length || M()(l).call(l, t.txtClassroomUid))
              }))).call(e, (function(t) {
                return (0, rt.gs)({
                  slotType: "resale",
                  slot: t,
                  relatedSlots: []
                })
              }))
            })),
            d = (0, Y.E)((function() {
              var e, n;
              if (null !== (e = t.allowedClassroomUids) && void 0 !== e && e.length) return [];
              var a = t.settingData.enrollSlots,
                o = void 0 === a ? [] : a,
                l = (0, rt.to)(t.projectUid);
              return b()(n = x()(o).call(o, (function(t) {
                return t.txtProjectUid === l
              }))).call(n, (function(t) {
                return (0, rt.gs)({
                  slotType: "enroll",
                  slot: t,
                  relatedSlots: []
                })
              }))
            })),
            f = function(e) {
              if (!e) return {
                type: "disabled",
                label: "-"
              };
              var n, a, o = e.slot;
              return o.apptInfo.canApptOrNot ? {
                type: "enabled",
                label: L()(n = "".concat(i.value)).call(n, o.cost)
              } : 1 === o.status ? {
                type: "disabled",
                label: "已约"
              } : 8 === o.status ? {
                type: "enabled",
                label: L()(a = "".concat(i.value)).call(a, o.cost)
              } : 10 === o.status || 11 === o.status ? "flat" === t.zonePartDisplayType ? {
                label: "已约分区",
                type: "disabled"
              } : p(e) ? {
                type: "disabled",
                label: "已约"
              } : {
                type: "enabled",
                label: "已约部分分区"
              } : -1 === o.status ? {
                type: "disabled",
                label: "已约整场"
              } : {
                type: "disabled",
                label: "已约"
              }
            },
            p = function(t) {
              var e, n = t.slot;
              if (null !== (e = n.apptInfo) && void 0 !== e && e.hadVenueAppts) {
                var a, o, l = (null === (a = n.chargeParts) || void 0 === a ? void 0 : b()(a).call(a, (function(t) {
                    return t.txtClassroomUid
                  }))) || [],
                  r = U()(o = n.apptInfo.hadVenueAppts).call(o, (function(t, e) {
                    return e.apptItems.forEach((function(e) {
                      M()(t).call(t, e.txtClassroomUid) || t.push(e.txtClassroomUid)
                    })), t
                  }), []);
                if (l.every((function(t) {
                    return M()(r).call(r, t)
                  }))) return !0
              }
              return !1
            },
            m = (0, Y.E)((function() {
              var e = u.value,
                n = e.classrooms,
                a = e.formattedSlots,
                o = e.classRoomGroups,
                l = e.formattedSlotsBeforeFilter,
                r = t.zonePartDisplayType,
                s = a,
                p = c.value,
                m = d.value,
                v = [],
                h = [],
                y = O(),
                g = O(),
                S = j(),
                T = Math.max.apply(Math, (0, D.A)(rt.CW));
              if (l.forEach((function(t) {
                  g > t.startDaySeconds && (g = t.startDaySeconds), S < t.endDaySecondsA1M && (S = t.endDaySecondsA1M), t.slot.gapMinutes && M()(rt.CW).call(rt.CW, t.slot.gapMinutes) && T > t.slot.gapMinutes && (T = t.slot.gapMinutes), (t.slot.apptInfo.canApptOrNot || 10 === t.slot.status || 11 === t.slot.status) && y > t.startDaySeconds && (y = t.startDaySeconds)
                })), g < S) {
                var x = 60 * T,
                  A = b()(rt.CW).call(rt.CW, (function(t) {
                    return 60 * t
                  })),
                  w = Math.min.apply(Math, (0, D.A)(A));
                g % w != 0 && (g = g + w - g % w), S % w != 0 && (S -= S % w);
                for (var C = (0, rt.hp)(g, S, x, A, b()(l).call(l, (function(t) {
                    return {
                      start: t.startDaySeconds,
                      end: t.endDaySecondsA1M
                    }
                  }))), P = 0; P < C.length - 1; P++) v.push({
                  key: C[P].toString(),
                  start: C[P],
                  end: C[P + 1],
                  startText: (0, dt.n)(C[P]),
                  endText: (0, dt.n)(C[P + 1])
                });
                n.forEach((function(t) {
                  for (var e = [], n = function(n) {
                      var o = v[n],
                        l = k()(m).call(m, (function(e) {
                          return e.slot.txtClassroomUid === t.uid && e.startDaySeconds >= o.start && e.startDaySeconds < o.end
                        }));
                      if (l && "enroll" === l.slotType)
                        for (var r = n; r < v.length; r++) {
                          var u, c;
                          if (l.endDaySecondsA1M > v[r].start && l.endDaySecondsA1M <= v[r].end || r === v.length - 1) return e.push({
                            key: l.id,
                            type: "enabled",
                            label: 1 === l.slot.enrollmentRule.hasEnrollmentFee ? L()(u = "".concat(i.value)).call(u, l.slot.enrollmentRule.enrollmentFee) : "免费",
                            rowspan: r - n + 1,
                            slotType: "enroll",
                            data: l,
                            enrollmentNum: L()(c = "".concat(l.slot.enrollmentRule.ParticipateCount, "/")).call(c, l.slot.enrollmentRule.enrollmentLimitNum),
                            enrollmentTitle: l.slot.enrollmentRule.title
                          }), a = n = r, 0
                        }
                      var d = k()(p).call(p, (function(e) {
                        return e.slot.txtClassroomUid === t.uid && e.startDaySeconds === o.start
                      }));
                      if (d)
                        for (var h = n; h < v.length; h++) {
                          var y;
                          if (d.endDaySecondsA1M === v[h].end) return e.push({
                            key: d.id,
                            type: "enabled",
                            label: L()(y = "".concat(i.value)).call(y, d.slot.cost),
                            rowspan: h - n + 1,
                            slotType: "resale",
                            data: d
                          }), a = n = h, 0
                        }
                      var g = k()(s).call(s, (function(e) {
                        return e.slot.txtClassroomUid === t.uid && e.startDaySeconds === o.start
                      }));
                      if (g)
                        for (var D = n; D < v.length; D++)
                          if (g.endDaySecondsA1M === v[D].end) return e.push(yt(yt({}, f(g)), {}, {
                            key: g.id,
                            rowspan: D - n + 1,
                            slotType: "appt",
                            data: g
                          })), a = n = D, 0;
                      e.push(yt(yt({}, f(g)), {}, {
                        key: o.key,
                        rowspan: 1,
                        slotType: "empty"
                      })), a = n
                    }, a = 0; a < v.length; a++) n(a);
                  h.push({
                    key: t.uid,
                    items: e
                  })
                }))
              }
              return {
                classRoomGroups: o,
                classrooms: n,
                times: v,
                columns: h,
                canApptEarlySeconds: y,
                zonePartDisplayType: r
              }
            })),
            v = (0, $.IJ)([]),
            h = (0, $.IJ)(0);
          (0, Q.wB)((function() {
            return t.settingData
          }), (function(t, e) {
            if (e) {
              var n, o = V()(n = m.value.times).call(n, (function(t) {
                return m.value.canApptEarlySeconds >= t.start && m.value.canApptEarlySeconds < t.end
              }));
              if (o > -1) {
                var l = a();
                l.select("#time-point-".concat(o)).boundingClientRect(), l.select("#booking-scroll").scrollOffset(), l.select("#booking-scroll").boundingClientRect(), l.select("#booking-thead").boundingClientRect(), l.exec((function(t) {
                  t[0] && t[1] && t[2] && t[3] && (h.value = t[0].top + t[1].scrollTop - t[2].top - t[3].height)
                }))
              }
            }
          }), {
            flush: "post"
          }), (0, Q.wB)((function() {
            return t.settingData
          }), (function() {
            v.value = []
          }));
          var g = (0, Y.E)((function() {
              var t;
              return U()(t = v.value).call(t, (function(t, e) {
                return e.forEach((function(e) {
                  e.relatedSlots && e.relatedSlots.length > 0 ? e.relatedSlots.forEach((function(e) {
                    t[e.id] || (t[e.id] = !0)
                  })) : t[e.id] = !0
                })), t
              }), {})
            })),
            S = function(e) {
              var n;
              return !(t.maxDuration && U()(e).call(e, (function(t, e) {
                return U()(e).call(e, (function(t, e) {
                  return t + e.durationMinutes
                }), t)
              }), 0) / 60 + (null !== (n = t.settingData.hasAppointTime) && void 0 !== n ? n : 0) > t.maxDuration) || (o.toast({
                title: "本店限制每天预约不得超过".concat(t.maxDuration, "小时"),
                icon: "none"
              }), !1)
            },
            T = function(t, e) {
              var n;
              return S(L()(n = []).call(n, (0, D.A)(t), [e]))
            },
            A = function(t) {
              return new(H())((function(e) {
                var n = (0, y.A)(t, 1)[0].startDateTime;
                et()().isAfter(n) ? o.modal({
                  title: "提示",
                  content: "该场次已过开场时间，如需预约，将按整场收费。"
                }).then((function(t) {
                  e(t.confirm)
                })) : e(!0)
              }))
            },
            C = function(t) {
              var e, n, a, o, l, r, s = (0, y.A)(t, 1)[0].slotType;
              if ("appt" === s) v.value = x()(e = b()(n = v.value).call(n, (function(t) {
                return x()(t).call(t, (function(t) {
                  return "appt" === t.slotType
                }))
              }))).call(e, (function(t) {
                return t.length > 0
              })), null !== (a = t[0].zonePartFlat) && void 0 !== a && a.type && (v.value = x()(l = b()(r = v.value).call(r, (function(e) {
                return x()(e).call(e, (function(e) {
                  var n, a;
                  return e.slot.chargeId !== t[0].slot.chargeId || (null === (n = e.zonePartFlat) || void 0 === n ? void 0 : n.type) === (null === (a = t[0].zonePartFlat) || void 0 === a ? void 0 : a.type) || !e.startDate.isBefore(t[0].endDate) || !e.endDate.isAfter(t[0].startDate)
                }))
              }))).call(l, (function(t) {
                return t.length > 0
              }))), v.value = L()(o = []).call(o, (0, D.A)(v.value), [t]);
              else if ("enroll" === s) v.value = [t];
              else if ("resale" === s) {
                var i, u, c;
                v.value = x()(i = b()(u = v.value).call(u, (function(t) {
                  return x()(t).call(t, (function(t) {
                    return "resale" === t.slotType
                  }))
                }))).call(i, (function(t) {
                  return t.length > 0
                })), v.value = L()(c = []).call(c, (0, D.A)(v.value), [t])
              }
            },
            I = function(t, e) {
              return 0 === t.length && 0 === e.length || !!(t.length > 0 && e.length > 0 && t[0].isSame(e[0]) && t[1].isSame(e[1]))
            },
            F = function(t) {
              var e;
              if ("part" === (null === (e = t.zonePartFlat) || void 0 === e ? void 0 : e.type)) {
                if (t.zonePartFlat.fixedTimeRange.length) return t.zonePartFlat.fixedTimeRange;
                if (0 === v.value.length) return [];
                var n, a = mt(v.value);
                try {
                  for (a.s(); !(n = a.n()).done;) {
                    var o = n.value,
                      l = k()(o).call(o, (function(e) {
                        return e.slot.chargeId === t.slot.chargeId && e.startDate.isSameOrBefore(t.startDate) && e.endDate.isSameOrAfter(t.endDate)
                      }));
                    if (l) return [l.startDate, l.endDate]
                  }
                } catch (t) {
                  a.e(t)
                } finally {
                  a.f()
                }
              }
              return []
            },
            E = function(t) {
              var e;
              return 1 === t.length && null !== (e = t[0].relatedSlots) && void 0 !== e && e.length ? t[0].relatedSlots : t
            },
            R = (0, $.IJ)(),
            N = function(t) {
              G.value = [], B.value = -1, R.value = t, W()
            },
            z = function(t, e) {
              var n;
              G.value = [], B.value = -1;
              var a = t.slot;
              if (null !== (n = a.apptInfo.hadVenueAppts) && void 0 !== n && n.length) {
                var o = a.apptInfo.hadVenueAppts[0].apptItems[0],
                  l = [];
                if (e.forEach((function(t) {
                    var e;
                    null !== (e = t.slot.apptInfo.hadVenueAppts) && void 0 !== e && e.some((function(t) {
                      return t.apptItems.some((function(t) {
                        return t.txtApptItemUid === o.txtApptItemUid
                      }))
                    })) && l.push(t)
                  })), l.length > 0) {
                  var r, s = U()(l).call(l, (function(t, e) {
                      return t.add(e.slot.cost)
                    }), ct()(0)).value,
                    i = U()(l).call(l, (function(t, e) {
                      var n;
                      return null === (n = e.slot.chargeParts) || void 0 === n || n.forEach((function(e) {
                        var n = k()(t).call(t, (function(t) {
                          return t.txtClassroomUid === e.txtClassroomUid
                        }));
                        n ? n.cost = ct()(n.cost).add(e.cost).value : t.push(yt({}, e))
                      })), t
                    }), []),
                    u = l[0],
                    c = l[l.length - 1];
                  R.value = (0, rt.gs)({
                    slotType: "appt",
                    slot: yt(yt({}, u.slot), {}, {
                      cost: s,
                      beginDatetime: u.slot.beginDatetime,
                      endDatetime: c.slot.endDatetime,
                      chargeParts: i
                    }),
                    relatedSlots: L()(r = []).call(r, l)
                  }), W()
                }
              }
            },
            G = (0, $.IJ)([]),
            B = (0, $.IJ)(-1),
            X = (0, st.C)(),
            K = X.value,
            W = X.toggle,
            Z = X.close,
            tt = (0, Y.E)((function() {
              var t = ct()(0),
                e = 0,
                n = [];
              return v.value.forEach((function(a) {
                var o, l, r, s, i, u, c = ct()(0);
                a.forEach((function(t) {
                  e += t.durationMinutes, c = c.add(ct()(t.slot.cost))
                }));
                var d = a[0],
                  f = a[a.length - 1],
                  p = 1 === (null === (o = d.slot) || void 0 === o ? void 0 : o.minGapType) ? ct()(0) : null !== (l = d.slot) && void 0 !== l && l.chargeFees ? U()(r = d.slot.chargeFees).call(r, (function(t, e) {
                    return t.add(e.amount)
                  }), ct()(0)) : ct()(0);
                t = t.add(c).add(p), n.push({
                  id: L()(s = L()(i = "".concat(d.slot.txtClassroomUid, "-")).call(i, d.slot.beginDatetime, "-")).call(s, f.slot.endDatetime),
                  name: d.slot.classRoomName,
                  timeRange: L()(u = "".concat(et()(d.startDateTime).format("HH:mm"), "-")).call(u, et()(f.endDateTime).format("HH:mm")),
                  amount: c.value,
                  feeAmount: p.value,
                  slotIds: b()(a).call(a, (function(t) {
                    return t.id
                  }))
                })
              })), {
                totalAmount: t.value,
                totalHours: e / 60,
                items: n
              }
            })),
            nt = (0, Y.E)((function() {
              var t = [];
              return v.value.forEach((function(e) {
                var n = e[0];
                if ("enroll" === n.slotType) {
                  var a, o, l, r, s, i = n.slot;
                  t.push({
                    enrollmentTitle: i.enrollmentRule.title,
                    name: i.classRoomName || "",
                    customerModels: (null === (a = i.enrollmentRule) || void 0 === a ? void 0 : a.customerModels) || [],
                    timeRange: L()(o = "".concat(et()(i.beginDatetime).format("HH:mm"), "-")).call(o, et()(i.endDatetime).format("HH:mm")),
                    enrollmentFee: (null === (l = i.enrollmentRule) || void 0 === l ? void 0 : l.enrollmentFee) || 0,
                    enrollmentLimitNum: (null === (r = i.enrollmentRule) || void 0 === r ? void 0 : r.enrollmentLimitNum) || 0,
                    participateCount: (null === (s = i.enrollmentRule) || void 0 === s ? void 0 : s.ParticipateCount) || 0
                  })
                }
              })), t
            })),
            ot = (0, st.C)(),
            ut = ot.value,
            vt = ot.toggle,
            ht = ot.close;
          (0, Q.wB)((function() {
            return tt.value.items.length
          }), (function(t) {
            0 === t && ht()
          }));
          var gt = (0, st.C)(),
            Dt = gt.value,
            St = gt.toggle,
            bt = (0, Y.E)((function() {
              return nt.value.length > 0
            }));
          return {
            currencySymbol: i,
            tableData: m,
            extraFeeText: s,
            checkedMap: g,
            onTapCellBtn: function(e, n) {
              var a = m.value.columns[e].items[n];
              if ("empty" !== a.slotType) {
                var l = v.value;
                if (l.some((function(t) {
                    return t.some((function(t) {
                      var e;
                      return null === (e = t.relatedSlots) || void 0 === e ? void 0 : e.some((function(t) {
                        return t.id === a.data.id
                      }))
                    }))
                  }))) v.value = x()(l).call(l, (function(t) {
                  return !t.some((function(t) {
                    var e;
                    return null === (e = t.relatedSlots) || void 0 === e ? void 0 : e.some((function(t) {
                      return t.id === a.data.id
                    }))
                  }))
                }));
                else {
                  var r, s = V()(l).call(l, (function(t) {
                    return t.some((function(t) {
                      return t.id === a.data.id
                    }))
                  }));
                  if (s > -1) v.value = L()(r = []).call(r, (0, D.A)(_()(l).call(l, 0, s)), (0, D.A)(_()(l).call(l, s + 1)));
                  else if ("enroll" !== a.slotType)
                    if ("resale" !== a.slotType) {
                      var i = a.data,
                        c = i.slot.apptInfo,
                        d = c.canApptOrNot,
                        f = c.status,
                        p = c.errorMessage,
                        h = i.zonePartFlat,
                        y = i.chargeGroupId,
                        g = i.slot,
                        P = g.minGap,
                        k = g.minGapType,
                        U = void 0 === k ? 0 : k,
                        M = g.projectType,
                        R = g.chargeParts,
                        O = void 0 === R ? [] : R,
                        j = u.value.chargeIdFormattedSlotsMap[y];
                      if ("popup" !== t.zonePartDisplayType || 10 !== f && 11 !== f)
                        if (d) {
                          var G = F(i),
                            B = function(t) {
                              return t.slot.apptInfo.canApptOrNot && I(G, F(t)) && !l.some((function(e) {
                                return e.some((function(e) {
                                  return e.id === t.id
                                })) || e.some((function(e) {
                                  var n;
                                  return null === (n = e.relatedSlots) || void 0 === n ? void 0 : n.some((function(e) {
                                    return e.id === t.id
                                  }))
                                }))
                              }))
                            };
                          if (0 !== U) {
                            var H = function(t) {
                              return t.slot.apptInfo.canApptOrNot && !l.some((function(e) {
                                return e.some((function(e) {
                                  return e.id === t.id
                                })) || e.some((function(e) {
                                  var n;
                                  return null === (n = e.relatedSlots) || void 0 === n ? void 0 : n.some((function(e) {
                                    return e.id === t.id
                                  }))
                                }))
                              }))
                            };
                            if (void 0 !== P && P > 1 && j) {
                              var X = V()(j).call(j, (function(t) {
                                return t.id === i.id
                              }));
                              if (X > -1) {
                                var K = function(t, e, n, a, o, l, r, s) {
                                  for (var i = 0; i < o.length; i++) {
                                    for (var u = E(o[i]), c = new(w())(b()(u).call(u, (function(t) {
                                        return t.id
                                      }))), d = a.length, f = -1, p = 0; p < a.length; p++) c.has(a[p].id) && (p < d && (d = p), p > f && (f = p));
                                    if (!(f < 0 || n !== f + 1 && n !== d - 1)) {
                                      var m = a[n];
                                      if (m && r(m) && u[0].chargeGroupId === t) return i
                                    }
                                  }
                                  return -1
                                }(y, i.id, X, j, l, 0, H);
                                if (K > -1) {
                                  var W, q, Q = l[K],
                                    $ = E(Q),
                                    Y = J()(W = L()(q = []).call(q, (0, D.A)($), [i])).call(W, (function(t, e) {
                                      return t.startDateTime - e.startDateTime
                                    })),
                                    Z = (0, D.A)(l);
                                  if (Z[K] = 2 === M ? [(0, rt.KX)(Y)] : Y, !S(Z)) return;
                                  return void A(Y).then((function(t) {
                                    t && (v.value = Z)
                                  }))
                                }
                                for (var tt = X + 1; tt - X < P && tt < j.length && H(j[tt]);) tt++;
                                for (; tt - X < P && X > 0 && H(j[X - 1]);) X--;
                                if (tt - X === P) {
                                  var et = _()(j).call(j, X, tt);
                                  2 === M ? T(l, et) && A(et).then((function(e) {
                                    e && ("flat" === t.zonePartDisplayType && h ? C([(0, rt.KX)(et)]) : O.length > 0 ? N((0, rt.KX)(et)) : C(et))
                                  })) : T(l, et) && A(et).then((function(t) {
                                    t && C(et)
                                  }))
                                } else {
                                  var nt;
                                  o.toast({
                                    title: "不足起订时长，请重新选择起订时长：".concat((null !== (nt = i.slot.gapMinutes) && void 0 !== nt ? nt : 0) * P / 60, "小时"),
                                    icon: "none"
                                  })
                                }
                              }
                            } else {
                              var at = [i];
                              2 === M ? T(l, at) && A(at).then((function(e) {
                                e && ("flat" === t.zonePartDisplayType && h ? C([(0, rt.KX)(at)]) : O.length > 0 ? N((0, rt.KX)(at)) : C(at))
                              })) : T(l, at) && A(at).then((function(t) {
                                t && C(at)
                              }))
                            }
                          } else if (void 0 !== P && P > 1 && j) {
                            var ot = V()(j).call(j, (function(t) {
                              return t.id === i.id
                            }));
                            if (ot > -1) {
                              for (var lt = ot + 1; lt - ot < P && lt < j.length && B(j[lt]);) lt++;
                              for (; lt - ot < P && ot > 0 && B(j[ot - 1]);) ot--;
                              if (lt - ot === P) {
                                var st = _()(j).call(j, ot, lt);
                                2 === M ? T(l, st) && A(st).then((function(e) {
                                  e && ("flat" === t.zonePartDisplayType && h ? C([(0, rt.KX)(st)]) : O.length > 0 ? N((0, rt.KX)(st)) : C(st))
                                })) : T(l, st) && A(st).then((function(t) {
                                  t && C(st)
                                }))
                              } else {
                                var it;
                                o.toast({
                                  title: "不足单场次时长，请重新选择单场次时长：".concat((null !== (it = i.slot.gapMinutes) && void 0 !== it ? it : 0) * P / 60, "小时"),
                                  icon: "none"
                                })
                              }
                            }
                          } else {
                            var ut = [i];
                            2 === M ? T(l, ut) && A(ut).then((function(e) {
                              e && ("flat" === t.zonePartDisplayType && h ? C([(0, rt.KX)(ut)]) : O.length > 0 ? N((0, rt.KX)(ut)) : C(ut))
                            })) : T(l, ut) && A(ut).then((function(t) {
                              t && C(ut)
                            }))
                          }
                        } else 8 === f && p && o.toast({
                          title: p
                        });
                      else z(i, j || [])
                    } else {
                      var ct = [a.data];
                      T(l, ct) && C(ct)
                    }
                  else {
                    var dt = [a.data];
                    C(dt)
                  }
                }
              }
            },
            handleDeleteCheckedData: function(t) {
              var e = (0, D.A)(v.value),
                n = V()(e).call(e, (function(e) {
                  return e.some((function(e) {
                    return M()(t).call(t, e.id)
                  }))
                })); - 1 !== n && (q()(e).call(e, n, 1), v.value = e)
            },
            orderData: tt,
            orderDetailsShow: ut,
            onTapOrderDetails: function() {
              tt.value.items.length > 0 && vt()
            },
            onPressOrderBtn: function() {
              var t;
              n("order", {
                slots: P()(t = v.value).call(t, (function(t) {
                  return [{
                    classroomUid: t[0].slot.txtClassroomUid,
                    beginDatetime: t[0].slot.beginDatetime,
                    endDatetime: t[t.length - 1].slot.endDatetime
                  }]
                }))
              })
            },
            scrollTop: h,
            enrollmentDetailsShow: Dt,
            onTapEnrollmentDetails: function() {
              St()
            },
            goEnrollment: function() {
              var t, e, n, a = v.value[0][0].slot,
                o = a.enrollmentRule,
                l = o.uidTxt,
                r = o.userId,
                s = o.id;
              wx.navigateTo({
                url: L()(t = L()(e = L()(n = "/marketingSubpages/pages/sportActivity/details/index?ruleUid=".concat(l, "&ruleUserId=")).call(n, r, "&id=")).call(e, s, "&storeId=")).call(t, a.userId)
              })
            },
            onEnrollmentNames: function() {
              var t, e = v.value[0][0].slot.enrollmentRule,
                n = e.uidTxt,
                a = e.userId;
              wx.navigateTo({
                url: L()(t = "/marketingSubpages/pages/sportActivity/enrolled-list/index?uid=".concat(n, "&userId=")).call(t, a)
              })
            },
            hasEnrollSlot: bt,
            enrollDataList: nt,
            handleShowPartsVenuePopup: N,
            partsVenuePopupShow: K,
            newFormattedSlot: R,
            onConfirmPartsVenuePopup: function() {
              if (R.value) {
                var t, e = R.value,
                  n = R.value.slot,
                  a = G.value;
                0 === B.value ? (C([e]), Z()) : null === (t = n.chargeParts) || void 0 === t || t.forEach((function(t) {
                  var o = [];
                  if (M()(a).call(a, t.txtClassroomUid)) {
                    var l = yt(yt({}, n), {}, {
                        apptPartStatus: t.apptPartStatus,
                        txtClassroomUid: t.txtClassroomUid,
                        classRoomName: t.classRoomName,
                        cost: t.cost,
                        chargeFees: t.chargeFees,
                        apptCount: t.apptCount
                      }),
                      r = (0, rt.gs)({
                        slotType: "appt",
                        slot: l,
                        relatedSlots: e.relatedSlots.length ? e.relatedSlots : [e]
                      });
                    o.push(r), C(o), Z()
                  }
                }))
              }
            },
            onChangePopupPartsVenue: function(t) {
              if (R.value) {
                var e = R.value.slot,
                  n = e.chargeParts || [],
                  a = G.value || [];
                if (-1 === t) {
                  if (10 === e.status || 11 === e.status) return;
                  return B.value = 0 === B.value ? -1 : 0, void(G.value = [])
                }
                B.value = 1;
                var o = n[t];
                if (o && !(o.apptCount > 0)) {
                  var l, r = o.txtClassroomUid;
                  M()(a).call(a, r) ? (G.value = x()(a).call(a, (function(t) {
                    return t !== r
                  })), 0 === G.value.length && (B.value = -1)) : G.value = L()(l = []).call(l, (0, D.A)(a), [r])
                }
              }
            },
            checkedType: B,
            closePartsVenuePopup: Z,
            checkedPopupClassroomUids: G
          }
        }
      })
    },
    22297: function(t) {
      t.exports = function(t, e) {
        e.prototype.isSameOrAfter = function(t, e) {
          return this.isSame(t, e) || this.isAfter(t, e)
        }
      }
    },
    35684: function(t) {
      t.exports = function(t, e) {
        e.prototype.isSameOrBefore = function(t, e) {
          return this.isSame(t, e) || this.isBefore(t, e)
        }
      }
    },
    95364: function(t, e, n) {
      t.exports = n(89730)
    },
    92501: function(t, e, n) {
      t.exports = n(59771)
    },
    3819: function(t, e, n) {
      n(91925), n(29704);
      var a = n(68015);
      t.exports = a("Array", "flatMap")
    },
    11887: function(t, e, n) {
      var a = n(99916),
        o = n(3819),
        l = Array.prototype;
      t.exports = function(t) {
        var e = t.flatMap;
        return t === l || a(l, t) && e === l.flatMap ? o : e
      }
    },
    67610: function(t, e, n) {
      n(1778), t.exports = -9007199254740991
    },
    15122: function(t, e, n) {
      var a = n(64835),
        o = n(95005),
        l = n(81768),
        r = n(7347),
        s = n(59843);
      t.exports = function t(e, n, i, u, c, d, f, p) {
        for (var m, v = c, h = 0, y = !!f && r(f, p); h < u;) h in i && (m = y ? y(i[h], h, n) : i[h], d > 0 && a(m) ? v = t(e, n, m, o(m), v, d - 1) - 1 : (l(v + 1), s(e, v, m)), v++), h++;
        return v
      }
    },
    91925: function(t, e, n) {
      var a = n(581),
        o = n(15122),
        l = n(81593),
        r = n(9112),
        s = n(95005),
        i = n(54320);
      a({
        target: "Array",
        proto: !0
      }, {
        flatMap: function(t) {
          var e, n = r(this),
            a = s(n);
          return l(t), e = i(n, 0), o(e, n, n, a, 0, 1, t, arguments.length > 1 ? arguments[1] : void 0), e
        }
      })
    },
    29704: function(t, e, n) {
      n(41368)("flatMap")
    },
    1778: function(t, e, n) {
      n(581)({
        target: "Number",
        stat: !0,
        nonConfigurable: !0,
        nonWritable: !0
      }, {
        MIN_SAFE_INTEGER: -9007199254740991
      })
    },
    89730: function(t, e, n) {
      var a = n(11887);
      t.exports = a
    },
    59771: function(t, e, n) {
      var a = n(67610);
      t.exports = a
    }
  },
  function(t) {
    t(t.s = 40669)
  }
]);