var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [3999], {
    85155: function() {},
    41800: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_14e266aa"
      }, n.g.currentInject.render = function(e, t, n, o) {
        o("moreLink", this.moreLink), o("scopeId", this.scopeId), o("showIcon", this.showIcon) && o("icon", this.icon), o("textStyle", this.textStyle), o("text", this.text), o("showMore", this.showMore), n()
      }
    },
    36725: function() {},
    4868: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_14e266aa", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(41800), n(36725), n(85155), n.g.currentSrcMode = "wx", n(20033)
    },
    20033: function(e, t, n) {
      n.r(t), (0, n(69996).A)({
        properties: {
          icon: String,
          text: String,
          textStyle: String,
          moreLink: Object,
          scopeId: Number,
          showMore: Boolean,
          showIcon: Boolean
        }
      })
    }
  },
  function(e) {
    e(e.s = 4868)
  }
]);