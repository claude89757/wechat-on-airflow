var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [7683], {
    84303: function() {},
    26031: function(n, t, e) {
      e.g.currentInject = {
        moduleId: "_2477b104"
      }, e.g.currentInject.render = function(n, t, e, r) {
        r("fontStyle", this.fontStyle), n(r("list", this.list), (function(n, t) {
          n.link, n.displayTitle
        })), e()
      }
    },
    7244: function() {},
    84016: function(n, t, e) {
      e(97766), e.g.currentModuleId = "_2477b104", e.g.currentCtor = Component, e.g.currentCtorType = "component", e.g.currentResourceType = "component", e(26031), e(7244), e(84303), e.g.currentSrcMode = "wx", e(55941)
    },
    55941: function(n, t, e) {
      e.r(t), (0, e(69996).A)({
        properties: {
          list: Array,
          fontStyle: String
        }
      })
    }
  },
  function(n) {
    n(n.s = 84016)
  }
]);