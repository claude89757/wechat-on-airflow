var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [9051], {
    97626: function() {},
    99920: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_3e9d7763"
      }, n.g.currentInject.render = function(e, t, n, a) {
        a("template", this.template) && (t("template.displayStyle", this.template.displayStyle), a("isTextInBottom", this.isTextInBottom), a("maxHight", this.maxHight), a("easingFn", this.easingFn), e(a("images", this.images), (function(t, n) {
          t.link.type ? (t.link, t.src, t.text && t.text.length > 0 && (a("activeIdx", this.activeIdx) == n && t.textAnima, t.flexStyle, e(t.text, (function(e, t) {
            e.fontStyles, e.content
          })))) : (t.src, t.text && t.text.length > 0 && (a("activeIdx", this.activeIdx) == n && t.textAnima, t.flexStyle, e(t.text, (function(e, t) {
            e.fontStyles, e.content
          }))))
        })), 2 === t("template.layoutType", this.template.layoutType) && a("bgImages", this.bgImages) && a("bgImages", this.bgImages).length > 0 && t("template.imgAnimas", this.template.imgAnimas) && t("template.imgAnimas", this.template.imgAnimas).length > 0 && (3 === t("template.imgAnimas[0]", this.template.imgAnimas[0]) ? (a("bgImages", this.bgImages).length, a("activeIdx", this.activeIdx), e(a("bgImages", this.bgImages), (function(e, t) {
          a("bgImages", this.bgImages).length, a("activeIdx", this.activeIdx)
        }))) : (t("template.imgAnimas[0]", this.template.imgAnimas[0]), e(a("bgImages", this.bgImages), (function(e, t) {
          a("activeIdx", this.activeIdx)
        })))), t("template.images", this.template.images).length, a("swiperLineLeft", this.swiperLineLeft)), n()
      }, n.g.currentInject.getRefsData = function() {
        return [{
          key: "image",
          selector: ".ref_image_1",
          type: "node",
          all: !0
        }, {
          key: "image1",
          selector: ".ref_image1_2",
          type: "node",
          all: !0
        }, {
          key: "bgImage1",
          selector: ".ref_bgImage1_3",
          type: "node",
          all: !0
        }, {
          key: "bgImage2",
          selector: ".ref_bgImage2_4",
          type: "node",
          all: !0
        }]
      }
    },
    77442: function() {},
    7667: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_3e9d7763", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(99920), n(77442), n(97626), n.g.currentSrcMode = "wx", n(1471)
    },
    1471: function(e, t, n) {
      n.r(t);
      var a = n(49e3),
        i = n.n(a),
        l = n(17195),
        c = n.n(l),
        r = n(74058),
        s = n.n(r),
        m = n(82567),
        g = n.n(m),
        o = n(87802),
        u = n.n(o),
        p = n(27715),
        f = n(39298),
        h = n(93690),
        x = n.n(h),
        I = n(60192),
        d = n.n(I),
        b = n(74282),
        y = n.n(b),
        v = n(57391),
        A = n.n(v),
        _ = n(70841),
        k = n(39347),
        C = n(69996),
        j = n(90356);

      function w(e, t) {
        var n = i()(e);
        if (c()) {
          var a = c()(e);
          t && (a = s()(a).call(a, (function(t) {
            return g()(e, t).enumerable
          }))), n.push.apply(n, a)
        }
        return n
      }

      function S(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? w(Object(n), !0).forEach((function(t) {
            (0, f.A)(e, t, n[t])
          })) : u() ? Object.defineProperties(e, u()(n)) : w(Object(n)).forEach((function(t) {
            Object.defineProperty(e, t, g()(n, t))
          }))
        }
        return e
      }
      var L = ["flex-start", "center", "flex-end"],
        O = ["default", "linear", "easeInCubic", "easeOutCubic", "easeInOutCubic"];
      (0, C.A)({
        properties: {
          template: Object
        },
        setup: function(e, t) {
          var n = t.refs,
            a = (0, k.E)((function() {
              var t;
              return x()(t = e.template.images).call(t, (function(e, t) {
                var n, a;
                return {
                  key: t,
                  src: e.src2 ? e.src2 : e.src,
                  link: e.link,
                  text: e.text && e.text.length > 0 && x()(n = e.text).call(n, (function(e) {
                    return S(S({}, e), {}, {
                      fontStyles: (0, j.W9)(e.size, e.color, e.isBlod)
                    })
                  })),
                  textAnima: e.textAnima,
                  flexStyle: d()(a = "justify-content:".concat(L[e.textVerticalAlgin], "; align-items:")).call(a, L[e.textAlgin], ";")
                }
              }))
            })),
            i = (0, k.E)((function() {
              var t, n = x()(t = e.template.images).call(t, (function(e) {
                return e.src2 ? e.src : ""
              }));
              return e.template.imgAnimas && 3 === e.template.imgAnimas[0] ? y()(n).call(n) : n
            })),
            l = (0, _.KR)(0),
            c = (0, _.KR)(0),
            r = (0, _.KR)(0),
            s = (0, k.E)((function() {
              var t;
              if (2 === e.template.layoutType) return d()(t = "".concat(O)).call(t, e.template.imgAnimas[1])
            }));
          return {
            images: a,
            bgImages: i,
            onImageLoad: function() {
              var e;
              A().all(x()(e = ["image", "image1", "bgImage1", "bgImage2"]).call(e, (function(e) {
                return new(A())((function(t) {
                  n[e].boundingClientRect((function(e) {
                    t(Math.max.apply(Math, (0, p.A)(x()(e).call(e, (function(e) {
                      return e.height
                    })))))
                  })).exec()
                }))
              }))).then((function(e) {
                l.value = Math.max.apply(Math, (0, p.A)(e))
              }))
            },
            maxHight: l,
            swiperChange: function(t) {
              c.value = t.detail.current, e.template.images.length > 1 && (r.value = t.detail.current * (100 / e.template.images.length))
            },
            activeIdx: c,
            easingFn: s,
            swiperLineLeft: r
          }
        }
      })
    },
    74282: function(e, t, n) {
      e.exports = n(8536)
    }
  },
  function(e) {
    e(e.s = 7667)
  }
]);