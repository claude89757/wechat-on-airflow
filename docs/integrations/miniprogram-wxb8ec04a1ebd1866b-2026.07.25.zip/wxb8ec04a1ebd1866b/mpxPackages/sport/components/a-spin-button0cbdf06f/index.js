var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [4491], {
    61434: function() {},
    98025: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_0cbdf06f"
      }, r.g.currentInject.render = function(n, e, r, t) {
        t("disabled", this.disabled), !t("disabled", this.disabled) && t("spinning", this.spinning), r()
      }
    },
    8531: function() {},
    37669: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_0cbdf06f", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(98025), r(8531), r(61434), r.g.currentSrcMode = "wx", r(28658)
    },
    28658: function(n, e, r) {
      r.r(e), (0, r(69996).A)({
        properties: {
          disabled: Boolean,
          spinning: Boolean
        },
        setup: function(n, e) {
          var r = e.triggerEvent;
          return {
            onPress: function() {
              n.spinning || r("press")
            }
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 37669)
  }
]);