var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [4906], {
    21825: function() {},
    83027: function(e, n, t) {
      t.g.currentInject = {
        moduleId: "_1189e3ca"
      }, t.g.currentInject.render = function(e, n, t, r) {
        r("type", this.type), r("styleType", this.styleType), r("background", this.background), t()
      }
    },
    98958: function() {},
    86262: function(e, n, t) {
      t(97766), t.g.currentModuleId = "_1189e3ca", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "component", t(83027), t(98958), t(21825), t.g.currentSrcMode = "wx", t(17575)
    },
    17575: function(e, n, t) {
      t.r(n), (0, t(69996).A)({
        properties: {
          type: {
            type: Number,
            value: 0
          },
          styleType: {
            type: Number,
            value: 0
          },
          background: {
            type: String,
            value: "#ffffff"
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 86262)
  }
]);