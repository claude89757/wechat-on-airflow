var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [5683], {
    36544: function() {},
    63837: function(e, n, t) {
      var r = t(72244);
      t.g.currentInject = {
        moduleId: "_8d52aa42"
      }, t.g.currentInject.render = function(e, n, t, u) {
        u("value", this.value), r.c("a-checkbox", {
          disabled: u("disabled", this.disabled),
          checked: u("value", this.value)
        }), t()
      }
    },
    42911: function() {},
    37061: function(e, n, t) {
      t(97766), t.g.currentModuleId = "_8d52aa42", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "component", t(63837), t(42911), t(36544), t.g.currentSrcMode = "wx", t(70798)
    },
    70798: function(e, n, t) {
      t.r(n), (0, t(69996).A)({
        properties: {
          value: Boolean,
          disabled: Boolean
        },
        setup: function(e, n) {
          var t = n.triggerEvent;
          return {
            onTap: function() {
              e.disabled || t("input", {
                value: !e.value
              })
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 37061)
  }
]);