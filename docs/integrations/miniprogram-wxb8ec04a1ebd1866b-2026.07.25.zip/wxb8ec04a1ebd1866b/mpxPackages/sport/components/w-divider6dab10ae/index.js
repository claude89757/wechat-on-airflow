var e = {};
e.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [6146], {
    79635: function() {},
    17629: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_6dab10ae"
      }, n.g.currentInject.render = function(e, t, n, o) {
        o("template", this.template) && (t("template.displayStyle", this.template.displayStyle), t("template.bgColor", this.template.bgColor), t("template.height", this.template.height), t("template.color", this.template.color)), n()
      }
    },
    19715: function() {},
    21542: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_6dab10ae", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(17629), n(19715), n(79635), n.g.currentSrcMode = "wx", n(76515)
    },
    76515: function(e, t, n) {
      n.r(t), (0, n(69996).A)({
        properties: {
          template: Object
        }
      })
    }
  },
  function(e) {
    e(e.s = 21542)
  }
]);