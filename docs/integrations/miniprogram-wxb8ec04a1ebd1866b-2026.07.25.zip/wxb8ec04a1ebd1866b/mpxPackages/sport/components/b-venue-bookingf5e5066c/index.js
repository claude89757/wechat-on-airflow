var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [6723], {
    27156: function() {},
    66701: function(t, e, o) {
      o.g.currentInject = {
        moduleId: "_f5e5066c"
      }, o.g.currentInject.render = function(t, e, o, r) {
        0 == e("project.type", this.project.type) || 2 == e("project.type", this.project.type) ? (e("project.txtUid", this.project.txtUid), r("settingData", this.settingData), r("allowedClassroomUids", this.allowedClassroomUids), r("maxDuration", this.maxDuration)) : 1 == e("project.type", this.project.type) && (e("project.txtUid", this.project.txtUid), r("settingData", this.settingData), r("allowedClassroomUids", this.allowedClassroomUids), r("showBookedAvatar", this.showBookedAvatar)), o()
      }
    },
    72274: function() {},
    53819: function(t, e, o) {
      o(97766), o.g.currentModuleId = "_f5e5066c", o.g.currentCtor = Component, o.g.currentCtorType = "component", o.g.currentResourceType = "component", o(66701), o(72274), o(27156), o.g.currentSrcMode = "wx", o(48864)
    },
    48864: function(t, e, o) {
      o.r(e), (0, o(69996).A)({
        properties: {
          project: Object,
          settingData: Object,
          allowedClassroomUids: Array,
          maxDuration: Number,
          showBookedAvatar: Boolean
        },
        setup: function(t, e) {
          var o = e.triggerEvent;
          return {
            onOrder: function(t) {
              o("order", t.detail)
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 53819)
  }
]);