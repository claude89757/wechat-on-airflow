var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [2149], {
    51068: function() {},
    85744: function(t, e, a) {
      a.g.currentInject = {
        moduleId: "_75970f5e"
      }, a.g.currentInject.render = function(t, e, a, n) {
        n("template", this.template) && (e("template.background", this.template.background) && e("template.background", this.template.background), e("template.data", this.template.data) && e("template.data.photoPath", this.template.data.photoPath), e("template.showExpDate", this.template.showExpDate) && e("template.data", this.template.data) && e("template.data.durationInDays", this.template.data.durationInDays) && e("template.data.durationInDays", this.template.data.durationInDays)), a()
      }
    },
    42256: function() {},
    55809: function(t, e, a) {
      a(97766), a.g.currentModuleId = "_75970f5e", a.g.currentCtor = Component, a.g.currentCtorType = "component", a.g.currentResourceType = "component", a(85744), a(42256), a(51068), a.g.currentSrcMode = "wx", a(35830)
    },
    35830: function(t, e, a) {
      a.r(e);
      var n = a(40519);
      (0, a(69996).A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          return (0, n.nT)((function() {
            wx.setNavigationBarColor({
              frontColor: t.template.frontColor,
              backgroundColor: "#000000"
            })
          })), {}
        }
      })
    }
  },
  function(t) {
    t(t.s = 55809)
  }
]);