var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [6899], {
    61358: function() {},
    57410: function(t, n, e) {
      e.g.currentInject = {
        moduleId: "_3de85533"
      }, e.g.currentInject.render = function(t, n, e, r) {
        t(r("list", this.list), (function(t, n) {
          r("tab", this.tab), t.link, 2 == t.customImgs.length ? t.customImgs[r("tab", this.tab) == n ? 1 : 0] : t.icons[r("tab", this.tab) == n ? 1 : 0], t.title || t.name
        })), e()
      }, e.g.currentInject.getRefsData = function() {
        return [{
          key: "tabBar",
          selector: ".ref_tabBar_1",
          type: "node",
          all: !1
        }]
      }
    },
    84348: function() {},
    24251: function(t, n, e) {
      e(97766), e.g.currentModuleId = "_3de85533", e.g.currentCtor = Component, e.g.currentCtorType = "component", e.g.currentResourceType = "component", e(57410), e(84348), e(61358), e.g.currentSrcMode = "wx", e(97852)
    },
    97852: function(t, n, e) {
      e.r(n);
      var r = e(57187),
        c = e(69996),
        o = e(6520);
      (0, c.A)({
        properties: {
          list: Array,
          tab: Number
        },
        setup: function(t, n) {
          var e = n.refs,
            c = n.triggerEvent;
          return (0, o.sV)((function() {
            e.tabBar.boundingClientRect((function(t) {
              c("update", {
                height: 0,
                safeBottom: t.height
              })
            })).exec()
          })), {
            onTapTab: function(n) {
              r.F.switchTab(n, t.list[n].link)
            }
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 24251)
  }
]);