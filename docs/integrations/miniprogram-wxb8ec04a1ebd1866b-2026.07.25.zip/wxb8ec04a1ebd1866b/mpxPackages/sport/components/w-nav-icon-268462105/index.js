var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [7063], {
    23796: function() {},
    40514: function(n, e, t) {
      t.g.currentInject = {
        moduleId: "_68462105"
      }, t.g.currentInject.render = function(n, e, t, r) {
        r("even", this.even), n(r("list", this.list), (function(n, e) {
          n.link, n.src, n.displayTitle
        })), t()
      }
    },
    88766: function() {},
    12101: function(n, e, t) {
      t(97766), t.g.currentModuleId = "_68462105", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "component", t(40514), t(88766), t(23796), t.g.currentSrcMode = "wx", t(75718)
    },
    75718: function(n, e, t) {
      t.r(e), (0, t(69996).A)({
        properties: {
          list: Array
        },
        setup: function(n) {
          return {
            even: n.list.length % 2 == 0
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 12101)
  }
]);