var t = {};
t.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (t.webpackChunk_mpxapp_decoration = t.webpackChunk_mpxapp_decoration || []).push([
  [7454], {
    52199: function() {},
    37171: function(t, e, n) {
      n.g.currentInject = {
        moduleId: "_5e3c018e"
      }, n.g.currentInject.render = function(t, e, n, c) {
        c("template", this.template) && c("scopeList", this.scopeList) && c("scopeList", this.scopeList).length && (e("template.bgColor", this.template.bgColor), c("paddingTop", this.paddingTop), t(c("scopeList", this.scopeList), (function(e, n) {
          e.style, 1 == e.images.length ? (e.images[0].link, e.images[0].src) : t(e.images, (function(t, e) {
            t.link, t.src
          }))
        }))), n()
      }
    },
    75025: function() {},
    5432: function(t, e, n) {
      n(97766), n.g.currentModuleId = "_5e3c018e", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "component", n(37171), n(75025), n(52199), n.g.currentSrcMode = "wx", n(99741)
    },
    99741: function(t, e, n) {
      n.r(e);
      var c = n(39298),
        r = n(91630),
        o = n.n(r),
        i = n(60192),
        a = n.n(i),
        l = n(93690),
        p = n.n(l),
        u = n(49e3),
        s = n.n(u),
        h = n(17195),
        m = n.n(h),
        f = n(74058),
        g = n.n(f),
        d = n(82567),
        v = n.n(d),
        x = n(87802),
        b = n.n(x),
        y = n(69996),
        k = n(50553);

      function j(t, e) {
        var n = s()(t);
        if (m()) {
          var c = m()(t);
          e && (c = g()(c).call(c, (function(e) {
            return v()(t, e).enumerable
          }))), n.push.apply(n, c)
        }
        return n
      }

      function C(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2 ? j(Object(n), !0).forEach((function(e) {
            (0, c.A)(t, e, n[e])
          })) : b() ? Object.defineProperties(t, b()(n)) : j(Object(n)).forEach((function(e) {
            Object.defineProperty(t, e, v()(n, e))
          }))
        }
        return t
      }(0, y.A)({
        properties: {
          template: Object
        },
        setup: function(t) {
          var e = t.template,
            n = e.size,
            c = e.gap,
            r = void 0 === c ? 0 : c,
            i = e.scopes,
            l = function(t) {
              var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : n;
              return (0, k.c)(t / e * 100)
            },
            u = o()(i).call(i, (function(t, e) {
              var n = e.style;
              return t.minY = Math.min(t.minY, n.top), t.maxY = Math.max(t.maxY, n.top + n.height), t
            }), {
              minY: n,
              maxY: 0
            }),
            s = u.minY,
            h = u.maxY,
            m = h - s,
            f = "".concat(l(m), "%"),
            g = function(t) {
              var e, c, o, i = t.width,
                l = t.height,
                p = t.top,
                u = t.left;
              return r > 0 ? a()(e = a()(c = a()(o = "".concat(p === s ? 0 : r, "rpx ")).call(o, u + i === n ? 0 : r, "rpx ")).call(c, p + l === h ? 0 : r, "rpx ")).call(e, 0 === u ? 0 : r, "rpx") : "0"
            };
          return {
            paddingTop: f,
            scopeList: p()(i).call(i, (function(t) {
              var e, n, c, r, o, i, u, h, f = t.style,
                d = f.width,
                v = f.height,
                x = f.top,
                b = f.left;
              return {
                key: a()(e = a()(n = a()(c = "".concat(d, "-")).call(c, v, "-")).call(n, x, "-")).call(e, b),
                style: a()(r = a()(o = a()(i = a()(u = "width:".concat(l(d), "%;height:")).call(u, l(v, m), "%;top:")).call(i, l(x - s, m), "%;left:")).call(o, l(b), "%;padding:")).call(r, g(t.style)),
                images: p()(h = t.images).call(h, (function(t, e) {
                  var n;
                  return C(C({}, t), {}, {
                    key: a()(n = "".concat(e, "-")).call(n, t.src)
                  })
                }))
              }
            }))
          }
        }
      })
    }
  },
  function(t) {
    t(t.s = 5432)
  }
]);