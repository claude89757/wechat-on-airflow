var n = {};
n.webpackChunk_mpxapp_decoration = require("../../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [251], {
    79113: function() {},
    2358: function(n, e, r) {
      r.g.currentInject = {
        moduleId: "_4c74e254"
      }, r.g.currentInject.render = function(n, e, r, c) {
        c("name", this.name), r()
      }
    },
    13906: function() {},
    70619: function() {},
    90132: function(n, e, r) {
      r(97766), r.g.currentModuleId = "_4c74e254", r.g.currentCtor = Component, r.g.currentCtorType = "component", r.g.currentResourceType = "component", r(2358), r(70619), r(13906), r(79113), r.g.currentSrcMode = "wx", r(25205)
    },
    25205: function(n, e, r) {
      r.r(e), (0, r(69996).A)({
        properties: {
          name: String
        }
      })
    }
  },
  function(n) {
    n(n.s = 90132)
  }
]);