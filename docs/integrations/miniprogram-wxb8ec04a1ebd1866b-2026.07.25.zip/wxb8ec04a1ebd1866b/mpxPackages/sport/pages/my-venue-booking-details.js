var e = {};
e.webpackChunk_mpxapp_decoration = require("../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [5011], {
    50903: function() {},
    15866: function(e, n, t) {
      t.g.currentInject = {
        moduleId: "_ff66af4e"
      }, t.g.currentInject.render = function(e, n, t, o) {
        n("apptInfo.date", this.apptInfo.date), n("apptInfo.storeName", this.apptInfo.storeName), e(n("apptInfo.apptItems", this.apptInfo.apptItems), (function(n, t) {
          n.status, n.classroomName, n.status, n.status, n.time, n.capacity, n.totalCost, e(n.chargeFees, (function(e, n) {
            e.feeTypeName, o("currencySymbol", this.currencySymbol), e.amount
          })), 2 != n.status && n.allowControlDevice, 2 != n.status && n.allowControlDevice
        })), o("currencySymbol", this.currencySymbol), n("apptInfo.appointAmount", this.apptInfo.appointAmount), n("apptInfo.feeAmount", this.apptInfo.feeAmount) > 0 && (o("extraFeeText", this.extraFeeText), o("currencySymbol", this.currencySymbol), n("apptInfo.feeAmount", this.apptInfo.feeAmount)), o("currencySymbol", this.currencySymbol), n("apptInfo.appointFeeAmount", this.apptInfo.appointFeeAmount), o("currencySymbol", this.currencySymbol), n("apptInfo.appointFeeAmount", this.apptInfo.appointFeeAmount), e(n("apptInfo.paymentMethods", this.apptInfo.paymentMethods), (function(e, n) {
          e.icon && e.icon, e.name
        })), o("allowInvoiceBtn", this.allowInvoiceBtn), o("showCancelPopup", this.showCancelPopup), o("openDoorPopupShow", this.openDoorPopupShow), o("openDoorMessage", this.openDoorMessage), o("posterPopupInfo", this.posterPopupInfo) && (o("posterPopupShow", this.posterPopupShow), o("posterPopupInfo", this.posterPopupInfo)), t()
      }
    },
    2471: function() {},
    99138: function(e, n, t) {
      t(97766), t.g.currentModuleId = "_ff66af4e", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "page", t(15866), t(2471), t(50903), t.g.currentSrcMode = "wx", t(63757)
    },
    63757: function(e, n, t) {
      t.r(n);
      var o = t(27715),
        a = t(91630),
        u = t.n(a),
        r = t(74058),
        i = t.n(r),
        c = t(93690),
        s = t.n(c),
        p = t(57391),
        l = t.n(p),
        m = t(60192),
        f = t.n(m),
        d = t(78475),
        v = t.n(d),
        I = t(64448),
        h = t.n(I),
        A = t(80492),
        C = t.n(A),
        y = t(61740),
        g = t(39164),
        P = t(86340),
        b = t(11821),
        w = t(40519),
        N = t(39347),
        T = t(6520),
        x = t(95766),
        D = t(84665),
        U = t.n(D),
        M = t(31259),
        E = t.n(M),
        B = t(10212),
        S = t.n(B),
        _ = t(70841),
        F = t(39295),
        k = t(46902),
        O = t(66855),
        V = t(83887);

      function L(e, n) {
        var t;
        return u()(t = e || []).call(t, (function(e, t) {
          return E()(e).add(n(t) || 0).value
        }), 0)
      }

      function J(e) {
        return E()(e.appointAmount || 0).add(function(e) {
          var n, t, o = L(i()(n = e.apptPayments || []).call(n, (function(e) {
              return -5008 === e.payMethodCode && null != e.couponPrice
            })), (function(e) {
              return e.couponPrice
            })),
            a = L(i()(t = e.apptUseCouponLogs || []).call(t, (function(e) {
              return 1 === e.status && null != e.couponPrice
            })), (function(e) {
              return e.couponPrice
            }));
          return E()(o).add(a).value
        }(e)).subtract(function(e) {
          var n;
          return L(i()(n = e.apptPayments || []).call(n, (function(e) {
            return -5008 === e.payMethodCode
          })), (function(e) {
            return e.amount
          }))
        }(e)).value
      }

      function j(e) {
        return Math.round(100 * e) / 100
      }
      U().extend(S()), (0, x.A)({
        setup: function() {
          var e = (0, T.nI)(),
            n = (0, g.JX)(),
            t = (0, O.uP)(),
            a = (0, V.G)(),
            r = (0, N.E)((function() {
              return "1" === t.data.CustomerControlDevice
            })),
            c = (0, N.E)((function() {
              return t.data.currency
            })),
            p = (0, N.E)((function() {
              return a.messages.extraFee
            })),
            m = (0, P.N)((function(e) {
              return e.uid ? {
                userId: e.userId ? Number(e.userId) : void 0,
                uid: e.uid
              } : l().reject(new Error("页面参数错误"))
            })),
            d = m.data,
            I = m.pending,
            A = m.error,
            x = (0, b._y)("AppointmentVenue/LoadVenueApptDetail", {
              params: function() {
                return d.value ? {
                  userId: d.value.userId,
                  apptUid: d.value.uid
                } : y.Oy
              },
              transform: function(e) {
                return e.result
              }
            }),
            D = x.data,
            M = x.pending,
            B = x.error,
            S = x.execute,
            L = (0, N.E)((function() {
              var e, n, t, u, p, l = D.value,
                m = r.value,
                d = !0,
                v = "",
                I = !0;
              if (!l) return {
                date: "-",
                storeName: "-",
                apptItems: [],
                appointAmount: 0,
                feeAmount: 0,
                appointFeeAmount: 0,
                paymentMethods: [],
                allowCancel: d,
                canNotCancelReason: v,
                allowInvoice: I
              };
              var h = l.venueAppt,
                A = l.settings,
                C = l.useDouyinCoupon,
                y = J(h),
                g = function(e, n, t) {
                  if (0 === e.length) return [];
                  if (n === t) return s()(e).call(e, (function(e) {
                    return e.totalCost || 0
                  }));
                  if (1 === e.length || !n) return s()(e).call(e, (function(e, n) {
                    return 0 === n ? t : e.totalCost || 0
                  }));
                  var o = t;
                  return s()(e).call(e, (function(a, u) {
                    if (u === e.length - 1) return j(o);
                    var r = j((a.totalCost || 0) / n * t);
                    return o = E()(o).subtract(r).value, r
                  }))
                }(h.apptClassroomItems, h.appointAmount || 0, y);
              return A.forEach((function(e) {
                d && 1 !== e.allowCancel && (d = !1, v = "该预约不可取消")
              })), h.apptClassroomItems.forEach((function(e) {
                d && 1 !== e.status && (d = !1, v = "该预约已有取消记录，无法再次取消"), I && 1 !== e.status && (I = !1)
              })), d && C && U()().diff(U()(h.createdDatetime), "hours", !0) >= 1 && (d = !1, v = "该预约核销抖音券已超过1小时，无法取消"), {
                date: U()(h.apptClassroomItems[0].beginDatetime).format("YYYY.MM.DD ddd"),
                storeName: h.storeName,
                apptItems: s()(e = h.apptClassroomItems).call(e, (function(e, n) {
                  var t;
                  return {
                    id: e.id,
                    uid: e.txtUid,
                    classroomName: e.classroomName,
                    time: U()(e.beginDatetime).format("HH:mm") + "-" + U()(e.endDatetime).format("HH:mm"),
                    capacity: e.serviceClassroom && e.serviceClassroom.capacity ? e.serviceClassroom.capacity + "人" : "-",
                    totalCost: g[n],
                    status: e.status,
                    allowControlDevice: m && U()().isBetween(e.beginDatetime, e.endDatetime, "second", "[]"),
                    chargeFees: null === (t = h.apptClassroomItemFees) || void 0 === t ? void 0 : i()(t).call(t, (function(n) {
                      return n.txtItemUid === e.txtUid
                    }))
                  }
                })),
                appointAmount: y,
                feeAmount: h.feeAmount || 0,
                appointFeeAmount: E()(y).add(h.feeAmount || 0).value,
                paymentMethods: f()(n = []).call(n, (0, o.A)(s()(t = h.apptPayments).call(t, (function(e) {
                  var n = e.payMethodName,
                    t = "";
                  switch (e.payMethodCode) {
                    case 7:
                      t = "balance_pay";
                      break;
                    case 17:
                      t = "wechat_pay";
                      break;
                    case 19:
                      t = "shopping_card_pay", n = a.messages.shoppingCard;
                      break;
                    case 97:
                      t = "venue_card_pay"
                  }
                  return {
                    id: "pay-".concat(e.id),
                    name: n,
                    icon: t
                  }
                }))), (0, o.A)(s()(u = i()(p = h.apptUseCouponLogs || []).call(p, (function(e) {
                  return 1 === e.status && null != e.couponPrice
                }))).call(u, (function(e) {
                  var n, t;
                  return {
                    id: "coupon-".concat(e.id),
                    name: f()(n = f()(t = "".concat(e.couponIncomeCustomPaymethodName || "优惠券", " ")).call(t, c.value)).call(n, e.couponPrice),
                    icon: ""
                  }
                })))),
                allowCancel: d,
                canNotCancelReason: v,
                allowInvoice: I
              }
            })),
            H = (0, _.IJ)(!1),
            R = function() {
              H.value = !1
            },
            W = (0, b.B8)("AppointmentVenue/CancelVenueApptAllItem"),
            Y = W.pending,
            Q = W.error,
            q = W.execute,
            G = (0, b.B8)("Invoice/QueryInvoice", {}, {
              resInterceptor: function(e) {
                return e
              }
            }),
            X = G.pending,
            z = G.error,
            K = G.execute,
            Z = (0, _.IJ)(!1),
            $ = (0, _.IJ)(!1),
            ee = (0, N.E)((function() {
              return $.value ? ae.value : null
            })),
            ne = (0, N.E)((function() {
              return t.data.HasInvoiceSetting && L.value.allowInvoice && !Z.value
            }));
          (0, w.wB)((function() {
            var e;
            return null === (e = d.value) || void 0 === e ? void 0 : e.uid
          }), (function(e) {
            e && ue({
              businessType: "VENUE_APPOINTMENT",
              businessUid: e
            }).then((function() {})).catch((function(e) {
              var n;
              null != e && null !== (n = e.message) && void 0 !== n && v()(n).call(n, "未开启扫码开票") && (Z.value = !0)
            }))
          }));
          var te = (0, b.B8)("Invoice/CheckInvoice"),
            oe = te.pending,
            ae = te.error,
            ue = te.execute,
            re = (0, b.B8)("AppointmentVenue/LoadWithWriteOffTime"),
            ie = re.pending,
            ce = re.execute,
            se = void 0;
          (0, T.hi)((function() {
            clearTimeout(se)
          }));
          var pe = (0, _.IJ)(!1),
            le = (0, _.IJ)(),
            me = (0, _.IJ)(!1),
            fe = (0, _.IJ)(""),
            de = (0, b.B8)("Appointment/OpenLightForce"),
            ve = de.pending,
            Ie = de.error,
            he = de.execute,
            Ae = (0, b.B8)("Appointment/CloseLightForce"),
            Ce = Ae.pending,
            ye = Ae.error,
            ge = Ae.execute;
          return (0, g.BU)([I, M, Y, X, oe, ie, ve, Ce]), (0, g.FB)([A, B, Q, z, ee, Ie, ye]), {
            currencySymbol: c,
            apptInfo: L,
            extraFeeText: p,
            allowInvoiceBtn: ne,
            onPressCancelBtn: function() {
              L.value.allowCancel ? H.value = !0 : n.error({
                content: L.value.canNotCancelReason
              })
            },
            showCancelPopup: H,
            onTapCancelPopupMask: R,
            onPressCancelPupupCancelBtn: R,
            onPressCancelPupupConfirmBtn: function() {
              !Y.value && d.value && q({
                apptUid: d.value.uid,
                userId: d.value.userId
              }).then((function() {
                H.value = !1, S(), e.proxy.getOpenerEventChannel().emit("refresh")
              })).catch((function() {
                H.value = !1
              }))
            },
            onPressInvoiceBtn: function() {
              if (!X.value && !oe.value && d.value) {
                var e = d.value.uid;
                K({
                  businessType: "VENUE_APPOINTMENT",
                  businessUid: e
                }).then((function(t) {
                  if (t.successed) {
                    if (!t.result.downloadUrl) return void n.error({
                      content: "单据还未生成，请稍后再试"
                    });
                    n.error({
                      content: "开票完成，请前往邮箱查看"
                    })
                  } else 5e3 === t.errorCode ? ($.value = !0, ue({
                    businessType: "VENUE_APPOINTMENT",
                    businessUid: e
                  }).then((function(n) {
                    var t, a, r, i, c = n.result,
                      p = h()({
                        orderAmount: c.invoiceAmount,
                        totalAmountForInvoice: c.invoiceAmounts ? u()(t = c.invoiceAmounts).call(t, (function(e, n) {
                          return e + n.amount
                        }), 0) : 0,
                        totalNonAmounts: c.notInvoiceAmounts ? u()(a = c.notInvoiceAmounts).call(a, (function(e, n) {
                          return e + n.amount
                        }), 0) : 0,
                        nonAmountsRemark: c.notInvoiceAmounts ? (0, o.A)(new(C())(s()(r = c.notInvoiceAmounts).call(r, (function(e) {
                          return e.remark
                        })))).join(", ") : ""
                      });
                    wx.navigateTo({
                      url: f()(i = "/pages/order/invoice/index?businessType=VENUE_APPOINTMENT&businessUid=".concat(e, "&invoiceDetailsInfo=")).call(i, p)
                    })
                  }))) : n.error({
                    content: t.message || "发生错误了"
                  })
                }))
              }
            },
            onPressVenueQrcodeBtn: function(e) {
              if (D.value) {
                var t = D.value.venueAppt,
                  o = t.storeName,
                  a = t.storeAddress,
                  u = D.value.venueAppt.apptClassroomItems[e];
                ce({
                  venueappointmentclassroomitemId: u.id
                }).then((function(e) {
                  var t = e.result || 0;
                  (function e() {
                    se = setTimeout((function() {
                      (0, F.S1)("AppointmentVenue/LoadWithWriteOffTime", {
                        params: {
                          venueappointmentclassroomitemId: u.id
                        }
                      }).then((function(o) {
                        if ((o.result || 0) > t) pe.value = !1, n.error({
                          content: "门已开"
                        });
                        else {
                          if (!pe.value) return;
                          e()
                        }
                      })).catch((function(e) {
                        var t;
                        if (e.message && v()(t = e.message).call(t, "核销次数已超上限")) return pe.value = !1, void n.error({
                          content: "门已开"
                        });
                        pe.value = !1, me.value = !0, fe.value = e.message
                      }))
                    }), 1e3)
                  })(), pe.value = !0, le.value = {
                    apptItemId: u.id,
                    classroomName: u.classroomName,
                    startDate: u.beginDatetime,
                    endData: u.endDatetime,
                    storeId: u.venueAppointmentUserId,
                    storeName: o,
                    storeAddress: a
                  }
                })).catch((function(e) {
                  me.value = !0, fe.value = e.message
                }))
              }
            },
            openDoorPopupShow: me,
            openDoorMessage: fe,
            onTapDoorFailPopupMask: function() {
              me.value = !1
            },
            onPressCallContactBtn: function() {
              D.value && k.mp.makePhoneCall({
                phoneNumber: D.value.venueAppt.storeTel
              })
            },
            posterPopupShow: pe,
            posterPopupInfo: le,
            onTapPosterPopupMask: function() {
              pe.value = !1, clearTimeout(se)
            },
            onPressTurnOnLightBtn: function(e) {
              if (D.value) {
                var t = D.value.venueAppt.apptClassroomItems[e];
                he({
                  apptItemUserId: t.venueAppointmentUserId,
                  apptItemUid: t.txtUid
                }).then((function() {
                  n.toast({
                    title: "已发送开灯请求"
                  })
                }))
              }
            },
            onPressTurnOffLightBtn: function(e) {
              if (D.value) {
                var t = D.value.venueAppt.apptClassroomItems[e];
                ge({
                  apptItemUserId: t.venueAppointmentUserId,
                  apptItemUid: t.txtUid
                }).then((function() {
                  n.toast({
                    title: "已发送关灯请求"
                  })
                }))
              }
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 99138)
  }
]);