var e = {};
e.webpackChunk_mpxapp_decoration = require("../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [3567], {
    91029: function() {},
    50918: function(e, r, n) {
      n.g.currentInject = {
        moduleId: "_367da21f"
      }, n.g.currentInject.render = function(e, r, n, t) {
        t("show", this.show) && (t("query", this.query), t("pageSharedId", this.pageSharedId)), n()
      }
    },
    127: function() {},
    47518: function(e, r, n) {
      n(97766), n.g.currentModuleId = "_367da21f", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "page", n(50918), n(127), n(91029), n.g.currentSrcMode = "wx", n(57809)
    },
    57809: function(e, r, n) {
      n.r(r);
      var t = n(43454),
        o = n.n(t),
        u = n(39347),
        c = n(95766),
        a = n(6520),
        i = n(86340),
        p = n(71328),
        d = n(92345),
        s = n(13572);
      n.g.currentInject.pageEvents = {
        onShareAppMessage: function(e) {
          return this.__mpxProxy.callHook("__onShareAppMessage__", [e])
        },
        onShareTimeline: function(e) {
          return this.__mpxProxy.callHook("__onShareTimeline__", [e])
        }
      }, (0, c.A)({
        setup: function() {
          var e, r = o()(e = getCurrentPages()).call(e, -1)[0].route,
            n = (0, i.N)(),
            t = n.data,
            c = n.status,
            l = (0, p.bz)(),
            h = (0, d.s)(l);
          return (0, a.Zg)((function() {
            var e, n;
            return {
              title: "场地预约",
              path: (0, s.C7)("/".concat(r), {
                storeId: h.id,
                projectUid: null === (e = t.value) || void 0 === e ? void 0 : e.projectUid,
                projectType: null === (n = t.value) || void 0 === n ? void 0 : n.projectType
              })
            }
          })), (0, a.Y9)((function() {
            var e, r;
            return {
              title: "场地预约",
              query: (0, s.OJ)({
                storeId: h.id,
                projectUid: null === (e = t.value) || void 0 === e ? void 0 : e.projectUid,
                projectType: null === (r = t.value) || void 0 === r ? void 0 : r.projectType
              })
            }
          })), {
            query: t,
            show: (0, u.E)((function() {
              return "success" === c.value
            })),
            pageSharedId: l
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 47518)
  }
]);