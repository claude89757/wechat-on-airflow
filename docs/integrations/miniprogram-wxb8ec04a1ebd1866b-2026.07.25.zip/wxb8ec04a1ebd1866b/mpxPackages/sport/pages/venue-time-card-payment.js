require("../../../@babel/runtime/helpers/Arrayincludes");
var n = {};
n.webpackChunk_mpxapp_decoration = require("../bundle.js"), (n.webpackChunk_mpxapp_decoration = n.webpackChunk_mpxapp_decoration || []).push([
  [2485], {
    63875: function() {},
    78895: function(n, e, o) {
      var a = o(87843);
      o.g.currentInject = {
        moduleId: "_8a771362"
      }, o.g.currentInject.render = function(n, e, o, t) {
        t("venueTimeCardConfirmOrder", this.venueTimeCardConfirmOrder) && (e("venueTimeCardConfirmOrder.photoPath", this.venueTimeCardConfirmOrder.photoPath), e("venueTimeCardConfirmOrder.name", this.venueTimeCardConfirmOrder.name), e("venueTimeCardConfirmOrder.totalCount", this.venueTimeCardConfirmOrder.totalCount), t("currencySymbol", this.currencySymbol), e("venueTimeCardConfirmOrder.totalAmount", this.venueTimeCardConfirmOrder.totalAmount), e("venueTimeCardConfirmOrder.periodOfUse", this.venueTimeCardConfirmOrder.periodOfUse), t("shoppingCardText", this.shoppingCardText), e("apptSelectedCardsAndCoupons.shoppingCards", this.apptSelectedCardsAndCoupons.shoppingCards).length ? e("apptSelectedCardsAndCoupons.shoppingCardNames", this.apptSelectedCardsAndCoupons.shoppingCardNames) : e("apptValidCardsAndCoupons.shoppingCardCount", this.apptValidCardsAndCoupons.shoppingCardCount) && e("apptValidCardsAndCoupons.shoppingCardCount", this.apptValidCardsAndCoupons.shoppingCardCount), e("apptSelectedCardsAndCoupons.shoppingCards", this.apptSelectedCardsAndCoupons.shoppingCards).length && e("apptSelectedCardsAndCoupons.shoppingCardDiscountAmount", this.apptSelectedCardsAndCoupons.shoppingCardDiscountAmount) > 0 && e("apptSelectedCardsAndCoupons.shoppingCardDiscountAmount", this.apptSelectedCardsAndCoupons.shoppingCardDiscountAmount), e("apptSelectedCardsAndCoupons.coupons", this.apptSelectedCardsAndCoupons.coupons).length ? e("apptSelectedCardsAndCoupons.couponsName", this.apptSelectedCardsAndCoupons.couponsName) : e("apptValidCardsAndCoupons.availableCouponsCanUseCount", this.apptValidCardsAndCoupons.availableCouponsCanUseCount) > 0 && e("apptValidCardsAndCoupons.availableCouponsCanUseCount", this.apptValidCardsAndCoupons.availableCouponsCanUseCount), t("orderRemark", this.orderRemark), e("venueTimeCardConfirmOrder.totalCount", this.venueTimeCardConfirmOrder.totalCount), t("currencySymbol", this.currencySymbol), e("venueTimeCardConfirmOrder.totalAmount", this.venueTimeCardConfirmOrder.totalAmount), t("currencySymbol", this.currencySymbol), e("venueTimeCardConfirmOrder.realAmount", this.venueTimeCardConfirmOrder.realAmount), e("apptSelectedCardsAndCoupons.shoppingCardPayAmount", this.apptSelectedCardsAndCoupons.shoppingCardPayAmount) > 0 && (t("shoppingCardText", this.shoppingCardText), e("venueTimeCardConfirmOrder.needPayAmount", this.venueTimeCardConfirmOrder.needPayAmount) > 0 && (t("currencySymbol", this.currencySymbol), e("venueTimeCardConfirmOrder.needPayAmount", this.venueTimeCardConfirmOrder.needPayAmount))), e("venueTimeCardConfirmOrder.needPayAmount", this.venueTimeCardConfirmOrder.needPayAmount) > 0 && (t("paymentMethodSelectConfig", this.paymentMethodSelectConfig), t("paymentMethodSelectValue", this.paymentMethodSelectValue)), t("currencySymbol", this.currencySymbol), e("venueTimeCardConfirmOrder.realAmount", this.venueTimeCardConfirmOrder.realAmount), e("venueTimeCardConfirmOrder.totalCount", this.venueTimeCardConfirmOrder.totalCount), t("orderBtnLoading", this.orderBtnLoading), t("orderBtnDisabled", this.orderBtnDisabled), t("apptValidCardsAndCoupons", this.apptValidCardsAndCoupons) && (t("shoppingCardPopupShow", this.shoppingCardPopupShow), t("shoppingCardText", this.shoppingCardText), 0 == e("apptValidCardsAndCoupons.shoppingCards", this.apptValidCardsAndCoupons.shoppingCards).length && t("shoppingCardText", this.shoppingCardText), n(e("apptValidCardsAndCoupons.shoppingCards", this.apptValidCardsAndCoupons.shoppingCards), (function(n, e) {
          a.includes(t("shoppingCardPopupSUids", this.shoppingCardPopupSUids), n.uid), n.uid, n.name, n.validityPeriod, t("currencySymbol", this.currencySymbol), n.balance, a.includes(t("shoppingCardPopupSUids", this.shoppingCardPopupSUids), n.uid)
        })), t("shoppingCardPopupBtnDisabled", this.shoppingCardPopupBtnDisabled)), t("couponPopupShow", this.couponPopupShow), 0 == e("apptValidCardsAndCoupons.availableCoupons", this.apptValidCardsAndCoupons.availableCoupons).length || n(e("apptValidCardsAndCoupons.availableCoupons", this.apptValidCardsAndCoupons.availableCoupons), (function(n, e) {
          n.disabled, n.approachingExpirationDate, n.image, n.name, n.disabled && n.disabledText, n.approachingExpirationDate && n.expirationDate, n.description, a.includes(t("couponPopupSelectedCouponCodes", this.couponPopupSelectedCouponCodes), n.code), n.disabled
        })), t("couponPopupBtnDisabled", this.couponPopupBtnDisabled)), o()
      }
    },
    60974: function() {},
    62324: function(n, e, o) {
      o(97766), o.g.currentModuleId = "_8a771362", o.g.currentCtor = Component, o.g.currentCtorType = "component", o.g.currentResourceType = "page", o(78895), o(60974), o(63875), o.g.currentSrcMode = "wx", o(60043)
    },
    60043: function(n, e, o) {
      o.r(e);
      var a = o(49e3),
        t = o.n(a),
        r = o(17195),
        u = o.n(r),
        i = o(82567),
        d = o.n(i),
        p = o(87802),
        l = o.n(p),
        s = o(27715),
        c = o(39298),
        C = o(53888),
        m = o(57391),
        h = o.n(m),
        v = o(74058),
        f = o.n(v),
        g = o(93690),
        y = o.n(g),
        b = o(91630),
        A = o.n(b),
        P = (o(80173), o(78475)),
        T = o.n(P),
        S = o(60192),
        O = o.n(S),
        U = o(61458),
        x = o(39164),
        I = o(86340),
        D = o(64024),
        V = o(74665),
        M = o(11821),
        B = o(40519),
        E = o(70841),
        N = o(39347),
        w = o(95766),
        k = o(92206),
        j = o(84665),
        Y = o.n(j),
        R = o(31259),
        _ = o.n(R),
        q = o(83887),
        L = o(66855);

      function J(n, e) {
        var o = t()(n);
        if (u()) {
          var a = u()(n);
          e && (a = f()(a).call(a, (function(e) {
            return d()(n, e).enumerable
          }))), o.push.apply(o, a)
        }
        return o
      }

      function F(n) {
        for (var e = 1; e < arguments.length; e++) {
          var o = null != arguments[e] ? arguments[e] : {};
          e % 2 ? J(Object(o), !0).forEach((function(e) {
            (0, c.A)(n, e, o[e])
          })) : l() ? Object.defineProperties(n, l()(o)) : J(Object(o)).forEach((function(e) {
            Object.defineProperty(n, e, d()(o, e))
          }))
        }
        return n
      }(0, w.A)({
        setup: function() {
          var n = (0, x.JX)(),
            e = (0, V.r)(),
            o = (0, q.G)(),
            a = (0, L.uP)(),
            t = (0, N.E)((function() {
              return o.messages.shoppingCard
            })),
            r = (0, N.E)((function() {
              return a.data.currency
            })),
            u = (0, D.n)(),
            i = (0, I.N)((function(n) {
              if (!n.userId || !n.uid) return h().reject(new Error("页面参数错误"));
              var e = 1;
              return n.quantity && Number(n.quantity) >= 1 && (e = Number(n.quantity)), {
                userId: Number(n.userId),
                uid: n.uid,
                quantity: e
              }
            })).data,
            d = (0, N.E)((function() {
              if (i.value) return {
                ruleUid: i.value.uid,
                ruleUserId: i.value.userId,
                totalCount: i.value.quantity
              }
            })),
            p = (0, M.B8)("VenueTimeCard/LoadAvailableCouponCodes", {
              transform: function(n) {
                return n.result
              },
              default: function() {
                return []
              }
            }),
            l = p.data,
            c = p.pending,
            m = p.error,
            v = p.execute;
          (0, B.nT)((function() {
            d.value && h().all([hn(d.value), v({
              cards: [{
                cardRuleUid: d.value.ruleUid,
                cardRuleUserId: d.value.ruleUserId
              }]
            }), X({
              venueTimeCardUids: [d.value.ruleUid]
            })]).then((function(n) {
              var e = (0, C.A)(n, 3),
                o = e[0],
                a = e[1],
                t = e[2];
              if (o.totalAmount > 0) {
                var r = f()(t).call(t, (function(n) {
                    return n.CanUseOrNot
                  })),
                  u = f()(a).call(a, (function(n) {
                    return n.CanUserOrNot
                  }));
                if (1 !== r.length + u.length) return;
                if (1 === r.length) {
                  var i = r[0].txtUid;
                  if (!d.value) return;
                  return void hn(F(F({}, d.value), {}, {
                    paymentItems: [{
                      paymentMethod: 219,
                      shoppingCardUid: i
                    }]
                  }))
                }
                if (1 === u.length) {
                  var p = u[0].code;
                  if (!d.value) return;
                  return void hn(F(F({}, d.value), {}, {
                    usedCoupons: [{
                      code: p
                    }]
                  }))
                }
              }
            }))
          }));
          var g = (0, N.E)((function() {
              var n, e = Y()(),
                o = Y()().add(3, "days");
              return y()(n = l.value).call(n, (function(n) {
                var a, t = n.expiredDate || n.promotionCoupon.endDate,
                  r = null === (a = n.promotionCoupon.promotionCashback) || void 0 === a ? void 0 : a.stackableQuantity;
                return {
                  code: n.code,
                  promotionCouponId: n.promotionCoupon.id,
                  userId: n.promotionCoupon.userId,
                  name: n.promotionCoupon.name,
                  description: n.promotionCoupon.description,
                  image: n.promotionCoupon.defaultImagePath && "https://img.pospal.cn/" + n.promotionCoupon.defaultImagePath,
                  disabled: !n.CanUserOrNot,
                  disabledText: n.UnavailableReason,
                  stackableQuantity: r,
                  stackable: (r || 0) > 1,
                  approachingExpirationDate: Y()(t).isBetween(e, o),
                  expirationDate: t,
                  isDouYinType: n.isDouYinType
                }
              }))
            })),
            b = (0, U.C)(),
            P = b.value,
            S = b.open,
            w = b.close,
            j = (0, E.IJ)([]),
            R = (0, N.E)((function() {
              return !en.value.coupons.length && !j.value.length
            })),
            J = (0, M.B8)("VenueTimeCard/LoadCustomerValidShoppingCardsForVenueTimeCard", {
              transform: function(n) {
                return n.result
              },
              default: function() {
                return []
              }
            }),
            Q = J.data,
            G = J.pending,
            W = J.error,
            X = J.execute,
            z = (0, N.E)((function() {
              var n;
              return y()(n = Q.value).call(n, (function(n) {
                var e;
                return {
                  uid: n.txtUid,
                  name: n.ShoppingCardRuleName,
                  validityPeriod: n.expireDateTime ? O()(e = "".concat(Y()(n.startUseDateTime).format("YYYY.MM.DD"), "-")).call(e, Y()(n.expireDateTime).format("YYYY.MM.DD")) : "永久有效",
                  balance: n.balance,
                  disabled: !n.CanUseOrNot
                }
              }))
            })),
            H = (0, N.E)((function() {
              var n;
              return A()(n = z.value).call(n, (function(n, e) {
                return e.disabled ? n : Math.max(n, e.balance)
              }), 0)
            })),
            K = (0, U.C)(),
            Z = K.value,
            $ = K.open,
            nn = K.close,
            en = (0, N.E)((function() {
              if (On.value && an.value) {
                var n = On.value,
                  e = n.usedShoppingCards,
                  o = void 0 === e ? [] : e,
                  a = n.usedCoupons,
                  t = void 0 === a ? [] : a,
                  r = n.paymentItems,
                  u = void 0 === r ? [] : r,
                  i = t,
                  d = A()(i).call(i, (function(n, e) {
                    var o = e.paymethods;
                    return o && (n = n ? f()(n).call(n, (function(n) {
                      return T()(o).call(o, n)
                    })) : (0, s.A)(o)), n
                  }), null),
                  p = o;
                return {
                  shoppingCards: p,
                  shoppingCardNames: y()(p).call(p, (function(n) {
                    return n.ShoppingCardRuleName
                  })).join("、"),
                  shoppingCardPayAmount: A()(u).call(u, (function(n, e) {
                    return 219 === e.paymentMethod && e.shoppingCardUid && void 0 !== e.amount ? n.add(e.amount || 0) : n
                  }), _()(0)).value,
                  shoppingCardDiscountAmount: A()(u).call(u, (function(n, e) {
                    return 219 === e.paymentMethod && e.shoppingCardUid && void 0 !== e.discountAmount ? n.add(e.discountAmount || 0) : n
                  }), _()(0)).value,
                  coupons: i,
                  couponsName: y()(i).call(i, (function(n) {
                    return n.promotionCoupon.name
                  })).join("、"),
                  couponsAllowPayMethods: d
                }
              }
              return {
                shoppingCards: [],
                shoppingCardNames: "",
                shoppingCardPayAmount: 0,
                shoppingCardDiscountAmount: 0,
                coupons: [],
                couponsName: "",
                couponsAllowPayMethods: null
              }
            })),
            on = (0, E.IJ)([]),
            an = (0, N.E)((function() {
              var n;
              return On.value ? {
                availableCoupons: g.value,
                availableCouponsCanUseCount: A()(n = g.value).call(n, (function(n, e) {
                  return e.disabled ? n : n + 1
                }), 0),
                shoppingCards: z.value,
                shoppingCardCount: z.value.length
              } : {
                availableCoupons: [],
                availableCouponsCanUseCount: 0,
                shoppingCards: [],
                shoppingCardCount: 0
              }
            })),
            tn = (0, N.E)((function() {
              return !en.value.shoppingCards.length && !on.value.length
            })),
            rn = (0, M.i7)("Checkout/IndexNoDiscount", {
              transform: function(n) {
                return n.data
              }
            }),
            un = rn.data,
            dn = rn.pending,
            pn = rn.error,
            ln = rn.execute,
            sn = (0, M.B8)("VenueTimeCard/VenueTimeCardConfirm", {
              transform: function(n) {
                return n.result
              }
            }),
            cn = sn.data,
            Cn = sn.pending,
            mn = sn.error,
            hn = sn.execute,
            vn = (0, M.B8)("VenueTimeCard/VenueTimeCardConfirm", {
              transform: function(n) {
                return n.result
              }
            }),
            fn = vn.pending,
            gn = vn.error,
            yn = vn.execute,
            bn = (0, E.IJ)(""),
            An = (0, M.B8)("VenueTimeCard/VenueTimeCardOrder", {
              transform: function(n) {
                return n.result
              }
            }),
            Pn = An.pending,
            Tn = An.error,
            Sn = An.execute;
          (0, x.BU)([Cn, c, G, dn]), (0, x.FB)([m, W, pn, mn, gn, Tn]);
          var On = (0, N.E)((function() {
              var n, e = cn.value;
              return e && {
                userId: e.rule.userId,
                uid: e.rule.uidTxt,
                name: e.rule.name,
                photoPath: e.rule.photoPathFull,
                periodOfUse: (0, k.p_)(e.rule),
                price: e.rule.price,
                totalAmount: e.totalAmount,
                needPayAmount: e.needPayAmount || 0,
                realAmount: e.realAmount || 0,
                totalCount: e.totalCount,
                usedShoppingCards: null === (n = e.usedShoppingCards) || void 0 === n ? void 0 : y()(n).call(n, (function(n) {
                  return F(F({}, n), {}, {
                    uid: n.txtUid
                  })
                })),
                discountAmount: e.discountAmount,
                usedCoupons: e.usedCoupons || [],
                paymentItems: e.paymentItems || []
              }
            })),
            Un = (0, N.E)((function() {
              if (On.value && un.value) {
                var n = en.value.couponsAllowPayMethods,
                  e = H.value,
                  o = On.value.realAmount,
                  a = e > 0 && e < o ? "buyCard" : "recharge";
                return {
                  totalAmount: On.value.needPayAmount,
                  balancePay: Boolean(un.value.EnableCustomerBalancePayMethod) && (!n || T()(n).call(n, 7)),
                  balanceAmount: un.value.CustomerBalance,
                  balanceCombinedPay: !0,
                  balanceInsufficientAction: a,
                  onlinePay: !n || T()(n).call(n, 17) ? un.value.EnableWxPayMethod ? "wechat" : un.value.EnableThirdPartyPayMethod ? "thirdParty" : void 0 : void 0
                }
              }
              return {
                totalAmount: 0,
                balancePay: !1,
                balanceAmount: 0,
                balanceCombinedPay: !1,
                balanceInsufficientAction: "recharge",
                onlinePay: void 0
              }
            })),
            xn = (0, E.IJ)({
              balance: !1,
              online: void 0
            }),
            In = (0, N.E)((function() {
              var n, e;
              return null !== (n = null === (e = un.value) || void 0 === e || null === (e = e.ThirdPartyPayMethods) || void 0 === e || null === (e = e[0]) || void 0 === e ? void 0 : e.Code) && void 0 !== n ? n : 900
            }));
          (0, B.wB)(Un, (function(n) {
            var e = {
              balance: !1,
              online: void 0
            };
            n.balancePay && n.balanceAmount > 0 ? n.balanceAmount >= n.totalAmount ? e.balance = !0 : n.balanceCombinedPay && n.onlinePay ? (e.balance = !0, e.online = n.onlinePay) : n.onlinePay && (e.online = n.onlinePay) : n.onlinePay && (e.online = n.onlinePay), xn.value = e
          }));
          var Dn = (0, N.E)((function() {
              return Cn.value || fn.value || Pn.value
            })),
            Vn = (0, N.E)((function() {
              var n = Un.value,
                e = xn.value;
              return !(e.online || e.balance && n.balanceAmount >= n.totalAmount)
            }));
          return {
            currencySymbol: r,
            venueTimeCardConfirmOrder: On,
            onTapCouponCell: function() {
              var n;
              j.value = y()(n = en.value.coupons).call(n, (function(n) {
                return n.code
              })) || [], S()
            },
            couponPopupShow: P,
            couponPopupClose: w,
            couponPopupSelectedCouponCodes: j,
            couponPopupBtnDisabled: R,
            onTapCouponPopupItem: function(n) {
              var e, o = null === (e = an.value) || void 0 === e ? void 0 : e.availableCoupons[n];
              if ((!o || !o.disabled) && o) {
                var a = j.value;
                T()(a).call(a, o.code) ? j.value = f()(a).call(a, (function(n) {
                  return n !== o.code
                })) : j.value = [o.code]
              }
            },
            onTapCouponPopupDetailLink: function(n) {
              var e, o = an.value.availableCoupons[n];
              wx.navigateTo({
                url: O()(e = "/accountSubpages/pages/account/couponPromotionCardDetails/couponPromotionCardDetails?code=".concat(o.code, "&filterStoreId=")).call(e, o.userId)
              })
            },
            onPressCouponPopupBtn: function() {
              var n, e;
              d.value && hn(F(F({}, d.value), {}, {
                usedCoupons: y()(n = j.value).call(n, (function(n) {
                  return {
                    code: n
                  }
                })),
                paymentItems: y()(e = en.value.shoppingCards).call(e, (function(n) {
                  return {
                    paymentMethod: 219,
                    shoppingCardUid: n.uid
                  }
                }))
              })).then((function() {
                w()
              }))
            },
            orderRemark: bn,
            paymentMethodSelectConfig: Un,
            paymentMethodSelectValue: xn,
            orderBtnLoading: Dn,
            orderBtnDisabled: Vn,
            onPressOrderBtn: function() {
              var o, a, t, r = Un.value,
                i = xn.value;
              if (Vn.value) i.balance || i.online ? n.toast({
                title: "当前选择的支付方式不足以支付订单"
              }) : n.toast({
                title: "请选择支付方式"
              });
              else if (On.value && un.value) {
                var p = [],
                  l = _()(r.totalAmount);
                if (l.value > 0 && i.balance) {
                  var c = Math.min(r.balanceAmount, l.value);
                  p.push({
                    paymentMethod: 2
                  }), l = l.subtract(c)
                }
                i.online && l.value > 0 && ("wechat" === i.online ? p.push({
                  paymentMethod: 4
                }) : "thirdParty" === i.online && p.push({
                  paymentMethod: In.value
                }));
                var C = {
                  ruleUserId: On.value.userId,
                  ruleUid: On.value.uid,
                  totalCount: On.value.totalCount
                };
                yn(F(F({}, C), {}, {
                  paymentItems: O()(o = []).call(o, (0, s.A)(y()(a = en.value.shoppingCards).call(a, (function(n) {
                    return {
                      paymentMethod: 219,
                      shoppingCardUid: n.uid
                    }
                  }))), p),
                  usedCoupons: y()(t = en.value.coupons).call(t, (function(n) {
                    return {
                      code: n.code
                    }
                  }))
                })).then((function(n) {
                  var e;
                  return Sn(F(F(F({}, C), n), {}, {
                    usedCoupons: null === (e = n.usedCoupons) || void 0 === e ? void 0 : y()(e).call(e, (function(n) {
                      return {
                        code: n.code
                      }
                    })),
                    remark: bn.value
                  }))
                })).then((function(o) {
                  var a = function() {
                    e.redirectTo({
                      page: "/sport/pages/venue-time-card-payment-success",
                      query: {
                        orderNo: o.orderNo
                      }
                    })
                  };
                  o.isPaid ? a() : o.payScript && u(o.payScript).then((function() {
                    a()
                  })).catch((function(o) {
                    "cancel" === o.type ? n.toast({
                      title: "支付取消",
                      icon: "error"
                    }) : "unsure" === o.type ? n.modal({
                      title: "提示",
                      content: "如果您已完成支付，请前往 我的场地卡 页面查看",
                      confirmText: "去查看",
                      cancelText: "未支付"
                    }).then((function(n) {
                      n.confirm ? e.redirectTo({
                        page: "/sport/pages/my-venue-time-card-list"
                      }) : e.navigateBack()
                    })) : n.error({
                      content: o.message
                    })
                  }))
                })).catch((function() {
                  d.value && hn(d.value), ln()
                }))
              }
            },
            apptValidCardsAndCoupons: an,
            shoppingCards: z,
            shoppingCardText: t,
            shoppingCardPopupSUids: on,
            apptSelectedCardsAndCoupons: en,
            onTapShoppingCardCell: function() {
              var n;
              on.value = y()(n = en.value.shoppingCards).call(n, (function(n) {
                return n.uid
              })) || [], $()
            },
            shoppingCardPopupShow: Z,
            shoppingCardPopupClose: nn,
            onTapShoppingCardPopupItem: function(n) {
              var e = on.value;
              T()(e).call(e, n) ? on.value = f()(e).call(e, (function(e) {
                return e !== n
              })) : on.value = [n]
            },
            onPressShoppingCardPopupBtn: function() {
              var n, e;
              d.value && hn(F(F({}, d.value), {}, {
                usedCoupons: y()(n = j.value).call(n, (function(n) {
                  return {
                    code: n
                  }
                })),
                paymentItems: null === (e = on.value) || void 0 === e ? void 0 : y()(e).call(e, (function(n) {
                  return {
                    paymentMethod: 219,
                    shoppingCardUid: n
                  }
                }))
              })).then((function() {
                nn()
              }))
            },
            shoppingCardPopupBtnDisabled: tn
          }
        }
      })
    }
  },
  function(n) {
    n(n.s = 62324)
  }
]);