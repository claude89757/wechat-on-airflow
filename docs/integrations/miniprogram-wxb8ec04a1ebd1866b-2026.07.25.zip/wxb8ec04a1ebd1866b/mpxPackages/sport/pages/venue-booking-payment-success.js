var e = {};
e.webpackChunk_mpxapp_decoration = require("../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [4316], {
    83404: function() {},
    30868: function(e, t, o) {
      o.g.currentInject = {
        moduleId: "_4a22dbe4"
      }, o.g.currentInject.render = function(e, t, o, n) {
        n("apptInfo", this.apptInfo) && (t("apptInfo.date", this.apptInfo.date), e(t("apptInfo.classroomItems", this.apptInfo.classroomItems), (function(t, o) {
          t.name, t.time, t.peopleCount && t.peopleCount, n("currencySymbol", this.currencySymbol), t.cost, e(t.chargeFees, (function(e, t) {
            e.feeTypeName, n("currencySymbol", this.currencySymbol), e.amount
          }))
        })), n("currencySymbol", this.currencySymbol), t("apptInfo.totalAmount", this.apptInfo.totalAmount), t("apptInfo.paymentsTxt", this.apptInfo.paymentsTxt), t("apptInfo.createdDatetime", this.apptInfo.createdDatetime), t("apptInfo.storeAddress", this.apptInfo.storeAddress), t("apptInfo.storeTel", this.apptInfo.storeTel), n("posterPopupInfo", this.posterPopupInfo) && (n("posterPopupShow", this.posterPopupShow), n("posterPopupInfo", this.posterPopupInfo))), o()
      }
    },
    81734: function() {},
    81977: function(e, t, o) {
      o(97766), o.g.currentModuleId = "_4a22dbe4", o.g.currentCtor = Component, o.g.currentCtorType = "component", o.g.currentResourceType = "page", o(30868), o(81734), o(83404), o.g.currentSrcMode = "wx", o(66254)
    },
    66254: function(e, t, o) {
      o.r(t);
      var n = o(57391),
        r = o.n(n),
        a = o(93690),
        p = o.n(a),
        s = o(60192),
        u = o.n(s),
        c = o(43454),
        i = o.n(c),
        d = o(74058),
        m = o.n(d),
        l = o(33134),
        f = o.n(l),
        I = o(61740),
        v = o(39164),
        y = o(86340),
        h = o(74665),
        g = o(11821),
        D = o(70841),
        C = o(39347),
        x = o(95766),
        b = o(84665),
        T = o.n(b),
        A = o(31259),
        P = o.n(A),
        S = o(66855);
      (0, x.A)({
        setup: function() {
          (0, h.r)();
          var e = (0, S.uP)(),
            t = (0, C.E)((function() {
              return e.data.currency
            })),
            o = (0, y.N)((function(e) {
              return e.uid ? {
                userId: e.userId ? Number(e.userId) : void 0,
                uid: e.uid
              } : r().reject(new Error("页面参数错误"))
            })),
            n = o.data,
            a = o.pending,
            s = o.error,
            c = (0, g._y)("AppointmentVenue/LoadVenueApptDetail", {
              params: function() {
                return n.value ? {
                  userId: n.value.userId,
                  apptUid: n.value.uid
                } : I.Oy
              },
              transform: function(e) {
                return e.result
              }
            }),
            d = c.data,
            l = c.pending,
            x = c.error;
          (0, v.BU)([a, l]), (0, v.FB)([s, x]);
          var b = (0, C.E)((function() {
              if (d.value) {
                var e, o, n = d.value.venueAppt,
                  r = P()(n.appointAmount).add(P()(n.feeAmount || 0)).value,
                  a = p()(e = n.apptClassroomItems).call(e, (function(e) {
                    var t, o, r, a;
                    return {
                      id: e.id,
                      uid: e.txtUid,
                      name: e.classroomName,
                      startDate: e.beginDatetime,
                      endDate: e.endDatetime,
                      time: u()(t = "".concat(i()(o = e.beginDatetime).call(o, 11, 16), "-")).call(t, i()(r = e.endDatetime).call(r, 11, 16)),
                      cost: e.totalCost,
                      chargeFees: null === (a = n.apptClassroomItemFees) || void 0 === a ? void 0 : m()(a).call(a, (function(t) {
                        return t.txtItemUid === e.txtUid
                      })),
                      projectType: e.projectType,
                      txtClassroomUid: e.txtClassroomUid,
                      peopleCount: 1 === e.projectType ? 1 : void 0
                    }
                  }));
                return {
                  date: T()(n.apptClassroomItems[0].beginDatetime).format("YYYY-MM-DD ddd"),
                  classroomItems: A(a),
                  totalAmount: r,
                  storeId: n.userId,
                  storeName: n.storeName,
                  storeTel: n.storeTel,
                  storeAddress: n.storeAddress,
                  createdDatetime: n.createdDatetime,
                  paymentsTxt: p()(o = n.apptPayments).call(o, (function(e) {
                    var o, n;
                    return u()(o = u()(n = "".concat(e.payMethodName, " ")).call(n, t.value)).call(o, e.amount)
                  })).join("，")
                }
              }
            })),
            A = function(e) {
              return e.some((function(e) {
                return 1 === e.projectType
              })) ? function(e) {
                var t = new(f());
                e.forEach((function(e) {
                  var o, n = e.id,
                    r = e.txtClassroomUid,
                    a = e.uid,
                    p = e.name,
                    s = e.startDate,
                    c = e.endDate,
                    i = e.time,
                    d = e.cost,
                    m = e.projectType,
                    l = t.get(r);
                  l || (l = new(f()), t.set(r, l));
                  var I = u()(o = "".concat(s, "-")).call(o, c),
                    v = l.get(I);
                  v ? (v.cost = P()(v.cost).add(P()(d)).value, v.peopleCount = (v.peopleCount || 1) + 1) : l.set(I, {
                    id: n,
                    txtClassroomUid: r,
                    uid: a,
                    name: p,
                    startDate: s,
                    endDate: c,
                    time: i,
                    cost: d,
                    peopleCount: 1,
                    projectType: m
                  })
                }));
                var o = [];
                return t.forEach((function(e) {
                  e.forEach((function(e) {
                    return o.push(e)
                  }))
                })), o
              }(e) : e
            },
            w = (0, D.IJ)(!1),
            j = (0, D.IJ)();
          return {
            currencySymbol: t,
            apptInfo: b,
            onPressHomeBtn: function() {
              wx.reLaunch({
                url: "/pages/index/index?nogostoplist=1&nogoparent=1"
              })
            },
            onPressBookingRecordBtn: function() {
              wx.navigateTo({
                url: "/trainingSubpages/pages/appointmentSite/appointmentList/index"
              })
            },
            posterPopupShow: w,
            posterPopupInfo: j,
            onTapPosterPopupMask: function() {
              w.value = !1
            },
            onPressShareBtn: function(e) {
              if (b.value) {
                var t = b.value.classroomItems[e];
                w.value = !0, j.value = {
                  apptItemId: t.id,
                  classroomName: t.name,
                  startDate: t.startDate,
                  endData: t.endDate,
                  storeId: b.value.storeId,
                  storeName: b.value.storeName,
                  storeAddress: b.value.storeAddress
                }
              }
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 81977)
  }
]);