var e = {};
e.webpackChunk_mpxapp_decoration = require("../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [3371], {
    8481: function() {},
    5518: function(e, r, t) {
      t.g.currentInject = {
        moduleId: "_2bc8f2f6"
      }, t.g.currentInject.render = function(e, r, t, n) {
        n("orderDetails", this.orderDetails) && (e(r("orderDetails.list", this.orderDetails.list), (function(e, r) {
          e.photoPath, e.name, e.quantity, n("currencySymbol", this.currencySymbol), e.price
        })), r("orderDetails.orderDateTime", this.orderDetails.orderDateTime), n("currencySymbol", this.currencySymbol), r("orderDetails.payAmount", this.orderDetails.payAmount), r("orderDetails.storeAddress", this.orderDetails.storeAddress), r("orderDetails.storeTel", this.orderDetails.storeTel)), t()
      }
    },
    68510: function() {},
    57626: function(e, r, t) {
      t(97766), t.g.currentModuleId = "_2bc8f2f6", t.g.currentCtor = Component, t.g.currentCtorType = "component", t.g.currentResourceType = "page", t(5518), t(68510), t(8481), t.g.currentSrcMode = "wx", t(28173)
    },
    28173: function(e, r, t) {
      t.r(r);
      var n = t(57391),
        o = t.n(n),
        u = t(91630),
        i = t.n(u),
        a = t(80173),
        c = t.n(a),
        d = t(61740),
        s = t(39164),
        l = t(86340),
        p = t(74665),
        m = t(11821),
        f = t(39347),
        y = t(95766),
        h = t(66855);
      (0, y.A)({
        setup: function() {
          var e = (0, p.r)(),
            r = (0, h.uP)(),
            t = (0, f.E)((function() {
              return r.data.currency
            })),
            n = (0, l.N)((function(e) {
              return e.orderNo ? {
                orderNo: e.orderNo
              } : o().reject(new Error("页面参数错误"))
            })).data,
            u = (0, m._y)("VenueTimeCard/VenueTimeCardOrderDetail", {
              params: function() {
                return n.value ? {
                  localOrderNo: n.value.orderNo
                } : d.Oy
              },
              transform: function(e) {
                return e.result
              }
            }),
            a = u.data,
            y = u.pending,
            D = u.error;
          return (0, s.BU)([y]), (0, s.FB)([D]), {
            currencySymbol: t,
            orderDetails: (0, f.E)((function() {
              var e, r = a.value;
              return r ? {
                list: i()(e = r.customervenuetimecard).call(e, (function(e, r) {
                  var t = c()(e).call(e, (function(e) {
                    return e.uid === r.venuetimecard.uidTxt
                  }));
                  return t ? t.quantity += 1 : e.push({
                    uid: r.venuetimecard.uidTxt,
                    name: r.venuetimecard.name,
                    photoPath: r.venuetimecard.photoPathFull,
                    price: r.price,
                    quantity: 1
                  }), e
                }), []),
                orderDateTime: r.customervenuetimecardorder.createdDatetime,
                payAmount: r.totalAmount,
                storeAddress: r.address,
                storeTel: r.storeTel
              } : null
            })),
            onPressHomeBtn: function() {
              wx.reLaunch({
                url: "/pages/index/index?nogostoplist=1&nogoparent=1"
              })
            },
            onPressBookingBtn: function() {
              e.redirectTo({
                page: "/sport/pages/venue-booking"
              })
            }
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 57626)
  }
]);