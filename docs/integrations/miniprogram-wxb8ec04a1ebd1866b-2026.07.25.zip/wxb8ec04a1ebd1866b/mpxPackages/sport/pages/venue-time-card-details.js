var e = {};
e.webpackChunk_mpxapp_decoration = require("../bundle.js"), (e.webpackChunk_mpxapp_decoration = e.webpackChunk_mpxapp_decoration || []).push([
  [1641], {
    6331: function() {},
    96864: function(e, t, n) {
      n.g.currentInject = {
        moduleId: "_c5228eea"
      }, n.g.currentInject.render = function(e, t, n, r) {
        r("venueTimeCard", this.venueTimeCard) && (r("navOpacity", this.navOpacity), r("pageBackgroundStyle", this.pageBackgroundStyle), e(r("widgetsData", this.widgetsData), (function(e, t) {
          e.name, e.template
        })), "giftPage" !== t("query.sourcePage", this.query.sourcePage) && (r("quantity", this.quantity), r("totalAmount", this.totalAmount), t("venueTimeCard.maxSaleQuantity", this.venueTimeCard.maxSaleQuantity), r("footerBtnSpinning", this.footerBtnSpinning), t("venueTimeCard.cardType", this.venueTimeCard.cardType))), n()
      }
    },
    29262: function() {},
    42504: function(e, t, n) {
      n(97766), n.g.currentModuleId = "_c5228eea", n.g.currentCtor = Component, n.g.currentCtorType = "component", n.g.currentResourceType = "page", n(96864), n(29262), n(6331), n.g.currentSrcMode = "wx", n(23375)
    },
    23375: function(e, t, n) {
      n.r(t);
      var r = n(39298),
        a = n(43454),
        u = n.n(a),
        o = n(57391),
        i = n.n(o),
        l = n(80173),
        c = n.n(l),
        s = n(93690),
        d = n.n(s),
        p = n(49e3),
        m = n.n(p),
        v = n(17195),
        g = n.n(v),
        f = n(74058),
        h = n.n(f),
        y = n(82567),
        C = n.n(y),
        T = n(87802),
        I = n.n(T),
        P = n(61740),
        x = n(39164),
        S = n(86340),
        _ = n(80535),
        b = n(74665),
        j = n(11821),
        k = n(70841),
        A = n(39347),
        E = n(95766),
        O = n(6520),
        B = n(92206),
        D = n(84665),
        q = n.n(D),
        w = n(31259),
        F = n.n(w),
        U = n(13572),
        Q = n(66855),
        J = n(6355),
        M = n(79135),
        H = n(47512),
        L = n(98328),
        N = n(46867);

      function R(e, t) {
        var n = m()(e);
        if (g()) {
          var r = g()(e);
          t && (r = h()(r).call(r, (function(t) {
            return C()(e, t).enumerable
          }))), n.push.apply(n, r)
        }
        return n
      }

      function Z(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? R(Object(n), !0).forEach((function(t) {
            (0, r.A)(e, t, n[t])
          })) : I() ? Object.defineProperties(e, I()(n)) : R(Object(n)).forEach((function(t) {
            Object.defineProperty(e, t, C()(n, t))
          }))
        }
        return e
      }
      n.g.currentInject.pageEvents = {
        onShareAppMessage: function(e) {
          return this.__mpxProxy.callHook("__onShareAppMessage__", [e])
        }
      }, (0, E.A)({
        setup: function() {
          var e, t = u()(e = getCurrentPages()).call(e, -1)[0].route,
            n = (0, b.r)(),
            r = (0, L.C)(),
            a = (0, Q.uP)(),
            o = (0, Q.a1)({
              immediate: !1
            }),
            l = (0, A.E)((function() {
              return a.data.currency
            })),
            s = (0, M.bP)(a),
            p = s.pending,
            m = s.error,
            v = (0, M.bP)(o),
            g = v.pending,
            f = v.error,
            h = (0, J.J)(a, o),
            y = (0, S.N)((function(e) {
              return e.userId && e.uid ? {
                userId: Number(e.userId),
                uid: e.uid,
                sourcePage: e.sourcePage
              } : i().reject(new Error("页面参数错误"))
            })),
            C = y.data,
            T = y.pending,
            I = y.error,
            E = (0, j._y)("VenueTimeCard/LoadVenueTimeCardRuleDetail", {
              params: function() {
                return C.value ? {
                  ruleUid: C.value.uid,
                  ruleUserId: C.value.userId
                } : P.Oy
              },
              transform: function(e) {
                return e.result
              }
            }),
            D = E.data,
            w = E.pending,
            R = E.error,
            V = E.execute,
            z = (0, j._y)("Product/ReadDescStruct", {
              params: function() {
                return D.value ? {
                  id: D.value.id,
                  productType: 18
                } : P.Oy
              },
              transform: function(e) {
                return e.result.length ? JSON.parse(e.result[0].WigdetData) : []
              },
              default: function() {
                return []
              }
            }),
            W = z.data,
            G = z.pending,
            K = z.error,
            X = (0, A.E)((function() {
              var e, t = c()(e = W.value).call(e, (function(e) {
                return "页面设置" === e.name
              }));
              return t ? (0, N.gu)(t.template) : ""
            })),
            Y = (0, A.E)((function() {
              var e = D.value,
                t = $.value,
                n = W.value || [];
              return e && t && n && n.length > 0 ? d()(n).call(n, (function(t, n) {
                var r;
                return "场地卡面" === t.name ? t.template.data = {
                  durationInDays: 1 === e.timeLimitType ? q()(e.limitEndDatetime).diff(e.limitBeginDatetime, "day") : null !== (r = e.durationInDays) && void 0 !== r ? r : 0,
                  photoPath: e.photoPathFull
                } : "场地卡说明" === t.name && (t.template.data = $.value), Z(Z({}, t), {}, {
                  key: t.name + "-" + n
                })
              })) : [{
                name: "场地卡面",
                key: 1,
                template: {
                  background: "",
                  frontColor: "#000000",
                  showExpDate: !1,
                  data: t ? {
                    photoPath: t.photoPath
                  } : void 0
                }
              }, {
                name: "场地卡说明",
                key: 2,
                template: {
                  bgColor: "#ffffff",
                  fontColor: ["#3A3C4C", "#757575", "#333333"],
                  fontSize: [18, 13],
                  isBold: [!0, !1],
                  data: t
                }
              }]
            }));
          (0, x.BU)([T, w, G]), (0, x.FB)([I, R, m, f, K]), (0, _.c)(V);
          var $ = (0, A.E)((function() {
              var e = D.value;
              if (e) {
                var t = (0, B.b_)(e),
                  n = (0, B.Zi)(e);
                return {
                  uid: e.uidTxt,
                  userId: e.userId,
                  name: e.name,
                  photoPath: e.photoPathFull,
                  periodOfUse: (0, B.p_)(e),
                  ruleOfUse: (0, B.cF)(e),
                  price: e.price,
                  times: (0, B.mg)(e),
                  isSoldOut: (0, B.QZ)(e),
                  usageForAll: e.usageForAll,
                  projects: e.serviceclassroomprojects,
                  userProjects: t,
                  userProjectsText: 1 === t.length ? t[0].projectsText : "",
                  classrooms: e.serviceclassrooms,
                  userClassrooms: n,
                  userClassroomsText: 1 === n.length ? n[0].classroomsText : "",
                  usageAssignmentUsers: e.usageAssignmentUsers,
                  usageLimitText: (0, B.dn)(e),
                  limitsText: (0, B.nl)(e),
                  maxSaleQuantity: (0, B.m9)(e),
                  cardType: e.cardType,
                  autoActiveDate: (0, B.QH)(e)
                }
              }
            })),
            ee = (0, k.IJ)(1),
            te = (0, A.E)((function() {
              return $.value ? F()($.value.price).multiply(ee.value).value : 0
            })),
            ne = (0, A.E)((function() {
              return p.value || g.value
            })),
            re = (0, k.IJ)(0),
            ae = (0, A.E)((function() {
              return (0, H.I)(re.value, r.navigationBarInfo.totalHeight, {
                range: 100
              })
            }));
          return (0, O.Zg)((function() {
            var e, n, r, a;
            return {
              title: (null === (e = $.value) || void 0 === e ? void 0 : e.name) || "场地卡详情",
              imageUrl: null === (n = $.value) || void 0 === n ? void 0 : n.photoPath,
              path: (0, U.C7)("/".concat(t), {
                userId: null === (r = C.value) || void 0 === r ? void 0 : r.userId,
                uid: null === (a = C.value) || void 0 === a ? void 0 : a.uid
              })
            }
          })), {
            currencySymbol: l,
            venueTimeCard: $,
            quantity: ee,
            totalAmount: te,
            footerBtnSpinning: ne,
            onFooterChange: function(e) {
              ee.value = e.detail
            },
            onFooterBuy: function() {
              $.value && n.navigateTo({
                page: "/sport/pages/venue-time-card-payment",
                query: {
                  userId: $.value.userId,
                  uid: $.value.uid,
                  quantity: ee.value
                },
                guard: h
              })
            },
            pageBackgroundStyle: X,
            widgetsData: Y,
            handleScroll: function(e) {
              re.value = e.detail.scrollTop
            },
            navOpacity: ae,
            query: C
          }
        }
      })
    }
  },
  function(e) {
    e(e.s = 42504)
  }
]);